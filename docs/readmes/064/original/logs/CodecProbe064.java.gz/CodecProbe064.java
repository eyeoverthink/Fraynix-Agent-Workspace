package fraymus.workspace;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import org.json.*;
public class CodecProbe064 {
 public static void main(String[] args)throws Exception{String raw=new JSONObject(Files.readString(Path.of(args[0]))).toString();long start=System.nanoTime();String packed=BrainPayload064.pack(raw);double encode=(System.nanoTime()-start)/1e6;start=System.nanoTime();String restored=BrainPayload064.unpack(packed);double decode=(System.nanoTime()-start)/1e6;if(!raw.equals(restored))throw new IllegalStateException("Exact evidence text changed");var result=new JSONObject().put("passed",true).put("rawBytes",raw.getBytes(StandardCharsets.UTF_8).length).put("storedBytes",packed.getBytes(StandardCharsets.UTF_8).length).put("sha256",MapDefinition.sha(raw.getBytes(StandardCharsets.UTF_8))).put("encodeMillis",encode).put("decodeMillis",decode).put("scope","One exact completed study text; storage envelope includes Base64 and hash. Timing is this invocation, not a controlled end-to-end speed comparison.");Files.writeString(Path.of(args[1]),result.toString(2));System.out.println(result);}
}
