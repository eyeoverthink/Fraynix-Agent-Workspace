package fraymus.workspace;
import java.nio.file.*;
import org.json.*;
public class ExportContact064 {
 public static void main(String[] args)throws Exception{
  var job=new JSONObject(Files.readString(Path.of(args[0])));ContactStudy064.audit(job);var traces=new JSONArray();
  String[] columns={"timeS","tangentMps","normalMps","rotationDeg","angularSpeedRadps","normalImpulseNs","lateralMagnitudeNs","cachedTangentNs","observedContactTangentNs","momentumResidualNs","contactPoints","touchPoints"};
  for(Object raw:job.getJSONArray("diagnostics064")){var row=(JSONObject)raw;var r=row.getJSONObject("record");var series=new JSONArray();for(Object p:ContactMath064.series(r)){var s=(JSONObject)p;var a=new JSONArray();for(String key:columns)a.put(s.get(key));series.put(a);}traces.put(new JSONObject().put("definition",row.getJSONObject("definition")).put("variant",row.getString("variant")).put("settings",r.getJSONObject("settings")).put("summary",r.getJSONObject("summary")).put("recordSha256",r.getString("sha256")).put("series",series));}
  var data=new JSONObject().put("source",ContactStudy064.source()).put("columns",new JSONArray(columns)).put("traces",traces).put("intervalModel",job.getJSONObject("intervalModel064")).put("evaluation",job.getJSONObject("evaluation064")).put("stressEvaluation",job.getJSONObject("stressEvaluation064"));
  for(String phase:new String[]{"reserved","stress"}){var rows=new JSONArray();for(Object raw:job.getJSONArray(phase+"064")){var row=(JSONObject)raw;rows.put(new JSONObject().put("definition",row.getJSONObject("definition")).put("actual",row.getJSONObject("record").getJSONObject("summary").getDouble("endpointM")).put("intervals",row.getJSONObject("intervalsBeforeObservation")));}data.put(phase,rows);}
  Files.writeString(Path.of(args[1]),data.toString());System.out.println("Exported "+traces.length()+" audited Java traces and60reserved/30stress intervals");
 }
}
