import java.util.*;
import java.nio.ByteBuffer;
public class ReviewProbe {
    public static void main(String[] args) {
        double[] input=new double[32];Arrays.fill(input,1.0);
        for(int n:new int[]{4,8,10,32,128}){
            double[] out=new FraynixGPT.Connectome.Fly(32,n).encode(input);
            System.out.println("sparse_layer size="+n+" active="+Arrays.stream(out).filter(x->x!=0).count());
        }
        var c=new FraynixGPT.ChronosHive.Column("review-column","review-parent",3,32,FraynixGPT.ChronosHive.Role.AXIOM_ARCHITECT);
        for(int i=0;i<6;i++)c.step(input,.7,16);
        // Explicit valid lifecycle state exposes what the serialization contract retains.
        c.highStress=2;c.idle=59;c.flash=7;c.omega+=.25;c.reseal();
        byte[] seal=FraynixGPT.ChronosHive.exportSeal(List.of(c));
        var loaded=FraynixGPT.ChronosHive.loadSeal(seal).get(0);
        System.out.println("column_weights_exact="+Arrays.deepEquals(c.W,loaded.W));
        System.out.println("column_B_pred_exact="+(Arrays.equals(c.B,loaded.B)&&Arrays.equals(c.pred,loaded.pred)));
        System.out.println("lifecycle original="+c.highStress+","+c.idle+","+c.flash+","+c.parent+","+c.omega+" loaded="+loaded.highStress+","+loaded.idle+","+loaded.flash+","+loaded.parent+","+loaded.omega);
        byte[] unknown=seal.clone();ByteBuffer.wrap(unknown).putInt(8,999);
        byte[] digest=FraynixGPT.Sha256.digest(Arrays.copyOf(unknown,unknown.length-32));System.arraycopy(digest,0,unknown,unknown.length-32,32);
        var verdict=FraynixGPT.ChronosHive.verifySeal(unknown);
        System.out.println("resealed_unknown_version="+verdict.version+" accepted="+verdict.valid);
        long[] a=new long[128],b=new long[128];for(int i=0;i<128;i++){a[i]=(long)i*0x9E3779B97F4A7C15L;b[i]=~a[127-i];}
        System.out.println("joint_rotation_preserves_similarity="+(FraynixGPT.ChronosHive.sim(a,b)==FraynixGPT.ChronosHive.sim(FraynixGPT.ChronosHive.rot1(a),FraynixGPT.ChronosHive.rot1(b))));
    }
}
