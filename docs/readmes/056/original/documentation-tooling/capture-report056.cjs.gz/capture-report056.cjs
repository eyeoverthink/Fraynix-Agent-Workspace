const {launch}=require('../workspace-desktop/test/calibration-integration.cjs');
const fs=require('node:fs/promises'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
 process.env.FRAYNIX_WORKSPACE_PERSISTENT='0'; process.env.FRAYNIX_WORKSPACE_PLAN_CPU_ONLY='1';
 const out=path.resolve('workspace-desktop/test-output'),live=JSON.parse(await fs.readFile(path.join(out,'construction056-live.json'),'utf8'));assert(live.passed);
 const {app,page}=await launch(live.project);const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 try{
  assert(!(await app.evaluate(()=>global.workspaceTest.activityTrace())).some(e=>JSON.stringify(e).includes('Saved artifact could not open')));
  const artifact=await app.evaluate((_,id)=>global.workspaceTest.execute('canvas.open',{id}),live.first.report.id);
  await page.locator('#preview-tab').click();
  await page.waitForFunction(()=>document.querySelector('#preview-tab').classList.contains('selected')&&!document.querySelector('#canvas-surface').hidden);
  const observed=await app.evaluate(()=>global.workspaceTest.canvasRead('({curves:document.querySelectorAll("#load056-curve").length, structured:JSON.parse(document.querySelector("#cf045-data").textContent).version, width:innerWidth})'));
  assert.equal(observed.curves,1);assert(observed.width>400);
  await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  await app.evaluate(()=>global.workspaceTest.canvasRead('document.querySelector("#load056-curve").scrollIntoView({block:"center"}); true'));
  await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  await fs.writeFile(path.join(out,'construction056-chart.png'),Buffer.from(await app.evaluate(()=>global.workspaceTest.capture()),'base64'));
  assert.deepEqual(errors,[]);
  const record={passed:true,source:require('node:child_process').execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),project:live.project,report:live.first.report,observed,checks:['Actual saved verified report opens after cold restart without fallback','Live preview visibly selected before composite screenshot; original load curve remains present and is scrolled into view'],errors};
  await fs.writeFile(path.join(out,'construction056-report-capture.json'),JSON.stringify(record,null,2));console.log(JSON.stringify(record));
 }finally{await app.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
