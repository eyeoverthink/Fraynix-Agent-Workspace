from pathlib import Path
import subprocess,json
r=Path(__file__).resolve().parent.parent;m=json.loads((r/'docs/readmes/editions.json').read_text(encoding='utf8'));e=m['editions'][-1];assert e['number']==56
paths=[x['path'] for x in e['snapshotFiles']];assert all((r/p).resolve().is_relative_to((r/'docs/readmes/056').resolve()) for p in paths)
subprocess.run(['git','add','--','AGENTS.md','README.md','README-056.md','docs/DEVELOPMENT_LOG.md','docs/PROJECT_MEMORY.md','docs/JAVA_CHAT_044.md','docs/VALIDATION_056.json','docs/readmes/INDEX.md','docs/readmes/editions.json','docs/obsidian/64-measured-redesign.md','docs/obsidian/measured-redesign.canvas'],cwd=r,check=True)
for start in range(0,len(paths),50):subprocess.run(['git','add','-f','--',*paths[start:start+50]],cwd=r,check=True)
print('Staged complete frozen056 snapshot, including original XML and world checkpoints:',len(paths))
