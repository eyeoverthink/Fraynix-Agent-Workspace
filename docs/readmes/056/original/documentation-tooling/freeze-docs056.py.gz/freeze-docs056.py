from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).resolve().parent.parent;d=r/'docs/readmes/056'
def canon(p):return p.read_text(encoding='utf8').replace('\r\n','\n').encode()
snap=[]
for p in sorted(d.rglob('*')):
 if p.is_file():
  binary=p.suffix in ['.png','.jpg','.gz','.zip']
  snap.append({'path':p.relative_to(r).as_posix(),'kind':'binary' if binary else 'text','sha256':hashlib.sha256(p.read_bytes() if binary else canon(p)).hexdigest()})
p=r/'docs/readmes/editions.json';m=json.loads(p.read_text(encoding='utf8'));assert m['latest'] in [55,56]
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
e={'number':56,'date':'2026-11-03','title':'Measured load limits and verified redesign','status':'validated-local','markdown':'README-056.md','markdownSha256':hashlib.sha256(canon(r/'README-056.md')).hexdigest(),'companion':'docs/readmes/056/index.html','tag':'readme-056','sourceBaseline':source,'snapshotDirectory':'docs/readmes/056','snapshotFiles':snap}
m['editions']=[x for x in m['editions'] if x['number']!=56]+[e];m['latest']=56;p.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n',encoding='utf8');print('Frozen',len(snap),'new snapshot files; earlier entries unchanged')
