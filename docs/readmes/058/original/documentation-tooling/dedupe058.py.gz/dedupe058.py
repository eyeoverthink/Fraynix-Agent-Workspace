from pathlib import Path
import json,hashlib,gzip
r=Path(__file__).resolve().parent.parent;d=r/'docs/readmes/058';p=d/'original-evidence.json';m=json.loads(p.read_text(encoding='utf8'));unique={};deletions=[]
for row in m['files']:
 file=r/row['path'];b=file.read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256']
 key=row['sha256']
 if key not in unique:unique[key]=row
 else:
  kept=unique[key];assert (kept['rawBytes'],kept['rawSha256'])==(row['rawBytes'],row['rawSha256'])
  kept.setdefault('identicalOriginalSources',[]).append({'source':row['source'],'originalCaptureDestination':row['path']})
  assert file.resolve().is_relative_to(d.resolve()) and file.is_file();deletions.append(str(file.resolve()))
m['files']=list(unique.values());m['storage']='Byte-identical captures stored once; every source and original capture destination retained as aliases. No distinct original bytes removed.'
p.write_text(json.dumps(m,indent=2)+'\n',encoding='utf8');(r/'build/duplicate058-files.json').write_text(json.dumps(deletions),encoding='utf8');print('Duplicate generated copies:',len(deletions),'Unique originals:',len(unique))
