from pathlib import Path
import json,gzip,subprocess,re
r=Path(__file__).resolve().parent.parent
m=json.loads((r/'docs/readmes/editions.json').read_text(encoding='utf8'))
old=json.loads(subprocess.check_output(['git','show','38854e9:docs/readmes/editions.json'],cwd=r))
assert m['editions'][:57]==old['editions'] and m['latest']==58
value=json.loads(gzip.decompress((r/'docs/readmes/058/original/actual-app/agency-043/tasks.json.gz').read_bytes()))
found=[]
def scan(v,path=''):
 if isinstance(v,dict):
  for k,x in v.items():
   if k.lower() in {'authorization','apikey','api_key','password','secret','token','authtoken','accesstoken','nonce'} and x:found.append(path+'/'+k)
   scan(x,path+'/'+k)
 elif isinstance(v,list):
  for i,x in enumerate(v):scan(x,path+'/'+str(i))
 elif isinstance(v,str) and v.lstrip().startswith(('{','[')):
  try: nested=json.loads(v)
  except (ValueError,TypeError): return
  scan(nested,path+'/(encoded JSON)')
records=list((r/'docs/readmes/058/original').rglob('tasks.json.gz'))
for p in records:scan(json.loads(gzip.decompress(p.read_bytes())),p.relative_to(r).as_posix())
assert not found,found
secret_files=[]
secret_re=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|sk-proj-[A-Za-z0-9_-]{30,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----)')
for p in (r/'docs/readmes/058').rglob('*'):
 if p.is_file() and p.suffix in ['.gz','.json','.log','.md','.html']:
  b=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()
  if secret_re.search(b):secret_files.append(p.relative_to(r).as_posix())
assert not secret_files,secret_files
assert '{{MEASURED_RESULTS}}' not in (r/'README-058.md').read_text(encoding='utf8') and '{{SCREENSHOTS}}' not in (r/'README-058.md').read_text(encoding='utf8')
new=[p for p in (r/'docs/readmes/058').rglob('*') if p.is_file()]
assert max(p.stat().st_size for p in new)<100_000_000
result={'passed':True,'priorManifestEntriesExact':57,'credentialKeyScan':'No credential-bearing keys found in original final/development chat records, including encoded JSON strings','chatRecordsScanned':len(records),'newSnapshotFiles':len(new),'largestFileBytes':max(p.stat().st_size for p in new)}
(r/'build/preflight058.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result))
