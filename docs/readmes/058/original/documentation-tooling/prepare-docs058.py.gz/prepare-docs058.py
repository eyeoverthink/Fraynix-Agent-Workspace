from pathlib import Path
import json,hashlib,re,subprocess,shutil,gzip,datetime,xml.etree.ElementTree as ET,html

r=Path(__file__).resolve().parent.parent;d=r/'docs/readmes/058';out=r/'workspace-desktop/test-output';d.mkdir(exist_ok=True)
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
live=json.loads((out/'construction058-live.json').read_text(encoding='utf-8'));assert live['passed'];source=live['source']
shots=[('stock','Labelled synthetic stock before assembly'),('review','Measured baseline failure and a decision awaiting review'),('results','Fresh design and unfamiliar payload results'),('report','Verified phase comparison and source identities'),('replay','Recorded motion of the unfamiliar heavy payload'),('chat','Actual local-model task and retained skill'),('compact','Compact geometry and narrow application layout')]
shots=[('construction058-'+name+'.png',title) for name,title in shots]
for name,_ in shots:shutil.copyfile(out/name,d/name)
shutil.copyfile(out/'construction058-live.json',d/'desktop-live.json')
archives=[];seen=set();roots=set()
def pack(p,dest):
 if len(str(dest))>=235:dest=d/'original/long-path-records'/(sha(dest.relative_to(d).as_posix().encode())+'.gz')
 if dest in seen:return
 seen.add(dest);b=p.read_bytes();z=gzip.compress(b,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archives.append({'path':dest.relative_to(r).as_posix(),'bytes':len(z),'sha256':sha(z),'rawBytes':len(b),'rawSha256':sha(b),'source':str(p),'format':'gzip of original bytes'})
invocations=[];cases={}
for base in sorted((r/'build').glob('native058-*')):
 src=(base/'source.txt').read_text(encoding='utf-8-sig').strip();rows=[]
 for p in sorted(base.rglob('TEST-*.xml')):
  tree=ET.parse(p).getroot()
  for c in tree.findall('testcase'):rows.append({'case':c.attrib['classname']+'#'+c.attrib['name'],'passed':c.find('failure') is None and c.find('error') is None and c.find('skipped') is None,'seconds':float(c.attrib['time'])})
  for match in re.findall(r'C:\\Users\\eyeka\\AppData\\Local\\Temp\\[^\s<]+',p.read_text(encoding='utf-8')):
   path=Path(match.strip())
   if path.is_dir():roots.add(path)
  pack(p,d/'java'/base.name/(p.name+'.gz'))
 v={'label':base.name,'source':src,'count':len(rows),'failures':sum(not x['passed'] for x in rows),'cases':rows};invocations.append(v);js(d/(base.name+'.json'),v)
 for row in rows:cases.setdefault(row['case'],[]).append(row)
 for p in base.glob('*.log'):pack(p,d/'java'/base.name/(p.name+'.gz'))
passed=[k for k,rows in cases.items() if any(x['passed'] for x in rows)];classes={x.split('#')[0] for x in passed}
for p in sorted((r/'build').glob('test058*.log')):pack(p,d/'logs'/(p.name+'.gz'))
for p in sorted((r/'build').glob('*058.*')):
 if p.suffix in ['.py','.cjs']:pack(p,d/'original/documentation-tooling'/(p.name+'.gz'))
def project(base,label):
 for p in base.rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(base).as_posix()
  if p.name in ['state.json','studies.json','tasks.json','tasks.fworld','results.json','summary.json','result.json','original.json','test-desktop-process.log','engine.log','evaluation-summary.json','design-summary.json','all-originals.json','partial-originals.json','fresh-assembly.json'] or p.name.endswith('-original.json') or ('payload-058/' in rel or 'evaluation/' in rel or 'loads/' in rel or rel.startswith('exports/')) and p.suffix in ['.json','.jsonl','.bin'] or ('checkpoints/' in rel or rel.startswith('receipts/')) and p.suffix=='.json' or p.name.endswith('.pending'):pack(p,d/'original'/label/(rel+'.gz'))
project(Path(live['project']),'actual-app')
for root in sorted(roots):project(root,'native/'+root.name)
for p in sorted(out.glob('construction058-*.json')):pack(p,d/'original/exports'/(p.name+'.gz'))
failures=[]
for p in sorted(out.glob('construction058-failed-*.json')):
 v=json.loads(p.read_text(encoding='utf-8'));failures.append({'record':p.name,'source':v['source'],'error':v['error'],'project':v['project']})
 if Path(v['project'])!=Path(live['project']):project(Path(v['project']),p.stem)
for base in sorted((r/'build').glob('ui058-*')):
 for p in base.rglob('*'):
  if p.is_file():pack(p,d/'original/development-ui'/base.name/(p.relative_to(base).as_posix()+'.gz'))
timing={}
for key in ['chat','reused']:
 t=live[key];start=datetime.datetime.fromisoformat(t['createdAt']);end=datetime.datetime.fromisoformat(t.get('finishedAt',t['history'][-1]['at']))
 timing[key]={'wallSeconds':(end-start).total_seconds(),'endBasis':'finishedAt or last terminal history event','status':t['status'],'timing052':t.get('timing052',{}),'planningCalls':sum(h['kind']=='plan' for h in t['history']),'repairs':[h['detail'] for h in t['history'] if h['kind']=='repair'],'source':live.get(key+'Source',source)}
goals={'wide':live['first'],'changedCentre':live['chat']['completion044']['javaGoal'],'compact':live['compactGoal']}
results={name:g.get('payload057',{}) for name,g in goals.items()}
v={'edition':58,'date':'2026-11-03','source':source,'runtimeComponents':{'nativeFirst':'4ab6a9c','installedJava':(r/'build/install-source058.txt').read_text(encoding='utf-8').strip(),'actualPhases':{k:live.get(k+'Source',source) for k in ['first','chat','reused']}},'passed':True,'javaCount':len(passed),'javaSuites':len(classes),'javaInvocations':invocations,'javaScope':'Distinct targeted passing cases across source-qualified invocations; not a single full-suite run. Original attempts and any development failures remain archived.','desktopUnitTests':125,'integration':live['checks'],'timing':timing,'developmentFailures':failures,'results':results,'goalStatus':{name:{k:g.get(k) for k in ['status','reason','worldCommit','savedSkill']} for name,g in goals.items()},'sourceProjects':[str(p) for p in sorted(roots)],'continuations':live.get('continuations',[]),'desktopReopenObservations':live.get('opens',[]),'scope':'Predeclared same-stock native rigid-body redesign and paired reserved payload cases. Reserved conditions excluded from selection. Deterministic repeats are not independent physical trials. No material-strength, hardware, general learning or model-weight-training claim.'}
js(d/'verification.json',v);js(r/'docs/VALIDATION_058.json',v);js(d/'original-evidence.json',{'scope':'Complete original synthetic native attempts, contacts, decisions, interruptions and source-qualified development failures. Private mat/camera data excluded.','files':archives})
first=results['wide'];groups={g['phase']:g['summary'] for g in first['groups']};baseline=groups['baseline-reserved'];selected=groups['selected-reserved']
table='| Reserved payload | Original layout | Selected fresh layout | Original movement m | Selected movement m |\n| --- | --- | --- | ---: | ---: |\n'
for a,b in zip(baseline['results'],selected['results']):table+='| '+a['caseId']+' | '+('Stable' if a['metrics']['stable'] else '**Unstable**')+' | '+('Stable' if b['metrics']['stable'] else '**Unstable**')+f" | {a['metrics']['maxBeamDisplacementM']:.6f} | {b['metrics']['maxBeamDisplacementM']:.6f} |\n"
table+='\nThe original 0.8 m spacing failed the edge-force design cases. The selected wider layout used a 1.395 m span, preserving the same parts and limits. Its decision was fixed before reserved evaluation. Every case was repeated.\n\n'
table+=f"**{len(passed)} distinct targeted Java cases across {len(classes)} classes**, **125 desktop checks**, and the actual app/local-model workflow pass with source-qualified evidence. The changed-centre chat took **{timing['chat']['wallSeconds']:.3f} seconds**; compact saved-skill reuse ended **{timing['reused']['status']}** after **{timing['reused']['wallSeconds']:.3f} seconds**. These are complete task observations, including computation, persistence and verification; not model-only latency.\n\n"
for name,g in goals.items():
 data=g.get('payload057');table+=f"- **{name}:** {g['status']}. "
 if data:table+=f"Fresh design passed: {data['freshDesignPassed']}; selected reserved passed: {data['selectedReservedPassed']}. {data['attempts']} payload attempts, {data['totalTicks']} design/reserved ticks and {data['completeTaskTicks']} total recorded native ticks."
 else:table+=g.get('reason','No completed evaluation')+' No successful world or skill promotion.'
 table+='\n'
s=(r/'README-058.md').read_text(encoding='utf-8');assert '{{MEASURED_RESULTS}}' in s and '{{SCREENSHOTS}}' in s
screens='\n\n'.join(f'### {title}\n\n![{title}](docs/readmes/058/{name})\n\nNovember 3, 2026 · actual app capture · labelled synthetic practice scene. [Original image](docs/readmes/058/{name}).' for name,title in shots)
write(r/'README-058.md',s.replace('{{MEASURED_RESULTS}}',table).replace('{{SCREENSHOTS}}',screens))
note='docs/obsidian/66-payload-redesign.md';write(r/note,'# Measured failure, redesign and unfamiliar payloads\n\nJava selects support spacing using measured design failures, pins its decision, executes freshly and evaluates reserved payloads on both baseline and selected construction. Original evidence, negative outcomes and exact procedural policy remain retained.\n\n- [[README-058]]\n- [[docs/EDITION_058_CONTRACT]]\n- [[docs/obsidian/65-dynamic-payloads]]\n\nNext: richer finite repair choices with declared material/action costs and newly reserved conditions.\n')
modules=[('decision','Design-only decision','Measured failures admit the next declared support layout; reserved outcomes cannot select it.','workspace-engine/src/main/java/fraymus/workspace/Design058.java','Verified'),('series','Original native series','Design and reserved payload cases share actual integration and retain all attempts.','workspace-engine/src/main/java/fraymus/workspace/PayloadSeries058.java','Verified'),('goal','Java goal and exact skill','Fresh execution, paired evaluation, original report and promotion gates.','workspace-engine/src/main/java/fraymus/workspace/GoalRunner.java','Verified'),('report','Verified phase report','Actual tables, curves and replay checked against original records.','workspace-engine/src/main/java/fraymus/workspace/PayloadReport057.java','Verified'),('view','Integrated controls and chat','Visible example, local-model task, saved policy and original export.','workspace-desktop/renderer/construction051.js','Actual app verified'),('next','Richer repair space','Finite stock, asymmetric supports and newly reserved disturbances with full costs.','docs/EDITION_058_CONTRACT.md','Planned')]
data={'edition':58,'modules':[dict(id=i,name=n,summary=s,source=p,status=status,note=note) for i,n,s,p,status in modules],'screenshots':[{'path':'docs/readmes/058/'+name,'title':title+' · November 3, 2026 · synthetic practice world'} for name,title in shots],'evidence':[{'path':'docs/readmes/058/verification.json','title':'Source-qualified results'},{'path':'docs/readmes/058/original-evidence.json','title':'Original evidence and failures'}]};js(d/'system-map.json',data)
paths={x['path'] for x in json.loads((r/'docs/readmes/057/file-inventory.json').read_text(encoding='utf-8'))};new=subprocess.check_output(['git','diff','--name-only','--diff-filter=A','38854e9','HEAD'],cwd=r,text=True).splitlines();paths.update(p for p in new if p.startswith(('workspace-engine/','workspace-desktop/')))
inventory=[]
for name in sorted(paths):
 b=(r/name).read_bytes()
 try:b=b.decode('utf-8').replace('\r\n','\n').encode();kind='utf8-lf'
 except UnicodeDecodeError:kind='binary'
 inventory.append({'path':name,'bytes':len(b),'hashKind':kind,'sha256':sha(b)})
js(d/'file-inventory.json',inventory);write(d/'FILE_TREE.md','# Edition 058 source tree\n\n```text\n'+'\n'.join(sorted(paths))+'\n```\n')
old=(r/'docs/readmes/057/index.html').read_text(encoding='utf-8');css=re.search(r'<style>(.*?)</style>',old,re.S)[1];script=old[old.index('<script>'):old.index('</script>',old.index('<script>'))+9]
body='<header><small>FRAYNIX AGENT WORKSPACE · EDITION 058 · NOVEMBER 3, 2026</small><h1>Measure. Redesign. Test the unfamiliar.</h1><p>Same stock. Preserved failures. A decision fixed before reserved evaluation.</p><nav aria-label="Guide links"><a href="#walkthrough">Walkthrough</a><a href="#features">System map</a><a href="#captures">Actual screenshots</a><a href="#sources">Source inventory</a><a href="../../../README-058.md">Full README</a><a href="../057/index.html">Previous edition</a></nav></header><section id="walkthrough"><h2>Follow the actual task</h2><ol><li>Spatial → Gripper assembly → Failure → redesign → new payloads.</li><li>Java tests the original spacing and admits a wider layout only after measured design failure.</li><li>Review the saved decision before execution; restart preserves it.</li><li>Fresh construction repeats design checks before unfamiliar payloads are evaluated.</li><li>Compare original and selected reserved outcomes in the verified report.</li><li>Export all originals; reuse the exact skill on new geometry with fresh evidence.</li></ol><p>Virtual rigid bodies; no material-strength or model-weight-training claim.</p><p><a href="verification.json">Validation and complete costs</a> · <a href="original-evidence.json">Original evidence</a> · <a href="../../EDITION_058_CONTRACT.md">Frozen contract</a></p></section><section id="results"><h2>Paired unfamiliar payload results</h2><div class="results-table"><table id="results058"><thead><tr><th>Case</th><th>Original</th><th>Selected</th></tr></thead><tbody>'
for a,b in zip(baseline['results'],selected['results']):body+='<tr><td>'+html.escape(a['caseId'])+'</td><td>'+('Stable' if a['metrics']['stable'] else 'Unstable')+'</td><td>'+('Stable' if b['metrics']['stable'] else 'Unstable')+'</td></tr>'
body+='</tbody></table></div></section><section id="features"><h2>System map and next phases</h2><label for="feature-search">Find a component</label><input id="feature-search" type="search" placeholder="Try decision, Java or planned"><ul id="map"></ul></section><section id="captures"><h2>Actual application screenshots</h2><div id="gallery"></div></section><section id="sources"><h2>Source paths</h2><label for="file-search">Filter the inventory</label><input id="file-search" type="search" placeholder="Try Design058.java"><p id="file-count" aria-live="polite"></p><ul id="file-list"></ul><a href="FILE_TREE.md">Full source tree</a></section>'
write(d/'index.html','<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fraynix 058 · Measured redesign</title><style>'+css+'</style></head><body><main>'+body+'</main><script id="system-data" type="application/json">'+json.dumps(data)+'</script><script id="inventory-data" type="application/json">'+json.dumps(inventory)+'</script>'+script+'</body></html>\n')
nodes=[{'id':i,'type':'file','file':p,'x':(k%3)*410,'y':(k//3)*240,'width':380,'height':190} for k,(i,n,s,p,status) in enumerate(modules)];js(r/'docs/obsidian/payload-redesign.canvas',{'nodes':nodes,'edges':[{'id':'e'+str(k),'fromNode':nodes[k]['id'],'fromSide':'right','toNode':nodes[k+1]['id'],'toSide':'left'} for k in range(len(nodes)-1)]})
p=r/'README.md';s=p.read_text(encoding='utf-8');s=re.sub(r'> \*\*\[Edition057.*','> **[Edition 058 · Measured failure, redesign and unfamiliar payloads](README-058.md)** · [Offline guide](docs/readmes/058/index.html) · [Operation](docs/JAVA_CHAT_044.md) · [Edition history](docs/readmes/INDEX.md)',s,count=1);s=s.replace('Edition057 tests actual falling payloads and new force positions, preserves failures and verifies recorded motion before completion. [Measured results and originals](docs/readmes/057/verification.json).','Edition 058 selects a repair from measured failures, then tests unfamiliar payloads under a fixed decision. [Measured results and originals](docs/readmes/058/verification.json).');write(p,s)
p=r/'docs/readmes/INDEX.md';s=p.read_text(encoding='utf-8');write(p,s.replace('\nLatest implementation','\n| [058](../../README-058.md) | 2026-11-03 | Measured redesign and unfamiliar payloads | [Viewer](058/index.html) · [tree](058/FILE_TREE.md) |\n\nLatest implementation').replace('is **057**','is **058**'))
p=r/'docs/JAVA_CHAT_044.md';write(p,p.read_text(encoding='utf-8')+'\n\n## Failure-driven payload redesign 058\n\nSpatial → Gripper assembly → Failure → redesign → new payloads creates labelled stock. Chat can request redesign from measured failures and unfamiliar payloads. Java freezes a decision from design cases, executes freshly and compares original/selected reserved payloads before promotion. Saved procedures retain the exact policy. Report, replay and exports preserve failed and interrupted attempts. [Edition 058 walkthrough](../README-058.md).\n')
entry=f'\n\n## Edition 058 · Validated locally; publication audit next\n\nActual app source `{source}`. Frozen design-only selection, fresh execution and paired reserved payloads checked. {len(passed)} targeted Java cases across {len(classes)} classes,125 desktop checks and actual CPU/four-thread local-model chat/reuse with complete originals. See validation058 for source-qualified invocations and contrary outcomes. New README058, seven actual screenshots, offline guide and Obsidian map prepared. No material-strength or model-weight-training claim.\n\nActual main/edition058/readme-058 push and fresh fetched audit remain pending. Preserve normal045/qa046 installed runtimes/private data, dependency junction053 and immutable001–057. Next: richer finite repair choices with predeclared costs and newly reserved conditions.\n'
for name in ['AGENTS.md','docs/PROJECT_MEMORY.md','docs/DEVELOPMENT_LOG.md']:
 p=r/name;s=p.read_text(encoding='utf-8');i=s.index('\n');write(p,s[:i]+entry+s[i:])
print(json.dumps({'sourceFiles':len(inventory),'java':len(passed),'classes':len(classes),'archives':len(archives),'timing':timing}))
