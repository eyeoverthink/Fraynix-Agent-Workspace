$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$env:JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=4'
if(!(Test-Path -LiteralPath 'build/legacy064-restore')){Copy-Item -LiteralPath '../fraynix-workspace-edition070/build/legacy064-restore' -Destination 'build/legacy064-restore' -Recurse}
$env:FRAYNIX064_NATIVE_RESUME=(Resolve-Path 'build/legacy064-restore').Path
New-Item -ItemType Directory -Path build/regression072 -Force | Out-Null
git rev-parse HEAD | Set-Content -Encoding utf8 build/regression072/source.txt
$regression072Args=@(':workspace-engine:test')
foreach($class in @('BrainPayload064Test','Agent042Test','BrainPersistenceTest','BrainServiceTest','ChatChain052Test','Domain044Test','StoppingContext063Test','Contact064Test','RecoveryCompatibility066Test','TemporalCompatibility067Test','CalibrationCompatibility068Test','LaterCompatibility069Test','AdaptiveCompatibility070Test','UncertainCompatibility071Test','CalibrationChat068Test','UsefulObservation072Test','UsefulCompatibility072Test','WorldCheckpoint071Test','ProceduralTest')){$regression072Args+=@('--tests',"*$class")}
foreach($name in @('publishedCalibrationIsExactAndRecomputed','policyFitsIntervalsAndSharesDomainFence','utilityCountsMissesAndRefusalsWithoutInventingEndpoints','gateRequiresBothComparisonsAndRealTaskSuccess','planningTablesRetainEveryMetricAndLeaveOriginalsUntouched','freshPartitionsHaveNoOldNativeDefinitions')){$regression072Args+=@('--tests',"*Decision065Test.$name")}
foreach($name in @('initialPoliciesRetainOldChoicesAndRefusalDomain','inverseAndBoundsUseOnlyTheSelectedState','attemptedRecoveryPaysForFailuresAndEveryUsedOperation','qualificationRequiresObservationBenefitCompletionAndRecovery','freshTasksAndLosslessContextRetainSubgroupsAndNulls')){$regression072Args+=@('--tests',"*Recovery066Test.$name")}
foreach($name in @('temporalEvidenceHandlesDropoutButRefusesLostOrUnsafeSupport','contextIsLosslessAndFutureMotionCannotChangePlanning','initialChoicesAreCompatibleAndScreenIsProspective','costsIncludeThreeObservationsAndDeclinedScreens','qualificationKeepsAllComparisonsAndFailureLimits')){$regression072Args+=@('--tests',"*Temporal067Test.$name")}
foreach($name in @('lateInverseHonorsBudgetGuardAndNoActionWhenAlreadyFits','lateWindowChecksAllSamplesAndRejectsFuture','casesAreNewBalancedAndFrozenModelIsExact','feesIncludeFailedAttemptAndEveryLaterObservation','gateRejectsAddedCostsHarmsAndLateFailures')){$regression072Args+=@('--tests',"*Later069Test.$name")}
foreach($name in @('signedPhysicsStopsSticksAndRestartsDownhill','eventBoundaryIsAppliedExactlyOnce','scheduleHasNoFutureInputAndUsesOnlyPaidFirstState','selectedWindowsRejectFutureAndUnsafeEvidence','newCasesPreserveFirstChoicesAndBalanceTiming','skipPaysSchedulerButNoExtraSensingAndFailureStillCounts','qualificationRequiresSensingSavingsAndPreservesLateMisses')){$regression072Args+=@('--tests',"*Adaptive070Test.$name")}
$regression072Args+=@(':workspace-engine:installDist'  ,'verifySourceIsolation','--no-daemon','--max-workers=1','-I','build/validation072.init.gradle')
& ./gradlew.bat @regression072Args *> build/regression072/regression.log
$regression072Exit=$LASTEXITCODE
Copy-Item workspace-engine/build/test-results/test/TEST-*.xml build/regression072
Get-Content build/regression072/regression.log -Tail 25
exit $regression072Exit
