from pathlib import Path
r=Path('workspace-engine/src/main/java/fraymus/workspace')
def write(n,s): (r/n).write_text(s,encoding='utf8')
def edit(s,a,b):
 assert a in s,a
 return s.replace(a,b)
s=(r/'UncertainTrial071.java').read_text(encoding='utf8').replace('UncertainTrial071','UsefulTrial072').replace('UncertainPolicy071','UsefulPolicy072').replace('schedule071','schedule072').replace('timing071','timing072').replace('uncertain-observation-native-071-v1','useful-observation-native-072-v1')
s=edit(s,'UsefulPolicy072.class,Uncertainty071.class','UsefulPolicy072.class,StateUncertainty072.class,ObservationValue072.class,Uncertainty071.class,UncertainTrial071.class')
s=s.replace('decision.getString("method").equals("uncertain")','Set.of("uncertain","simple","useful").contains(decision.getString("method"))')
s=s.replace('Uncertainty071.verify(model)','StateUncertainty072.verify(model)').replace('Uncertainty071.verify(r.getJSONObject("uncertaintyModel"))','StateUncertainty072.verify(r.getJSONObject("uncertaintyModel"))')
s=s.replace('Set.of("blind","fixed","adaptive","uncertain")','Set.of("blind","adaptive","uncertain","simple","useful")')
start=s.index('    static JSONObject schedule(');end=s.index('    static void verify(',start)
s=s[:start]+'''    static JSONObject schedule(JSONObject task,JSONObject decision,JSONObject first,JSONObject models){
        return switch(decision.getString("method")){
            case "uncertain" -> Uncertainty071.schedule(task,decision,first,models.getJSONObject("distance"));
            case "simple","useful" -> ObservationValue072.plan(task,decision,first,models,decision.getString("method").equals("simple"));
            default -> ObservationSchedule070.plan(task,decision,first);
        };
    }
'''+s[end:]
write('UsefulTrial072.java',s)
s=(r/'UncertainPolicy071.java').read_text(encoding='utf8').replace('UncertainPolicy071','UsefulPolicy072').replace('timing071','timing072').replace('pairedUncertainMinus','pairedUsefulMinus')
s=edit(s,'List.of("blind","fixed","adaptive","uncertain")','List.of("blind","adaptive","uncertain","simple","useful")')
s=s.replace('Set.of("adaptive","uncertain")','Set.of("adaptive","uncertain","simple","useful")')
s=s.replace('decision.getString("method").equals("uncertain")','Set.of("uncertain","simple","useful").contains(decision.getString("method"))')
s=s.replace('method.equals("uncertain")?executions:0','Set.of("uncertain","simple","useful").contains(method)?executions:0')
s=s.replace('List.of("blind","fixed","adaptive")','List.of("blind","adaptive","uncertain","simple")').replace('r.getJSONObject("uncertain").getJSONObject("outcome")','r.getJSONObject("useful").getJSONObject("outcome")')
write('UsefulPolicy072.java',s)
s=(r/'UncertainStudy071.java').read_text(encoding='utf8').replace('UncertainStudy071','UsefulStudy072').replace('UncertainTrial071','UsefulTrial072').replace('UncertainPolicy071','UsefulPolicy072').replace('071','072').replace('7100','7200').replace('TOTAL=546','TOTAL=666').replace('uncertain-observation-072-v1','useful-observation-072-v1')
# Label fitting remains on the unmodified distance-only071 executor.
s=s.replace('Uncertainty072.cell','Uncertainty071.cell').replace('Uncertainty072.CELLS','Uncertainty071.CELLS').replace('Uncertainty072.fit','StateUncertainty072.fit').replace('Uncertainty072.coverage','StateUncertainty072.coverage')
start=s.index(' static JSONObject oldDecision(');end=s.index(' static JSONObject coverage(',start)
s=s[:start]+''' static JSONObject oldDecision(JSONObject task,String method){return UncertainPolicy071.initial(task).getJSONObject("decisions").getJSONObject(method);}
 static double parity(JSONObject old,JSONObject now){
  UncertainTrial071.verify(old);UsefulTrial072.verify(now);double delta=AdaptiveStudy070.compareSamples(old,now,45);
  for(String key:List.of("correctionPlan","laterPlan"))if(old.has(key)!=now.has(key)||old.has(key)&&!old.getJSONObject(key).similar(now.getJSONObject(key)))throw new IllegalStateException("Original071 plan changed");
  if(old.has("schedule071")&&!old.getJSONObject("schedule071").similar(now.getJSONObject("schedule072")))throw new IllegalStateException("Original071 scheduler changed");return delta;
 }
'''+s[end:]
s=s.replace('List.of("blind","fixed","adaptive")','List.of("blind","adaptive","uncertain")')
start=s.index(' static JSONObject coverage(');end=s.index(' static void advance(',start)
s=s[:start]+''' static JSONObject coverage(JSONArray rows){
  int count=0,joint=0,distance=0,end=0;double width=0,speedWidth=0;var cells=new JSONObject();
  for(String cell:Uncertainty071.CELLS)cells.put(cell,new JSONObject().put("count",0).put("jointCovered",0).put("distanceCovered",0).put("terminalCovered",0));
  for(Object raw:rows){var row=(JSONObject)raw;if(!row.has("coverage072"))continue;var c=row.getJSONObject("coverage072");count++;boolean j=c.getBoolean("jointCovered"),d=c.getBoolean("distanceCovered"),e=c.getBoolean("terminalCovered");if(j)joint++;if(d)distance++;if(e)end++;width+=c.getDouble("terminalWidthM");speedWidth+=c.getDouble("terminalSpeedWidthMps");var cell=cells.getJSONObject(c.getString("cell"));cell.put("count",cell.getInt("count")+1).put("jointCovered",cell.getInt("jointCovered")+(j?1:0)).put("distanceCovered",cell.getInt("distanceCovered")+(d?1:0)).put("terminalCovered",cell.getInt("terminalCovered")+(e?1:0));}
  return new JSONObject().put("count",count).put("jointCovered",joint).put("distanceCovered",distance).put("terminalCovered",end).put("jointCoverage",count==0?JSONObject.NULL:joint/(double)count).put("distanceCoverage",count==0?JSONObject.NULL:distance/(double)count).put("terminalCoverage",count==0?JSONObject.NULL:end/(double)count).put("meanTerminalWidthM",count==0?JSONObject.NULL:width/count).put("meanTerminalSpeedWidthMps",count==0?JSONObject.NULL:speedWidth/count).put("cells",cells).put("truth","Paired blind future, four position and four speed quantities");
 }
 static JSONObject evaluation(JSONArray rows,String phase){
  var out=UsefulPolicy072.evaluate(rows,true);double prefix=0;int suppressed=0,forced=0,retimed=0,looks=0,skips=0,corrections=0;var choices=new JSONObject().put("skip",0).put("92",0).put("116",0).put("140",0);var pairs=new JSONObject();for(String m:List.of("blind","adaptive","uncertain","simple"))pairs.put(m,new JSONObject().put("saved",0).put("harmed",0));var reasons=new JSONObject();
  for(Object raw:rows){var row=(JSONObject)raw;var rs=row.getJSONObject("results");if(!rs.getJSONObject("blind").has("record"))continue;var blind=rs.getJSONObject("blind").getJSONObject("record");for(String m:UsefulPolicy072.METHODS)prefix=Math.max(prefix,AdaptiveStudy070.prefixParity(blind,rs.getJSONObject(m).getJSONObject("record")));
   var rec=rs.getJSONObject("useful").getJSONObject("record");int tick=rec.getJSONObject("schedule072").getInt("selectedTick"),old=rs.getJSONObject("uncertain").getJSONObject("record").getJSONObject("schedule072").getInt("selectedTick");if(tick<0)skips++;else looks++;if(old>0&&tick<0)suppressed++;if(old<0&&tick>0)forced++;if(old>0&&tick>0&&old!=tick)retimed++;String key=tick<0?"skip":Integer.toString(tick);choices.put(key,choices.getInt(key)+1);if(rec.has("laterReceipt"))corrections++;if(rec.has("laterPlan")){String reason=rec.getJSONObject("laterPlan").getString("reason");reasons.put(reason,reasons.optInt(reason)+1);}
   boolean current=rs.getJSONObject("useful").getJSONObject("outcome").getBoolean("success");for(String m:pairs.keySet()){boolean previous=rs.getJSONObject(m).getJSONObject("outcome").getBoolean("success");var p=pairs.getJSONObject(m);if(current&&!previous)p.put("saved",p.getInt("saved")+1);if(previous&&!current)p.put("harmed",p.getInt("harmed")+1);}
  }
  out.put("diagnostics",new JSONObject().put("suppressedLooks",suppressed).put("forcedLooks",forced).put("retimedLooks",retimed).put("looks",looks).put("skips",skips).put("actualCorrections",corrections).put("correctionReasons",reasons).put("goals",pairs).put("choices",choices).put("prefixMaximumDelta",prefix)).put("coverage",coverage(rows)).put("phase",phase);
  var groups=new JSONObject();for(String name:List.of("accelerating","slowing","predicted","measured","brake","lift","push","spin","after-last")){var subset=new JSONArray();for(Object raw:rows){var row=(JSONObject)raw;boolean match=switch(name){case "accelerating"->row.getJSONObject("task").getDouble("frictionRatio")<1;case "slowing"->row.getJSONObject("task").getDouble("frictionRatio")>1;case "predicted"->!row.getJSONObject("plan").getJSONObject("decisions").getJSONObject("blind").getBoolean("recover");case "measured"->row.getJSONObject("plan").getJSONObject("decisions").getJSONObject("blind").getBoolean("recover");default->row.getString("disturbance").equals(name);};if(match)subset.put(row);}if(!subset.isEmpty())groups.put(name,UsefulPolicy072.evaluate(subset,false).put("coverage",coverage(subset)));}
  return out.put("subgroups",groups).put("qualified",qualifies(out,phase));
 }
 static boolean qualifies(JSONObject e,String phase){
  if(!Set.of("clean","disturbed").contains(phase))return false;boolean clean=phase.equals("clean");var m=e.getJSONObject("methods");var u=m.getJSONObject("useful");
  for(String other:List.of("adaptive","uncertain","simple")){var o=m.getJSONObject(other);double gain=e.getJSONObject("pairedUsefulMinus").getJSONObject(other).getDouble("meanDelta");if(u.getInt("successes")<o.getInt("successes")-(clean?0:1)||gain<(clean?(other.equals("uncertain")?.005:0):-.03)-1e-12)return false;}
  return !clean||e.getJSONObject("coverage").getDouble("jointCoverage")>=.85-1e-12;
 }
 static boolean qualified(JSONObject job){int looks=0,skip=0,saved=0,used=0,old=0;for(String phase:List.of("clean","disturbed")){var e=job.getJSONObject(phase+"Evaluation072");if(!e.getBoolean("qualified"))return false;var d=e.getJSONObject("diagnostics");looks+=d.getInt("looks");skip+=d.getInt("skips");saved+=d.getJSONObject("goals").getJSONObject("blind").getInt("saved");used+=e.getJSONObject("methods").getJSONObject("useful").getInt("extraObservations");old+=e.getJSONObject("methods").getJSONObject("uncertain").getInt("extraObservations");}return looks>0&&skip>0&&saved>0&&used<old;}
 static JSONObject trainingCosts(JSONObject job){double utility=0,cost=.08,ms=0;int observations=0,actions=0,misses=0;for(String phase:List.of("fit","calibration"))for(Object raw:job.getJSONArray(phase+"072")){var o=((JSONObject)raw).getJSONObject("outcome");utility+=o.getDouble("utility")-.245;cost+=o.getDouble("logicalCost")+.245;observations+=o.getInt("observations");actions+=o.getInt("actions");if(!o.getBoolean("success"))misses++;ms+=o.getDouble("nativeWallMillis");}return new JSONObject().put("runs",60).put("misses",misses).put("actions",actions).put("controllerObservations",observations).put("labelSampleTimes",240).put("labelScalars",480).put("logicalCost",cost).put("utility",utility-.08).put("nativeWallMillis",ms).put("fitAndCalibrationMillis",job.getDouble("fitMillis072")).put("scope","Original blind operations/misses plus eight scalar labels at .03 and .005 residual calculation each run; total fixed fitting/calibration .08. Label units are accounting assumptions; not extra sensor frames.");}
'''+s[end:]
# Specific execution substitutions; no changing the legacy classes.
s=s.replace('var record=UsefulTrial072.run(t,d,AdaptiveRamp070.event("none",0,0),dir,cancel,partial->','var record=UncertainTrial071.run(t,d,AdaptiveRamp070.event("none",0,0),dir,cancel,partial->')
s=s.replace('row.put("record",record).put("outcome",UsefulPolicy072.outcome(t,d,record)','row.put("record",record).put("outcome",UncertainPolicy071.outcome(t,d,record)')
s=s.replace('var old=AdaptiveTrial070.run(t,oldDecision(t,m),AdaptiveRamp070.event("none",0,0),dir,cancel,partial->{});','var old=UncertainTrial071.run(t,oldDecision(t,m),AdaptiveRamp070.event("none",0,0),dir,cancel,partial->{},m.equals("uncertain")?job.getJSONObject("model072").getJSONObject("distance"):null);')
s=s.replace('dir,cancel,partial->{},null);job.getJSONArray("parity072")','dir,cancel,partial->{},m.equals("uncertain")?job.getJSONObject("model072"):null);job.getJSONArray("parity072")')
s=s.replace('method.equals("uncertain")?job.getJSONObject("model072"):null','Set.of("uncertain","simple","useful").contains(method)?job.getJSONObject("model072"):null')
s=s.replace('if(method.equals("uncertain")&&!rec.getJSONObject','if(Set.of("uncertain","simple","useful").contains(method)&&!rec.getJSONObject')
s=s.replace('boundRecord(rec,t,d,AdaptiveRamp070.event("none",0,0),Instant.parse(row.getString("plannedAt")),ids);','boundTraining(rec,t,d,Instant.parse(row.getString("plannedAt")),ids);')
s=s.replace('!UsefulPolicy072.outcome(t,d,rec).similar(row.getJSONObject("outcome"))','!UncertainPolicy071.outcome(t,d,rec).similar(row.getJSONObject("outcome"))')
idx=s.index(' static void boundRecord(')
s=s[:idx]+''' static void boundTraining(JSONObject record,JSONObject task,JSONObject decision,Instant planned,Set<String> ids){UncertainTrial071.verify(record);if(!record.getJSONObject("task").similar(task)||!record.getJSONObject("decision").similar(decision)||!record.getJSONObject("disturbance").similar(AdaptiveRamp070.event("none",0,0))||Instant.parse(record.getString("startedAt")).isBefore(planned)||!ids.add(record.getString("id")))throw new IllegalStateException("Training source binding differs");}
'''+s[idx:]
s=s.replace('  if(!manifest().similar(job.getJSONObject("manifest072")))','  for(String phase:List.of("fit","calibration","clean","disturbed","unsupported"))for(Object raw:Set.of("fit","calibration").contains(phase)?UncertainStudy071.training(phase):UncertainStudy071.cases(phase))oldTuples.add(WorldFrames.hash(((JSONObject)raw).getJSONObject("task")));\n  for(String phase:List.of("fit","calibration","clean","disturbed","unsupported"))for(Object raw:job.getJSONArray(phase+"072"))if(oldTuples.contains(WorldFrames.hash(((JSONObject)raw).getJSONObject("task"))))throw new IllegalStateException("Published task reused");\n  if(!manifest().similar(job.getJSONObject("manifest072")))')
s=s.replace('job.getJSONObject("model072").getString("sha256")','job.getJSONObject("model072").getJSONObject("state").getString("sha256")').replace('job.getJSONObject("model072").getString("scope")','job.getJSONObject("model072").getJSONObject("state").getString("scope")')
s=s.replace('Four held-out','Five held-out').replace('Exact070 baseline parity','Exact071 baseline parity').replace('Residual model calibrated','State and distance models calibrated').replace('Uncertainty and all outcome costs measured','Useful observation and all outcome costs measured')
# Original manifest fields describing071 gates are replaced by exact072 conditions.
s=s.replace('.put("cleanSensingReduction",.10)','.put("requiredSensingReductionVersusUncertain",true)').replace('.put("hypotheticalScenarios",ObservationSchedule070.scenarios())','.put("hypotheticalScenarios",ObservationSchedule070.scenarios()).put("residualGridWeights",new JSONArray(new double[]{.25,.50,.25})).put("speedFloorMps",.01).put("scalarLabelFee",.03).put("newPolicyFee",.01)')
write('UsefulStudy072.java',s)
