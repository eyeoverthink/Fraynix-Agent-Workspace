'use strict';
const {launch}=require('../workspace-desktop/test/calibration-integration.cjs');
const fs=require('node:fs/promises'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
 const out=path.resolve('workspace-desktop/test-output'),live=JSON.parse(await fs.readFile(path.join(out,'useful072-live.json'),'utf8'));assert(live.passed);
 process.env.FRAYNIX_WORKSPACE_PERSISTENT='0';process.env.FRAYNIX_WORKSPACE_PLAN_CPU_ONLY='1';
 const {app,page}=await launch(live.project),errors=[];page.on('pageerror',e=>errors.push(e.message));
 try{
  await app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].setSize(1600,1100));
  await page.locator('#brain-open').click();await page.locator('#useful072').evaluate(e=>e.open=true);
  await page.waitForFunction(()=>!document.querySelector('#a072-load').disabled,{},{timeout:180000});
  const index=live.job.disturbed072.findIndex(r=>r.results.adaptive.outcome.success&&!r.results.useful.outcome.success);assert(index>=0);
  await page.locator('#a072-phase').selectOption('disturbed');await page.waitForFunction(()=>document.querySelectorAll('#a072-case option').length===60);
  await page.locator('#a072-case').selectOption(String(index));
  await page.waitForFunction(key=>document.querySelector('#a072-task').dataset.traceKey===key,live.job.id+':disturbed:'+index,{timeout:180000});
  const checks=[];
  for(const [method,name]of [['useful','missed-window'],['adaptive','early-recovery']]){
   await page.locator('#a072-method').selectOption(method);const expected=live.job.disturbed072[index].results[method].record;
   assert.equal(await page.locator('#a072-schedule').getAttribute('data-tick'),String(expected.schedule072.selectedTick));
   assert.equal(await page.locator('#a072-second').getAttribute('data-correct'),String(expected.laterPlan.correct));
   assert((await page.locator('#a072-second').innerText()).includes(expected.laterPlan.reason));
   await page.locator('#a072-second').scrollIntoViewIfNeeded();await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   await fs.writeFile(path.join(out,'useful072-'+name+'.png'),Buffer.from(await app.evaluate(()=>global.workspaceTest.capture()),'base64'));
   checks.push({method,tick:expected.schedule072.selectedTick,correct:expected.laterPlan.correct,reason:expected.laterPlan.reason});
  }
  assert.deepEqual(errors,[]);await fs.writeFile(path.join(out,'useful072-harmed-inspection.json'),JSON.stringify({passed:true,date:new Date().toISOString(),jobId:live.job.id,index,scope:'Actual app inspection of existing completed evidence; no new physics or model request.',checks,errors},null,2));console.log(JSON.stringify({passed:true,index,checks}));
 }finally{await app.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
