$ErrorActionPreference='Stop'
while(Get-Process -Id 63052 -ErrorAction SilentlyContinue){Start-Sleep -Seconds 3}
$native072Path='workspace-engine/build/test-results/test/TEST-fraymus.workspace.UsefulNative072Test.xml'
if(!(Test-Path -LiteralPath $native072Path)){throw 'Native results are missing; do not start another validator'}
Copy-Item -LiteralPath $native072Path -Destination build/native072.xml
[xml]$native072Result=Get-Content -LiteralPath build/native072.xml -Raw
if([int]$native072Result.testsuite.failures -ne 0 -or [int]$native072Result.testsuite.errors -ne 0){throw 'Native validation failed; inspect retained original results'}
Write-Output 'Native validation passed; starting targeted regression.'
& powershell -NoProfile -File build/regression072.ps1
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
Write-Output 'Targeted regression passed; starting actual app, restart, Stop and local-model report.'
& powershell -NoProfile -File build/run-app072.ps1
exit $LASTEXITCODE
