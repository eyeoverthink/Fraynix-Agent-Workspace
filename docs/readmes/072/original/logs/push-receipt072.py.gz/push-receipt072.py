import subprocess,pathlib
r=pathlib.Path('.')
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
subprocess.run(['python','build/publication072.py'],check=True)
with (r/'build/documentation072-publication.log').open('wb') as f:subprocess.run(['powershell','-NoProfile','-File','scripts/Verify-Documentation.ps1'],stdout=f,stderr=subprocess.STDOUT,check=True)
files=['AGENTS.md','README.md','docs/PROJECT_MEMORY.md','docs/DEVELOPMENT_LOG.md','docs/PUBLICATION_072.json','docs/publication072/release-audit.json','docs/publication072/documentation.json','docs/publication072/push.log.gz']
subprocess.run(['git','add',*files],check=True)
subprocess.run(['git','commit','-m','Record fetched GitHub publication verification for edition 072'],check=True)
with (r/'build/push072-receipt.log').open('wb') as f:subprocess.run(['git','-c','pack.threads=4','push','--atomic','origin','HEAD:refs/heads/main','HEAD:refs/heads/edition072'],stdout=f,stderr=subprocess.STDOUT,check=True)
print((r/'build/push072-receipt.log').read_text(encoding='utf8'))
subprocess.run(['git','fetch','origin','refs/heads/main:refs/verify/edition072-main','refs/heads/edition072:refs/verify/edition072-branch','refs/tags/readme-072:refs/verify/edition072-tag'],check=True)
assert git('rev-parse','refs/verify/edition072-branch')==git('rev-parse','HEAD')
subprocess.run(['python','build/audit-publication072.py','refs/verify/edition072-main',git('rev-parse','HEAD')],check=True)
