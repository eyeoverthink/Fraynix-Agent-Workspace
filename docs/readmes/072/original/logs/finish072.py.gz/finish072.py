from pathlib import Path
import json
r=Path.cwd();v=json.loads((r/'docs/readmes/072/verification.json').read_text(encoding='utf8'));c=v['clean'];d=v['disturbed']
def write(p,s):p.write_text(s,encoding='utf8')
for f in ['documentation-browser.json','documentation-review.json']:assert json.loads((r/'docs/readmes/072'/f).read_text(encoding='utf8'))['passed']
assert v['javaAllPassed']
short=f"Clean old guard→useful successes {c['methods']['uncertain']['successes']}→{c['methods']['useful']['successes']}/48; later readings {c['methods']['uncertain']['extraObservations']}→{c['methods']['useful']['extraObservations']}; utility change {c['pairedUsefulMinus']['uncertain']['meanDelta']:+.6f}. Disturbed successes {d['methods']['uncertain']['successes']}→{d['methods']['useful']['successes']}/60; readings {d['methods']['uncertain']['extraObservations']}→{d['methods']['useful']['extraObservations']}; utility change {d['pairedUsefulMinus']['uncertain']['meanDelta']:+.6f}. Combined qualification: {v['combinedQualified']}."
p=r/'README.md';s=p.read_text(encoding='utf8');a=s.index('> **[Edition071');b=s.index('\nOne integrated app',a)
s=s[:a]+f'''> **[Edition072 · When another look can still help](README-072.md)** · [Offline guide](docs/readmes/072/index.html) · [Chandra review](docs/CHANDRA_072_ASSESSMENT.md) · [Operation](docs/JAVA_CHAT_044.md) · [Edition history](docs/readmes/INDEX.md)

Edition072 combines calibrated position/speed uncertainty, remaining correction authority and sensing cost, compared with a simple reachability rule and three preserved baselines. {short} No automatic controller promotion. [Full evidence](docs/readmes/072/verification.json).

Edition072 implementation, screenshots and original evidence are prepared for publication. [Previous fetched publication](docs/PUBLICATION_071.json).

'''+s[b:];write(p,s)
p=r/'docs/readmes/INDEX.md';s=p.read_text(encoding='utf8');lines=s.splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('| [071]'));lines.insert(i+1,'| [072](../../README-072.md) | 2026-11-05 | Uncertainty, remaining correction and useful observations | [Viewer](072/index.html) · [tree](072/FILE_TREE.md) |');write(p,('\n'.join(lines)+'\n').replace('checkout is **071**','checkout is **072**'))
p=r/'docs/JAVA_CHAT_044.md';s=p.read_text(encoding='utf8');i=s.index('\n');write(p,s[:i]+f'''

## Edition072: when another look can still help

Java Brain → When can another look help? runs24 fit and36 separate calibration trajectories, six exact071 parity pairs and five policies on48clean/60disturbed/12unsupported tasks. Inspect frozen position/speed ranges, selected/skipped observation times, remaining impulse budget, hypothetical saved/harmed fractions, actual native contact guards, all costs and full46-sample traces. Hypothetical fractions are assumptions, not calibrated probabilities. Stop retains completed evidence and cold restart restores exact records.

Chat: “Inspect the useful observation study and create the verified Java report. Include state uncertainty, remaining correction ability, all five policies, costs and failures. Do not run experiments or move objects.” Actual CPU4gpt-oss20b reporting was checked against complete Java facts.

{short} Active controller stays unchanged. This is native ramp control, not physical camera calibration. Chandra contributes reviewed organization and inheritance ideas; its fleet is not installed into Java. [README072](../README-072.md) · [contract](EDITION_072_CONTRACT.md) · [review](CHANDRA_072_ASSESSMENT.md).

'''+s[i:])
entry=f'''

## Edition072 · Validated locally; publication next

Contract2e4a2e7 and cost clarificationf7c4220 precede implementation4e36547 and outcomes. Isolated work/fraynix-workspace-edition072 from622fdfb.24fit/36calibration trajectories freeze original071 distance model and new joint position/speed residual model. Five policies blind/adaptive/uncertain/simple/useful preserve first action and .12individual/.24cumulative correction authority. New useful policy compares243 hypothetical states at92/116/140; explicit weights are assumptions.666slots/612native executions; six exact071 parity pairs. All46 diagnostic samples retained.

{short} Joint state coverage clean {c['coverage']['jointCovered']}/{c['coverage']['count']}, disturbed {d['coverage']['jointCovered']}/{d['coverage']['count']}. Simple comparator and every saved/harmed goal, refusal, failed correction, scheduler time and training cost retained. No post-outcome rule/case/gate tuning, controller promotion or LLM-weight training.

{v['javaDistinct']}targeted Java checks/{v['javaClasses']}classes,127desktop checks, actual complete app study, identical native/app numeric outcomes, restart/Stop/CPU4gpt-oss20b report and offline1440/390 checks pass. Published071 cold-restores. Source/model/timing/event/plan tampering is rejected. Factory runtime/transaction harnesses pass. No fresh full-history heavyweight rerun claimed. README072,{v['actualApp']['screenshotCount']}actual app captures,2offline captures, complete source inventory, Obsidian80/canvas and exact originals prepared.

Chandra e984a33685c0ed9e0c4f4c79e4cd1f094b4118de: inspected fleet/roles/harness/perspectives/Ouroboros/prediction/active inference/RSI. Four isolated inheritance tests pass; six controlled source probes reproduce false completion, false execution receipt, oversized output, no-action credit and random unchanged-genome improvement. Setup failure retained. Roles, contextual inheritance and budgets transfer as concepts; source status/labels are not new verified intelligence. No whole-app quality claim, external dependency, service or personal database changes.

The targeted regression first ran under Windows PowerShell5, whose Stop preference treated the informational JAVA_TOOL_OPTIONS stderr line as a wrapper failure. Its111 passing XML checks are retained; a successful PowerShell7 invocation verifies the up-to-date test outputs, installation and source isolation.

The first full native validation completed all612 executions and the study audit, then failed with a768MB heap error while the test retained multiple full tampered copies. Original XML/log/test source are archived. Harness-only769b366 scopes those copies before the next trace read; the completed original experiment is reused unchanged. Physics/model rules remain4e36547. The first resume then rejected an oversized chat context;6891627/c223cf4 tabulate repeated coverage/goal fields losslessly, with every value reconstructed in the real-study test. That original failure is retained too.

The Game Lab follow-up is documented in docs/REHEARSAL_MEMORY_072.md: reusable experiments with complete restore contracts, immutable parent/child episodes, state/actions plus visual witnesses, component substitutions and an optional Java bytecode investigator. Pinned Akashic2e5a0f94 and RE4c04eee3 were reviewed; selected source identities and focused probes are archived. Akashic exact13 Java sources compiled; original19 RAM-mode checks pass and six additional counterexamples reproduce the identified gaps. Four RE-script counterexamples use mocked process/model/receipt boundaries; no native RE stack or whole external app validation is claimed. These are reviewed concepts, not newly installed rehearsal/RE capabilities.

Publication/fetched audit next. Preserve normal045/qa046, private worlds and immutable001–071. No subagents/overlapping heavy validators. Next073 proposal: reusable experimental memory through typed specialist requests in the existing Java goal runner, complete checkpoints, one-component forks, shared source identity, one total budget, explicit partial failure and matched-budget retrieval/no-retrieval comparison. Do not retune072 against its test outcomes.
'''
for name in ['AGENTS.md','docs/PROJECT_MEMORY.md','docs/DEVELOPMENT_LOG.md']:
 p=r/name;s=p.read_text(encoding='utf8');i=s.index('\n');write(p,s[:i]+entry+s[i:])
print('Updated entry point, operations and continuity records')
