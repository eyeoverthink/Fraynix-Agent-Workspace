$ErrorActionPreference='Stop'
$akashic072Jdk='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$akashic072Sources=@(rg --files build/reference072/fraynix-akashic/src -g '*.java')
New-Item -ItemType Directory -Path build/reference072/classes -Force | Out-Null
& "$akashic072Jdk/bin/javac.exe" -J-XX:ActiveProcessorCount=2 -encoding UTF-8 -d build/reference072/classes @akashic072Sources build/ReviewAkashic072.java *> build/akashic-compile072.log
if($LASTEXITCODE -ne 0){Get-Content build/akashic-compile072.log;exit $LASTEXITCODE}
& "$akashic072Jdk/bin/java.exe" -XX:ActiveProcessorCount=2 -Xmx256m -cp build/reference072/classes fraynix.akashic.VerifyAll *> build/akashic-original072.log
$akashic072OriginalExit=$LASTEXITCODE
& "$akashic072Jdk/bin/java.exe" -XX:ActiveProcessorCount=2 -Xmx256m -cp build/reference072/classes fraynix.akashic.ReviewAkashic072 *> build/akashic-probes072.log
$akashic072ProbeExit=$LASTEXITCODE
Get-Content build/akashic-original072.log -Tail 7
Get-Content build/akashic-probes072.log
if($akashic072OriginalExit -ne 0 -or $akashic072ProbeExit -ne 0){exit 1}
