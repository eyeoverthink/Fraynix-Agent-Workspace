import subprocess,json,pathlib
r=pathlib.Path('.')
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
assert not git('status','--porcelain')
assert json.loads((r/'build/documentation-check.json').read_text(encoding='utf8'))['passed']
assert json.loads((r/'build/publication-audit072.json').read_text(encoding='utf8'))['commit']==git('rev-parse','HEAD')
subprocess.run(['git','fetch','origin','main','--quiet'],check=True)
subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],check=True)
subprocess.run(['git','tag','-a','readme-072','-m','Edition 072: useful observations, bounded correction, complete evidence and reusable experiment-memory design'],check=True)
with (r/'build/push072.log').open('wb') as f:subprocess.run(['git','-c','pack.threads=4','push','--atomic','origin','HEAD:refs/heads/main','HEAD:refs/heads/edition072','refs/tags/readme-072'],stdout=f,stderr=subprocess.STDOUT,check=True)
print((r/'build/push072.log').read_text(encoding='utf8'))
subprocess.run(['git','fetch','origin','refs/heads/main:refs/verify/edition072-main','refs/heads/edition072:refs/verify/edition072-branch','refs/tags/readme-072:refs/verify/edition072-tag'],check=True)
assert git('rev-parse','refs/verify/edition072-main')==git('rev-parse','HEAD')==git('rev-parse','refs/verify/edition072-branch')==git('rev-parse','refs/verify/edition072-tag^{commit}')
subprocess.run(['python','build/audit-publication072.py','refs/verify/edition072-main',git('rev-parse','HEAD')],check=True)
