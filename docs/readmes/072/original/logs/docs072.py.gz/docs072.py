from pathlib import Path
import json,hashlib,gzip,subprocess,shutil,xml.etree.ElementTree as ET,re,html,datetime
r=Path.cwd();d=r/'docs/readmes/072';d.mkdir(parents=True,exist_ok=True);out=r/'workspace-desktop/test-output'
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
live=json.loads((out/'useful072-live.json').read_text(encoding='utf8'));assert live['passed'];job=live['job'];source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
plans=[x['detail']['compute'] for x in live['chat']['history'] if x['kind']=='plan']
assert plans and all(x['cpuOnly'] and x['options']['num_thread']==4 and x['options']['num_gpu']==0 for x in plans)
titles={'missed-window':'A later look misses the remaining correction window','early-recovery':'The earlier adaptive look recovers the same task','overview':'Integrated useful-observation study','calibration':'Frozen position and speed calibration','clean':'Clean outcomes, costs and comparisons','disturbed':'Unfamiliar disturbance results','brake':'Brake impulse and subsequent motion','lift':'Lift impulse and contact guard','push':'External push and bounded recovery','spin':'Torque and rotation guard','after-last':'Event after every candidate look','look':'A selected look and predicted correction value','skip':'A skipped look and remaining authority','simple':'Simpler nominal reachability comparison','prior-guard':'Preserved original071 uncertainty guard','coverage':'Position and speed intervals checked against blind motion','paired':'All five policies and measured costs','domain':'Unsupported task refused without invented motion','narrow':'Integrated Brain at 1100 pixels','chat':'Actual local-model report with checked Java facts'}
shots=[(k,t) for k,t in titles.items() if (out/f'useful072-{k}.png').exists()];assert len(shots)>=16
for k,_ in shots:shutil.copyfile(out/f'useful072-{k}.png',d/f'useful072-{k}.png')
archives=[];packed=set()
def pack(p,dest):
 if str(dest) in packed:return
 packed.add(str(dest));b=p.read_bytes();z=gzip.compress(b,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archives.append(dict(path=dest.relative_to(r).as_posix(),bytes=len(z),sha256=sha(z),rawBytes=len(b),rawSha256=sha(b),source=str(p)))
cases={};invocations=[];nativeRoot=None
for name,files in [('fast072',[r/'build/fast072.xml']),('compat072',sorted((r/'build/compat072').glob('TEST-*.xml'))),('native072',[r/'build/native072.xml']),('regression072',sorted((r/'build/regression072').glob('TEST-*.xml'))),('factory072',sorted((r/'build/factory072').glob('TEST-*.xml')))]:
 rows=[]
 for p in files:
  if not p.exists():continue
  tree=ET.parse(p).getroot()
  for c in tree.findall('testcase'):
   key=c.attrib['classname']+'#'+c.attrib['name'];passed=all(c.find(n) is None for n in ['failure','error','skipped']);rows.append(dict(case=key,passed=passed,seconds=float(c.attrib['time'])));cases[key]=passed
  for original in re.findall(r'EDITION072_NATIVE_ROOT=([^\r\n<]+)',p.read_text(encoding='utf8')):nativeRoot=Path(original.strip())
  pack(p,d/'original'/name/(p.name+'.gz'))
 if rows:invocations.append(dict(name=name,cases=rows))
assert cases and all(cases.values()) and nativeRoot
for f in ['original-attempt.json','original-experiment.json','trace.json']:
 q=nativeRoot/f
 if q.exists():pack(q,d/'original/native072'/(f+'.gz'))
for pattern in ['*072*.log','*072*.xml','*072*.java','*072*.py','*072*.ps1','*072*.init.gradle','comparison072.json','backup072.json','model-residency072.json','chandra-*.json','reference072-source.json','reference-validation072.json','rehearsal-probes072.json','check-docs072.cjs','inspect-harmed072.cjs','source-isolation.json']:
 for p in sorted((r/'build').glob(pattern)):pack(p,d/'original/logs'/(p.name+'.gz'))
for p in sorted((r/'build/regression072').glob('*.log')):pack(p,d/'original/regression072'/(p.name+'.gz'))
for p in sorted(out.glob('useful072-*.json')):pack(p,d/'original/actual-app'/(p.name+'.gz'))
for directory in ['native072-failures','ui072-failures']:
 for p in sorted((r/'build'/directory).rglob('*')):
  if p.is_file():pack(p,d/'original'/directory/(p.relative_to(r/'build'/directory).as_posix()+'.gz'))
js(d/'original-evidence.json',dict(format='Exact original bytes compressed with gzip. Synthetic isolated validation projects and declared Chandra, Akashic and RE reference checks; exact selected source identities retained.',files=archives))
review=json.loads((out/'useful072-review.json').read_text(encoding='utf8'));assert review['passed']
comparison=json.loads((r/'build/comparison072.json').read_text(encoding='utf8'));assert comparison['nativeMatchesActualApp']['evaluationRecords']==540
native=json.loads((nativeRoot/'original-experiment.json').read_text(encoding='utf8'))
def elapsed(j):return (datetime.datetime.fromisoformat(j['endedAt'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(j['createdAt'].replace('Z','+00:00'))).total_seconds()
v=dict(edition=72,date=live['date'],source=source,contractCommit='2e4a2e7',costClarificationBeforeOutcomes='f7c4220',implementationBeforeFirstOutcome='4e36547',postOutcomeChanges={'769b366':'Test-only lifetime of tampered copies; original completed study retained','6891627':'Lossless chat context tables for coverage and goal counts; physics unchanged','c223cf4':'Describe policy and calibration-cell identities in table schema'},nativeExecutions=job['nativeExecutions'],progressSlots=job['progress'],parityMaximumDeltas=[p['maximumDelta'] for p in job['parity072']],javaDistinct=len(cases),javaClasses=len({k.split('#')[0] for k in cases}),javaAllPassed=True,javaInvocations=invocations,desktopUnitTests=127,actualApp=dict(source=live['source'],physicsJobSource=live['jobSource'],checks=live['checks'],original='original/actual-app/useful072-live.json.gz',model='gpt-oss:20b CPU-only/four threads',widths=[1600,1100],screenshotCount=len(shots)),comparison=comparison,visualReview=review,model=job['model072'],trainingCosts=job['trainingCosts072'],clean=job['cleanEvaluation072'],disturbed=job['disturbedEvaluation072'],unsupported=job['unsupportedEvaluation072'],combinedQualified=job['accepted'],studyWallSeconds=dict(native=elapsed(native),actualApp=elapsed(job)),chandra=dict(commit='e984a33685c0ed9e0c4f4c79e4cd1f094b4118de',probeFile='original/logs/chandra-probes072.json.gz',inheritanceChecks=4,controlledCounterexamples=6,scope='Exact selected modules with explicit mocked boundaries; no whole-app/model-quality claim'),limitations=['Known native rigid-body ramp only; not physical webcam calibration or adaptive camera capture','Six fit and nine calibration examples per cell; nominal90% is not guaranteed after distribution shift','Eight-component coverage at four sampled times, not a continuous confidence region','Residual grid discards position/speed correlation; hypothetical weights are assumptions, not learned probabilities','Planning assumes contact; actual contact, rotation and velocity must still pass','Training logical charges include eight scalar labels/run, not eight physical frames','All46 diagnostic samples retained; savings count selected controller readings','No automatic controller promotion, new LLM weights or multi-LLM consensus claim','Fixed order and finite reserved tasks; app repetition checks reproducibility, not additional independent goals','Targeted regression scope, not a fresh full-history heavyweight run'])
v['rehearsalReferences']=json.loads((r/'build/reference-validation072.json').read_text(encoding='utf8'))
v['documentationHarnessRepair']={'scope':'Offline guide check only','original':'original/ui072-failures/documentation-assertion/failure.json.gz','reason':'The initial assertion expected the module title where the interface displays its descriptive summary. The repaired check asserts the exact summary and source link. No document behavior, physics, policy or outcomes changed.'}
def errors(rows):
 points=[b for row in rows for b in row.get('coverage072',{}).get('bands',[])];ends=[row['coverage072']['bands'][-1] for row in rows if 'coverage072' in row];out={'tasks':len(ends),'points':len(points)}
 for name,items in [('allFourTimes',points),('terminal',ends)]:
  out[name]={}
  for axis in ['distance','speed']:
   out[name][axis]={}
   for key in ['nominal','center']:
    values=[abs(b[axis]['actual']-b[axis][key]) for b in items];out[name][axis][key]={'meanAbsoluteError':sum(values)/len(values) if values else None,'maxAbsoluteError':max(values) if values else None}
 return out
nominal={}
for phase in ['clean','disturbed','unsupported']:
 rows=job[phase+'072'];nominal[phase]={'all':errors(rows),'cells':{cell:errors([row for row in rows if row.get('coverage072',{}).get('cell')==cell]) for cell in job['model072']['state']['cells']}}
v['forecastErrorByPhaseAndCell']=nominal;js(d/'forecast-errors.json',nominal)
runtimeLog=(r/'build/factory072.log').read_text(encoding='utf8');assert 'FactoryRuntimeTest passed' in runtimeLog and 'WorldTransactionTest passed' in runtimeLog
v['factoryRuntimeHarnesses']=['FactoryRuntimeTest','WorldTransactionTest'];js(d/'verification.json',v)
paths={x['path'] for x in json.loads((r/'docs/readmes/071/file-inventory.json').read_text(encoding='utf8'))}
paths.update(p for p in subprocess.check_output(['git','diff','--name-only','--diff-filter=A','622fdfb','HEAD'],text=True).splitlines() if p.startswith(('workspace-engine/','workspace-desktop/','fraynix-modules/','scripts/Review-Chandra072')))
inventory=[]
for name in sorted(paths):
 b=(r/name).read_bytes()
 try:b=b.decode('utf8').replace('\r\n','\n').encode();kind='utf8-lf'
 except UnicodeError:kind='binary'
 inventory.append(dict(path=name,bytes=len(b),hashKind=kind,sha256=sha(b)))
js(d/'file-inventory.json',inventory);write(d/'FILE_TREE.md','# Edition072 complete source tree\n\n[Canonical bytes and hashes](file-inventory.json).\n\n```text\n'+'\n'.join(x['path'] for x in inventory)+'\n```\n')
modules=[('fit','Separate fitting and joint calibration','Fit position/speed residuals, separately calibrate four source/regime cells and freeze before evaluation.','workspace-engine/src/main/java/fraymus/workspace/StateUncertainty072.java','Verified'),('value','Uncertainty and remaining correction','Compare243 hypothetical states across three windows using unchanged bounded inverse control and explicit cost.','workspace-engine/src/main/java/fraymus/workspace/ObservationValue072.java','Verified'),('native','Measured authority and outcomes','Actual contact, velocity and rotation guard each impulse; native samples and receipts are recomputed.','workspace-engine/src/main/java/fraymus/workspace/UsefulTrial072.java','Verified'),('study','Five paired policies and independent truth','Fresh fit/calibration/evaluation, exact071 parity, all costs, failures and blind-future coverage.','workspace-engine/src/main/java/fraymus/workspace/UsefulStudy072.java','Verified'),('chat','Checked Java-owned reports','Lossless aggregate tables preserve all policy metrics, paired deltas and costs in local model context.','workspace-engine/src/main/java/fraymus/workspace/UsefulContext072.java','Actual model'),('view','One integrated evidence view','Inspect calibration, choices, actual native motion and simple reachability without a second application.','workspace-desktop/renderer/useful072.js','Actual app'),('chandra','Chandra roles and inheritance review','Pinned code, four existing inheritance checks and six controlled counterexamples inform stricter Java contracts.','docs/CHANDRA_072_ASSESSMENT.md','Reviewed'),('next','Typed specialist requests','Extend the existing Java goal runner with bounded observer/planner/verifier requests and verified procedure inheritance.','docs/EDITION_072_CONTRACT.md','Planned')]
modules.append(('memory','Game Lab as reusable experimental memory','Design assessment: fork saved state, substitute components, compare actual outcomes and investigate failures at source/bytecode level. Pinned Akashic and RE source reviewed; not installed.','docs/REHEARSAL_MEMORY_072.md','Reviewed concept'))
system=dict(edition=72,modules=[dict(id=i,name=n,summary=s,source=p,status=status,note='docs/obsidian/80-useful-observation.md') for i,n,s,p,status in modules],screenshots=[dict(path=f'docs/readmes/072/useful072-{k}.png',title=t) for k,t in shots],evidence=[dict(path='docs/readmes/072/'+p,title=t) for p,t in [('verification.json','Verification'),('original-evidence.json','Exact originals'),('useful-data.json','Audited Java motion, bounds and schedules')]])
js(d/'system-map.json',system)
write(r/'docs/obsidian/80-useful-observation.md',f'''# Uncertainty and remaining correction

The Java brain compares uncertainty with remaining authority and complete sensing cost. Five paired policies separate the value of calibrated uncertainty, simple reachability and hypothetical planning. Actual native contact and outcome checks retain final authority.

- [[README-072]]
- [[docs/EDITION_072_CONTRACT]]
- [[docs/CHANDRA_072_ASSESSMENT]]
- [[docs/REHEARSAL_MEMORY_072]]
- [[docs/obsidian/79-observation-uncertainty]]

Combined qualification: {v['combinedQualified']}. Clean useful-minus-uncertain utility {v['clean']['pairedUsefulMinus']['uncertain']['meanDelta']:+.6f}; disturbed {v['disturbed']['pairedUsefulMinus']['uncertain']['meanDelta']:+.6f}. Model-state ranges, selected/skipped looks, saved/harmed goals, failures and training costs remain visible. Hypothetical fractions are not calibrated probabilities.

Chandra contributes role separation and context inheritance. Six focused counterexamples show why completion, execution receipts, bounded context, causal credit and promotion require independent tests. The user's follow-up connects Game Lab rehearsal, Akashic lineage and an internal RE investigator. Next: reusable experimental memory through typed specialist requests, complete restore contracts and tested component substitutions, with one total resource budget and explicit partial failures. No automatic controller promotion or claim of superintelligence.
''')
nodes=[dict(id=i,type='file',file=p,x=(k%3)*420,y=(k//3)*250,width=390,height=200) for k,(i,n,s,p,status) in enumerate(modules)]
js(r/'docs/obsidian/useful-observation.canvas',dict(nodes=nodes,edges=[dict(id=f'e{k}',fromNode=nodes[k]['id'],fromSide='right',toNode=nodes[k+1]['id'],toSide='left') for k in range(len(nodes)-1)]))
data=json.loads((r/'build/useful-data072.json').read_text(encoding='utf8'));assert data['cleanEvaluation']==job['cleanEvaluation072'];js(d/'useful-data.json',data)
page=(r/'build/guide072.html').read_text(encoding='utf8').replace('__SHOTS__',''.join(f'<figure><img src="useful072-{k}.png" alt="{html.escape(t)}"><figcaption>{html.escape(t)} · actual app · November 5,2026 · isolated synthetic project</figcaption></figure>' for k,t in shots))
for key,value in [('SYSTEM',system),('INVENTORY',inventory),('DATA',data)]:page=page.replace('__'+key+'__',json.dumps(value,ensure_ascii=False).replace('</','<\\/'))
write(d/'index.html',page);print(json.dumps(dict(sourceFiles=len(inventory),java=len(cases),archives=len(archives),source=source,screenshots=len(shots))))
