from pathlib import Path
import json,subprocess,gzip
r=Path.cwd()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
audit=read(r/'build/publication-audit072.json');assert audit['passed'] and audit['remoteFetched'];release=audit['commit'];tag=git('rev-parse','refs/verify/edition072-tag');assert git('rev-parse','refs/verify/edition072-tag^{commit}')==release
doc=read(r/'build/documentation-check.json');assert doc['passed'];v=read(r/'docs/readmes/072/verification.json');c=v['clean'];d=v['disturbed']
js(r/'docs/publication072/release-audit.json',audit);js(r/'docs/publication072/documentation.json',doc);(r/'docs/publication072/push.log.gz').write_bytes(gzip.compress((r/'build/push072.log').read_bytes(),mtime=0))
scope=f"{v['javaDistinct']} targeted Java checks/{v['javaClasses']} classes;127desktop checks; actual666-slot/612-execution app study, numeric native/app parity, six exact071 parity pairs, source/value/time/budget/model guards, cold restore, Stop and CPU4gpt-oss20b report. Qualification {v['combinedQualified']}; no promotion or post-outcome tuning. Chandra pinned-source review, four inheritance tests and six controlled counterexamples. Game Lab rehearsal-memory design plus pinned Akashic/RE source and controlled checks; no new external engine installed."
js(r/'docs/PUBLICATION_072.json',{**audit,'releaseCommit':release,'annotatedTag':'readme-072','tagObject':tag,'publishedRefs':['refs/heads/main','refs/heads/edition072','refs/tags/readme-072'],'documentation':doc,'evidence':'docs/readmes/072/verification.json','scope':scope})
p=r/'README.md';s=p.read_text(encoding='utf8');old='Edition072 implementation, screenshots and original evidence are prepared for publication. [Previous fetched publication](docs/PUBLICATION_071.json).';assert old in s
write(p,s.replace(old,f"Edition072 is published to main with full source, {v['actualApp']['screenshotCount']} actual app captures, exact original evidence and updated continuity notes. [Fetched GitHub verification](docs/PUBLICATION_072.json)."))
entry=f'''

## Edition072 · Published and fetched back on2026-11-05

Atomic push to Fraynix-Agent-Workspace main,edition072 and readme-072 succeeded. Release{release}; annotated tag{tag}. Fresh GitHub fetch verified {audit['canonicalSourceFiles']}canonical sources,{audit['frozenHashes']}frozen hashes across72editions and{audit['original072EvidenceFiles']}original archives including decompressed bytes. Documentation passed{doc['canvases']}canvases/{doc['references']}references. [Receipt](docs/PUBLICATION_072.json).

{scope}

Clean old guard→useful success {c['methods']['uncertain']['successes']}→{c['methods']['useful']['successes']}/48, later readings {c['methods']['uncertain']['extraObservations']}→{c['methods']['useful']['extraObservations']}; utility delta {c['pairedUsefulMinus']['uncertain']['meanDelta']:+.6f}. Disturbed success {d['methods']['uncertain']['successes']}→{d['methods']['useful']['successes']}/60, later readings {d['methods']['uncertain']['extraObservations']}→{d['methods']['useful']['extraObservations']}; utility delta {d['pairedUsefulMinus']['uncertain']['meanDelta']:+.6f}. All costs/failures and simpler control retained. Hypothetical weights are not probabilities. Native state calibration is not webcam accuracy.

README072,actual app/offline captures, full source inventory, Obsidian80/canvas, Chandra and experimental-memory/Akashic/RE assessments and raw proof published. Test app closed; normal045/qa046/private worlds preserved. No subagents or concurrent heavy validators. Next073 proposal: reusable experimental memory, complete restore contracts and component substitutions through typed bounded specialist requests in the existing Java goal runner. This receipt follows the immutable release tag.
'''
for name in ['AGENTS.md','docs/PROJECT_MEMORY.md','docs/DEVELOPMENT_LOG.md']:
 p=r/name;s=p.read_text(encoding='utf8');i=s.index('\n');write(p,s[:i]+(entry.replace('](docs/','](') if name.startswith('docs/') else entry)+s[i:])
print('Publication receipt prepared from fetched evidence',release)
