from pathlib import Path
import json
r=Path.cwd()
root=Path('C:/Users/eyeka/AppData/Local/Temp/fraynix-useful072-11023916200409927012')
native=json.loads((root/'original-experiment.json').read_text(encoding='utf8'))
appfile=r/'workspace-desktop/test-output/useful072-live.json'
app=json.loads(appfile.read_text(encoding='utf8'))['job'] if appfile.exists() else None
omit={'nativeWallMillis','schedulerWallMillis'}
def cleaned(v):
 if isinstance(v,dict):return {k:cleaned(x) for k,x in v.items() if k not in omit|{'modelSha256','recordId','recordSha256'}}
 if isinstance(v,list):return [cleaned(x) for x in v]
 return v
def check(a,b,partial=False):
 counts={'trainingRecords':0,'evaluationRecords':0,'refusals':0}
 for part in ['state','distance']:assert cleaned(a['model072'][part]['cells'])==cleaned(b['model072'][part]['cells'])
 for phase in ['fit','calibration']:
  for x,y in zip(a[phase+'072'],b[phase+'072']):
   assert x['task']==y['task'] and x['record']['samples']==y['record']['samples'];counts['trainingRecords']+=1
 for phase in ['clean','disturbed','unsupported']:
  for i,x in enumerate(a[phase+'072']):
   y=b[phase+'072'][i];assert x['task']==y['task'] and x['event']==y['event'] and x['plan']==y['plan']
   for method,z in x['results'].items():
    if 'outcome' not in z:assert partial;continue
    zz=y['results'][method];assert cleaned(z['outcome'])==cleaned(zz['outcome']),(phase,i,method,'outcome')
    if 'record' in z:
     assert z['record']['samples']==zz['record']['samples'],(phase,i,method,'samples')
     for key in ['correctionPlan','laterPlan']:assert cleaned(z['record'].get(key))==cleaned(zz['record'].get(key)),(phase,i,method,key)
     assert cleaned(z['record'].get('schedule072'))==cleaned(zz['record'].get('schedule072')),(phase,i,method,'schedule')
     counts['evaluationRecords']+=1
    else:counts['refusals']+=1
 return counts
result={'nativeProject':str(root),'policyRulesUnchanged':True,'physicalSamplesPlansAndNonTimingOutcomesMatch':True,'frozenNumericalCalibrationMatches':True,'identityScope':'Original training record IDs/hashes and model identities differ between independent runs; neither is substituted or discarded.'}
if app:result['nativeMatchesActualApp']=check(native,app)
(r/'build/comparison072.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))
