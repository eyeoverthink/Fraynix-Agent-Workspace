package fraynix.akashic;
import java.util.*;
/** Read-only reference behavior probes: RAM stores only, no production paths or services. */
public class ReviewAkashic072 {
 static void check(String name,boolean result,String evidence){if(!result)throw new AssertionError(name+": "+evidence);System.out.println("REPRODUCED: "+name+" | "+evidence);}
 public static void main(String[] args){
  var store=new AkashicStore(null);var c=store.active.get(0);String seal=c.rootSeal;byte[] w=c.packWeightsBlob();c.W[0][1]+=.5;c.computeRootSeal();check("Root state seal does not bind weights",seal.equals(c.rootSeal)&&!Arrays.equals(w,c.packWeightsBlob()),"weights changed; rootSeal="+seal);
  String snapA=store.snapshot(7);byte[] stateA=store.snapshots.getLast().columnBlobs().get(0);c.W[1][2]+=.5;String snapB=store.snapshot(7);check("Same-tick snapshots omit weight changes",snapA.equals(snapB)&&Arrays.equals(stateA,store.snapshots.getLast().columnBlobs().get(0)),"id="+snapB+"; state bytes="+stateA.length);
  var live=new AkashicStore(null);var loop=new Ouroboros(live);double[] input=new double[32];for(int i=0;i<input.length;i++)input[i]=StrictMath.sin(i*FraynixCore.PHI);
  loop.tick(input,16.66);var first=loop.columns.get(0);String before=first.rootSeal;first.computeRootSeal();check("Seal precedes final tick phase change",!before.equals(first.rootSeal),"saved="+before+" recomputed="+first.rootSeal);
  loop.populationCap=8;for(int t=0;t<6;t++){for(int i=0;i<input.length;i++)input[i]=StrictMath.sin(i*FraynixCore.PHI+100+t);loop.tick(input,16.66);}
  check("New runtime columns are absent from store active list",loop.columns.size()>live.active.size(),"runtime="+loop.columns.size()+" store="+live.active.size());
  var dreamStore=new AkashicStore(null);var dream=new Dreamer(dreamStore,7);String a=dream.dreamCycle(1).masterSealHex();for(var col:dreamStore.active){col.lastSurprise=1000;col.cumulativeSurprise=1000;}String b=dream.dreamCycle(1).masterSealHex();check("Dream weighting ignores recorded surprise fields",a.equals(b),"same master seal after changing last/cumulative surprise");
  check("Snapshot restore API absent",Arrays.stream(AkashicStore.class.getMethods()).noneMatch(m->m.getName().equals("restoreColumns")),"source also has no database SELECT/load path; no SQLite driver experiment claimed");
  System.out.println("6 focused Akashic counterexamples reproduced; no claim about general intelligence or physical learning.");
 }
}
