$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$env:JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=4'
if(!(Test-Path -LiteralPath build/akashic-reference072.exit)){
    & pwsh -NoProfile -File build/review-akashic072.ps1
    $LASTEXITCODE | Set-Content -Encoding utf8 build/akashic-reference072.exit
}
node workspace-desktop/test/useful072-integration.cjs *> build/app072.log
$code=$LASTEXITCODE
Get-Content build/app072.log -Tail 28
exit $code
