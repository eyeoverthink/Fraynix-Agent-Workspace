from pathlib import Path
import importlib.util,subprocess,tempfile,json,contextlib,io,hashlib,types
root=Path('build/reference072/fraymus-re-agent/scripts');results=[]
def module(file):
 spec=importlib.util.spec_from_file_location(file.replace('-','_'),root/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
annotate=module('fra-annotate.py')
fixture='// ==== alpha @ 1000 ====\nint alpha() { return 1; }\n// ==== beta @ 2000 ====\nint beta() { return 2; }\n'
parsed=annotate.split_functions(fixture)
assert parsed and (parsed[0]['name']!='alpha' or parsed[0]['addr']!='1000')
results.append(dict(name='Function name/address/body fields are misaligned by split indexing',reproduced=True,actual=parsed,expectedFirst=dict(name='alpha',addr='1000')))
planner=module('hive-plan.py');receipts=[]
planner.bus=lambda *a,**k:receipts.append(a)
planner.subprocess=types.SimpleNamespace(run=lambda *a,**k:subprocess.CompletedProcess(a[0],1,stdout='',stderr='controlled failure'))
capture=io.StringIO()
with contextlib.redirect_stdout(capture):planner.v_analyze('controlled-fixture.bin')
assert any(r[1]=='dossier_done' for r in receipts)
results.append(dict(name='Failed child process still receives dossier_done',reproduced=True,receipts=receipts.copy(),stdout=capture.getvalue(),scope='No pipeline or binary executed; subprocess explicitly returns1'))
receipts.clear();planner.ollama=lambda *a,**k:'No valid plan supplied'
with contextlib.redirect_stdout(io.StringIO()):planner.v_todo('controlled task')
assert any(r[1]=='plan_done' and '0 steps' in r[2] for r in receipts)
results.append(dict(name='Unparseable plan becomes done with zero steps',reproduced=True,receipts=receipts.copy(),scope='No model call; controlled reply'))
hive=module('hive-receipts.py');emitted=[];hive._load=lambda:emitted;hive._append=lambda r:emitted.append(r)
with tempfile.TemporaryDirectory(prefix='fraynix-review072-') as tmp:
 p=Path(tmp)/'bundle.json';p.write_text(json.dumps({'packets':[{'client_verified':True,'v13_sha256':'not-a-digest','v13_canonical':'changed','to':'fixture'}]}),encoding='utf8')
 with contextlib.redirect_stdout(io.StringIO()):hive.cmd_ingest_phone(types.SimpleNamespace(bundle=str(p)))
assert emitted[1]['type']=='proof_packet' and emitted[1]['seal']=='not-a-digest'
results.append(dict(name='Phone verified label trusts caller boolean without checking digest',reproduced=True,emitted=emitted,scope='Disposable fixture; no user receipts or device accessed'))
out=dict(source='4c04eee36be9a0c188a76bc5db8db16fb0142233',scope='Selected unmodified source functions with explicitly mocked subprocess/model/receipt boundaries; no RE engine, native binary or model executed.',files=[dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in root.glob('*.py')],checks=results)
Path('build/rehearsal-probes072.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(json.dumps(out))
