from pathlib import Path
s=Path('../fraynix-workspace-edition071/build/check-docs071.cjs').read_text(encoding='utf8').replace('071','072').replace('uncertain-data','useful-data').replace('data.model.sha256','data.model.state.sha256')
s=s.replace("'#results tbody tr').count(),4","'#results tbody tr').count(),5").replace("'#subgroups tbody tr').count(),4","'#subgroups tbody tr').count(),5")
s=s.replace("data.clean.findIndex(r=>r.results.fixed.laterPlan)","data.clean.findIndex(r=>r.results.uncertain.laterPlan)")
a=s.index("await p.locator('#method').selectOption('fixed')");b=s.index("assert.equal(await p.locator('#band polygon')",a)
s=s[:a]+"""await p.locator('#method').selectOption('uncertain');assert.equal(await p.locator('#second').getAttribute('data-kind'),'measured-later-window');assert.equal(await p.locator('#schedule').getAttribute('data-tick'),String(data.clean[example].results.uncertain.schedule072.selectedTick));await p.locator('#method').selectOption('useful');assert.equal(await p.locator('#schedule').getAttribute('data-tick'),String(data.clean[example].results.useful.schedule072.selectedTick));assert.equal(await p.locator('#candidates tbody tr').count(),3);await p.locator('#method').selectOption('simple');assert.equal(await p.locator('#schedule').getAttribute('data-role'),'simple nominal reachability');
"""+s[b:]
s=s.replace('Uncertainty072.java','StateUncertainty072.java').replace('Frozen uncertainty','Frozen state uncertainty')
Path('build/check-docs072.cjs').write_text(s,encoding='utf8')
s=Path('../fraynix-workspace-edition071/build/freeze071.py').read_text(encoding='utf8').replace('071','072').replace('number=71','number=72').replace("manifest['latest']=71","manifest['latest']=72").replace("manifest['latest']==70","manifest['latest']==71").replace('196fdce','622fdfb').replace('Source-bound uncertainty and risky observation skips','Uncertainty, remaining correction and useful observations')
Path('build/freeze072.py').write_text(s,encoding='utf8')
