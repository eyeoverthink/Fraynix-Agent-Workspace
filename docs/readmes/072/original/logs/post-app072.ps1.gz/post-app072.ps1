$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$env:JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=4'
$live072=Get-Content -Raw workspace-desktop/test-output/useful072-live.json | ConvertFrom-Json
if(!$live072.passed){throw 'Actual app validation must pass first'}
node build/inspect-harmed072.cjs *> build/inspect-harmed072.log
if($LASTEXITCODE -ne 0){Get-Content build/inspect-harmed072.log;exit $LASTEXITCODE}
./gradlew.bat :factory-runtime:check --no-daemon --max-workers=1 -I build/validation072.init.gradle *> build/factory072.log
if($LASTEXITCODE -ne 0){Get-Content build/factory072.log -Tail 25;exit $LASTEXITCODE}
& "$env:JAVA_HOME/bin/javac.exe" -cp 'workspace-engine/build/install/workspace-engine/lib/*' -d build build/ExportUseful072.java
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
@'
from pathlib import Path
import json
j=json.loads(Path('workspace-desktop/test-output/useful072-live.json').read_text(encoding='utf8'))
assert j['passed']
Path('build/app-job072.json').write_text(json.dumps(j['job']),encoding='utf8')
'@ | python -
& "$env:JAVA_HOME/bin/java.exe" -Xmx768m -cp 'build;workspace-engine/build/install/workspace-engine/lib/*' fraymus.workspace.ExportUseful072 build/app-job072.json build/useful-data072.json *> build/export072.log
if($LASTEXITCODE -ne 0){Get-Content build/export072.log;exit $LASTEXITCODE}
python build/compare072.py
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
Get-Content build/factory072.log -Tail 18
Get-Content build/export072.log
