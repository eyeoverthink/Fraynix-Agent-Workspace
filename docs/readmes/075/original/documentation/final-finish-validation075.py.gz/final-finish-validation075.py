from pathlib import Path
import subprocess,json,os,re
r=Path.cwd();out=r/'workspace-desktop/test-output/memory075-1793935649286'
record=json.loads((out/'result.json').read_text(encoding='utf8'));assert record['passed']
bank=Path(record['project'])/'memory-075'/record['studyId']/'bank'
os.environ['JAVA_HOME']='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
os.environ['PATH']=os.environ['JAVA_HOME']+'/bin;'+os.environ['PATH']
os.environ['JAVA_TOOL_OPTIONS']='-XX:ActiveProcessorCount=4 -Xmx768m'
def run(name,args,cwd=r):
 print('START '+name,flush=True)
 with (r/'build'/name).open('wb') as f:subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('PASS '+name,flush=True)
run('native-analysis075.json',['node','scripts/Inspect-Memory075.cjs',str(out),str(bank)])
run('inspector-probes075.json',['node','scripts/Test-Memory075-Inspector.cjs',str(out),str(bank)])
run('final-app075.log',['node','workspace-desktop/test/memory075-final.cjs',str(out)])
run('audit-stop075.log',['node','workspace-desktop/test/memory075-audit-stop.cjs',str(out)])
run('desktop075-final.log',['npm.cmd','test'],r/'workspace-desktop')
t=(r/'build/desktop075-final.log').read_text(encoding='utf8');counts={k:int(re.search(r'^(?:#|\u2139) '+k+r' (\d+)$',t,re.M)[1]) for k in ['tests','pass','fail']};assert counts=={'tests':127,'pass':127,'fail':0}
(r/'build/desktop075.json').write_text(json.dumps(dict(passed=True,**counts),indent=2)+'\n',encoding='utf8')
print('All final validation passed.',flush=True)
