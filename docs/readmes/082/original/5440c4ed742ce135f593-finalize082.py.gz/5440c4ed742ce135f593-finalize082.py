from pathlib import Path
import json,subprocess,hashlib
r=Path.cwd();d=r/'docs/readmes/082'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
def js(p,x):write(p,json.dumps(x,indent=2,ensure_ascii=False)+'\n')
v=load(d/'verification.json');a=v['analysis'];assert a['passed'];p=a['profiles'];total=sum(y['completed'] for x in p for y in x['arms'].values())
def change(n):return f"{abs(n):.2f}% {'lower' if n>=0 else 'higher'}"
result=f"The study completed **{total}/36 planned evaluation goals** across the six continuing-world sequences. The following changes compare two evidence readers with one reader inside each resource budget. Positive percentages mean less elapsed time; negative percentages mean more.\n\n"
for x in p:result+=f"- **{x['budget']['id']}**: complete Java time was {change(x['completeReductionPercent'])}; evidence checking was {change(x['loaderReductionPercent'])}.\n"
result+='\nMatching reader arms retained identical decisions, native work and final states in the independently checked completed pairs. Setup and restart costs remain separate below. These measurements do not establish an automatic best budget.'
validation=f"**{v['javaDistinct']} Java tests across {v['javaClasses']} classes and {v['desktop']['tests']} desktop checks passed**, with no failed or skipped checks. A real persistent Java owner refused a different requested budget and then reconnected under matching limits with the same PID and boot identity. All study launches checked the effective heap bound and CPU count; sampled OS affinity remained within the declared logical processors. Sixteen actual Java API evidence-corruption probes exercised both readers under the tightest study launch settings and restored exact original bytes."
estimated=sum(y['estimated'] for x in p for y in x['arms'].values());lookups=sum(y['lookups'] for x in p for y in x['arms'].values())
result+=f"\n\n**Calibration coverage:** {estimated}/{total} evaluation goals had matching complete-cost estimates; {lookups}/{total} selected remembered execution. The measured outcomes therefore describe the existing verified fallback path when those estimates are unavailable. They do not establish a memory-selection benefit."
next_text=f"This batch recorded {estimated} goals with supported complete-cost estimates and {lookups} goals that selected remembered execution. Those counts matter when interpreting the timing comparison: faster evidence loading alone is not evidence that remembered procedures helped the sequence. Next, collect explicitly matched cold-start and retention workloads, then compare longer sequences against simple control with repeated, counterbalanced runs. Keep any new policy behind the same original outcome checks. Automatic reader selection should wait for those resource/benefit measurements."
text=(r/'build/README-082-template.md').read_text(encoding='utf8').replace('__RESULTS__',result).replace('__TABLE__',(r/'build/table082.md').read_text(encoding='utf8')).replace('__VALIDATION__',validation).replace('__NEXT__',next_text)
for old,new in [('a768MiB','a 768 MiB'),('with512MiB','with 512 MiB'),('with384MiB','with 384 MiB'),('from256 to768','from 256 to 768'),('from1 to4','from 1 to 4'),('Java21','Java 21'),('edition081','edition 081')]:text=text.replace(old,new)
assert '__' not in text;write(r/'README-082.md',text)
summary='; '.join(f"{x['budget']['id']}: reference {x['arms']['reference']['completed']}/6, parallel {x['arms']['parallel']['completed']}/6, complete-time change {x['completeReductionPercent']:.2f}% lower, checking change {x['loaderReductionPercent']:.2f}% lower" for x in p)
entry=f'''\n\n## Edition 082 · Validated locally; publication next

Three measured Java budgets, all on the isolated D:/Codex-Work/fraynix-workspace-edition082 checkout. Prospective contract f2db6ba; parent409afc5. {summary}. {total}/36 planned evaluation goals; each sequence binds continuing world state, restarts after goal three and requests final experience/skill retention. One sequence pair per budget; no statistical generalization or automatic promotion. Historical C: times are not matched evidence. JVM heap limits exclude total native/Electron/OS memory; actual Windows affinity, JVM counters and process samples retained.

{validation}

320 prior compiled engine classes remain byte-identical; the sole modified prior class is WorkspaceServer. Added read-only Resources082 and bounded launch settings. Physics/controllers/proof reader/cost math/GoalRunner/WorldLedger unchanged. Every original byte check, model profile, host report and world commit retained. {estimated} supported estimate decisions / {lookups} remembered executions; cold/retention mismatch fallback remains intact. Source/build receipt checked before and after all profiles. Failed attempts and original evidence retained.

README082, actual screenshots, offline charts/motion replay, complete source/raw inventory and Obsidian90 map prepared. Memory/logs updated. Existing normal045/qa046/private data/services preserved. Push main/edition082/readme-082 and fresh Git verification remain; do not claim publication yet. No subagents or overlapping heavy work. Next: repeated cold/retention calibration and longer-sequence simple-control comparisons before automatic resource policy.
'''
for name in ['AGENTS.md','docs/PROJECT_MEMORY.md','docs/DEVELOPMENT_LOG.md']:
 f=r/name;s=f.read_text(encoding='utf8');i=s.index('\n');write(f,s[:i]+entry+s[i:])
f=r/'README.md';s=f.read_text(encoding='utf8');i=s.index('\n');write(f,s[:i]+'\n\n**Latest: [edition 082 — resource budgets and continuing-world sequences](README-082.md).**\n\nEdition 082 is validated locally; publication verification is pending.\n'+s[i:])
f=r/'docs/readmes/INDEX.md';s=f.read_text(encoding='utf8');i=s.index('\n');write(f,s[:i]+'\n\n- [Edition 082: resource budgets and continuing-world sequences](../../README-082.md) · [Offline results](082/index.html)\n'+s[i:])
note='# Resource budgets and continuing-world sequences\n\n'+summary+'\n\n'+validation+'\n\n'+next_text+'\n\n[[README-082.md|Edition 082]] · [[docs/readmes/082/index.html|Offline results]] · [[docs/readmes/082/verification.json|Actual evidence]]\n';write(r/'docs/obsidian/90-resource-sequences.md',note)
nodes=[{'id':'readme','type':'file','file':'README-082.md','x':0,'y':0,'width':380,'height':250},{'id':'note','type':'file','file':'docs/obsidian/90-resource-sequences.md','x':440,'y':0,'width':380,'height':250},{'id':'limits','type':'file','file':'workspace-desktop/java-budget082.cjs','x':0,'y':310,'width':380,'height':250},{'id':'measure','type':'file','file':'workspace-engine/src/main/java/fraymus/workspace/Resources082.java','x':440,'y':310,'width':380,'height':250},{'id':'evidence','type':'file','file':'docs/readmes/082/verification.json','x':880,'y':310,'width':380,'height':250}]
js(r/'docs/obsidian/resource-sequences.canvas',{'nodes':nodes,'edges':[{'id':'edge'+str(i),'fromNode':x,'toNode':y} for i,(x,y) in enumerate([('readme','note'),('note','limits'),('limits','measure'),('measure','evidence')])]})
f=r/'docs/obsidian/00-home.md';s=f.read_text(encoding='utf8');i=s.index('\n');write(f,s[:i]+'\n\n[[docs/obsidian/90-resource-sequences.md|Edition 082 resource measurements]] · [[docs/obsidian/resource-sequences.canvas|System map]]\n'+s[i:])
f=r/'docs/ARCHITECTURE.md';s=f.read_text(encoding='utf8');i=s.index('\n');write(f,s[:i]+'\n\nEdition 082 adds validated Java launch limits and read-only resource counters. Existing native outcome and world-commit authority is unchanged. See [current measurements](../README-082.md).\n'+s[i:])
print('README082, index, architecture, Obsidian map and current continuity notes prepared')
