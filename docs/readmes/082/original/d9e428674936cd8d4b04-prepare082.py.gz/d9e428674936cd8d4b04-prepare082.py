from pathlib import Path
import json
r=Path.cwd()
p=json.loads((r/'workspace-engine/src/main/resources/procedures081-protocol.json').read_text(encoding='utf8'))
source=p['training'][1]
steps=[
 [[3.65,.21,3.5,95],[1.4,.16,-1.5,-100]],
 [[-1.7,.21,1.6,70],[2.0,.16,-1.6,-85]],
 [[-2.4,.21,-1.8,0],[2.3,.16,1.6,0]],
 [[3.45,.21,3.6,100],[1.6,.16,-1.5,-100]],
 [[-1.4,.21,1.4,50],[2.2,.16,-1.4,-75]],
 [[-2.4,.21,-1.8,0],[2.3,.16,1.6,0]]]
protocol={'edition':82,'parent':'409afc56a86d70d851af58426c4caf8955beaa57','budgets':[{'id':'four-768','processors':4,'heapMiB':768,'order':['reference','parallel']},{'id':'two-512','processors':2,'heapMiB':512,'order':['parallel','reference']},{'id':'one-384','processors':1,'heapMiB':384,'order':['reference','parallel']}], 'training':[source],'calibration':p['calibration'][:2],'source':source['source'],'sequence':[], 'restartAfter':3,'microRepeats':6,'note':'Prospective labelled continuing-world experiment, not physical observations. Goal one is a training-layout regression; the subsequent trajectory is new. One matched sequence pair per budget.'}
for i,coords in enumerate(steps):
 protocol['sequence'].append({'id':f'sequence-{i+1}','targets':[{'sourceId':name,'positionM':x[:3],'yawDeg':x[3]} for name,x in zip(['A','B'],coords)],'forceLimitN':40,'torqueLimitNm':2.5,'retain':i==5,'skillName':'resource-route-082' if i==5 else ''})
dest=r/'workspace-desktop/test/fixtures/procedures082-protocol.json';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(protocol,indent=2)+'\n',encoding='utf8')
pkg=r/'workspace-desktop/package.json';text=pkg.read_text(encoding='utf8');text=text.replace('test/agency043.test.cjs"','test/agency043.test.cjs test/java-budget082.test.cjs"');pkg.write_text(text,encoding='utf8',newline='\n')
base=Path('C:/Users/eyeka/Documents/Codex/2026-10-26/is/work/fraynix-workspace-edition081')
for name in ['regress081.ps1','check-desktop081.py']:
 text=(base/'build'/name).read_text(encoding='utf8').replace('081','082')
 if name.startswith('regress'):text=text.replace("'CalibrationScan082Test'","'Resources082Test','CalibrationScan081Test'")
 (r/'build'/name.replace('081','082')).write_text(text,encoding='utf8',newline='\n')
print('Prepared prospective resource/sequence protocol and validation scripts')
