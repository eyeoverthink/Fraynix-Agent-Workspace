from pathlib import Path
r=Path.cwd();base=Path('C:/Users/eyeka/Documents/Codex/2026-10-26/is/work/fraynix-workspace-edition081/build')
for filename in ['audit-publication081.py','freeze081.py']:
 s=(base/filename).read_text(encoding='utf8').replace('081','082')
 if filename.startswith('freeze'):
  s=s.replace("'b121e65:docs/readmes/editions.json'","'409afc5:docs/readmes/editions.json'").replace("manifest['latest']==80","manifest['latest']==81").replace('number=81','number=82').replace('Faster estimation with complete byte verification','Measured resource limits and continuing-world sequences').replace("manifest['latest']=81","manifest['latest']=82")
 (r/'build'/filename.replace('081','082')).write_text(s,encoding='utf8',newline='\n')
