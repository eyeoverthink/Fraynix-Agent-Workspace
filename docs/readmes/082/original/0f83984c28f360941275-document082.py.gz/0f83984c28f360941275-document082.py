from pathlib import Path
import json,hashlib,gzip,subprocess,shutil,base64,html,xml.etree.ElementTree as ET
r=Path.cwd();d=r/'docs/readmes/082';d.mkdir(parents=True,exist_ok=True)
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
def js(p,x):write(p,json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
analysis=load(r/'build/analysis082.json');assert analysis['passed'];profiles=[];archives=[];seen=set()
def pack(p,logical):
 key=sha(logical.encode())[:20]+'-'+p.name[-50:]+'.gz'
 if key in seen:return
 seen.add(key);raw=p.read_bytes();z=gzip.compress(raw,mtime=0);dest=d/'original'/key;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archives.append({'path':dest.relative_to(r).as_posix(),'logicalPath':logical,'source':str(p),'bytes':len(z),'sha256':sha(z),'rawBytes':len(raw),'rawSha256':sha(raw)})
for summary in analysis['profiles']:
 folder=r/'build'/('ui082-'+summary['budget']['id']);record=load(folder/'result.json');assert record['passed'];entry={'summary':summary,'rows':{}}
 for arm in record['arms']:
  rows=[]
  for row in arm['rows']:
   exported=load(folder/row['originalFile']);replays=[]
   for packet in exported['originals']:
    raw=gzip.decompress(base64.b64decode(packet['gzipBase64']));assert sha(raw)==packet['rawSha256'];run=json.loads(raw);attempt=next(x for x in row['job']['arm']['attempts'] if x['id']==run['id']);n=len(run['samples']);count=min(120,n);indices=sorted(set(round(i*(n-1)/max(1,count-1)) for i in range(count)))
    replays.append({'id':run['id'],'stage':attempt['stage'],'family':attempt['family'],'status':attempt['status'],'originalSampleCount':n,'targets':run['plan']['intent']['targets'],'samples':[{'tick':run['samples'][i]['tick'],'originalSampleIndex':i,'bodies':[{k:b[k] for k in ['id','position','rotation']} for b in run['samples'][i]['bodies']]} for i in indices]})
   rows.append({'id':row['id'],'status':row['status'],'completeMillis':row['goal'].get('taskCost080',{}).get('totalMillis',0),'callerMillis':row['callerMillis'],'revision':row['observed']['expectedRevision'],'decision':row['job']['decision'],'replays':replays})
  entry['rows'][arm['mode']]=rows
 profiles.append(entry)
 for p in folder.glob('*.png'):shutil.copyfile(p,d/(summary['budget']['id']+'-'+p.name))
# Archive all attempts without editing their original files. Synthetic data only.
for folder in sorted((r/'build').glob('ui082-*')):
 if not folder.is_dir():continue
 for p in folder.rglob('*'):
  if p.is_file() and 'desktop-profile' not in p.parts and p.suffix in ['.json','.jsonl','.log','.png','.html','.css','.js','.txt'] and p.name!='host.json':pack(p,'build/'+p.relative_to(r/'build').as_posix())
tests={};classes=set()
for p in (r/'build/regression082').glob('TEST-*.xml'):
 tree=ET.parse(p).getroot();classes.add(tree.attrib['name'])
 for c in tree.findall('testcase'):tests[c.attrib['classname']+'#'+c.attrib['name']]=all(c.find(x) is None for x in ['failure','error','skipped'])
 pack(p,'java/'+p.name)
assert tests and all(tests.values())
for pattern in ['*082*.log','*082*.json','*082*.ps1','*082*.py','guide082.html']:
 for p in (r/'build').glob(pattern):
  if p.is_file():pack(p,'validation/'+p.name)
faults=load(r/'build/ui082-faults/result.json');owner=load(r/'build/owner082-result.json');unchanged=load(r/'build/unchanged082.json');desktop=load(r/'build/desktop082.json');assert faults['passed'] and owner['passed'] and unchanged['passed']
verification={'passed':True,'analysis':analysis,'javaDistinct':len(tests),'javaClasses':len(classes),'javaTests':tests,'desktop':desktop,'owner':owner,'faults':faults,'sourceComparison':unchanged,'studyBuild':load(r/'build/study082-build.json'),'regressionSource':(r/'build/regression082-source.txt').read_text(encoding='utf8').strip(),'scope':'Resource budget study with actual native outcomes. No new physical-camera accuracy, neural training or statistical generalization claim.'}
js(d/'verification.json',verification);js(d/'original-evidence.json',{'files':archives,'note':'Exact compressed originals, including any failed attempts; synthetic study projects. Original paths are provenance, not required at replay time.'});js(d/'comparison-data.json',{'profiles':profiles})
old=load(r/'docs/readmes/081/file-inventory.json');paths={x['path'] for x in old};paths.update(x for x in subprocess.check_output(['git','diff','--name-only','--diff-filter=A','409afc5','HEAD'],text=True).splitlines() if x.startswith(('workspace-engine/','workspace-desktop/','scripts/','fraynix-modules/')))
inventory=[]
for name in sorted(paths):
 raw=(r/name).read_bytes()
 try:b=raw.decode('utf8').replace('\r\n','\n').encode();kind='utf8-lf'
 except UnicodeDecodeError:b=raw;kind='binary'
 inventory.append({'path':name,'bytes':len(b),'sha256':sha(b),'hashKind':kind})
js(d/'file-inventory.json',inventory);write(d/'FILE_TREE.md','# Edition 082 complete source inventory\n\n'+ '\n'.join('- ['+x['path']+'](../../../'+x['path']+')' for x in inventory)+'\n')
module_specs=[('budget','Resource limits','workspace-desktop/java-budget082.cjs','Strict startup limits in both Java lifetimes; a running owner is never silently replaced.'),('measure','Actual JVM counters','workspace-engine/src/main/java/fraymus/workspace/Resources082.java','Read-only heap, process CPU and garbage collection measurements.'),('reader','Original evidence checks','workspace-engine/src/main/java/fraymus/workspace/CalibrationScan081.java','One or two readers check the same original bytes, join and compare.'),('world','Continuing world','workspace-engine/src/main/java/fraymus/workspace/WorldProcedure079.java','Unchanged native forecasts, actual motion, outcome checks and persistent commits.'),('inspect','Independent inspection','scripts/Inspect-Procedures082.cjs','Original-byte/native arithmetic/commit inspection and resource accounting.')]
shots=[('four-768-parallel-goal-6-report.png','Completed sixth goal, four-processor budget'),('one-384-parallel-continuing-world.png','Continuing world under the one-processor budget'),('one-384-parallel-saved-skill.png','Saved skill and verified report after reopening')]
system={'modules':[{'id':i,'name':n,'source':s,'description':t,'note':'docs/obsidian/90-resource-sequences.md'} for i,n,s,t in module_specs],'screenshots':[{'path':'docs/readmes/082/'+p,'caption':c} for p,c in shots],'evidence':[{'path':'docs/readmes/082/verification.json','caption':'Validation and measurements'},{'path':'docs/readmes/082/original-evidence.json','caption':'Exact original archives'}]};js(d/'system-map.json',system)
guide=(r/'build/guide082.html').read_text(encoding='utf8').replace('__DATA__',json.dumps({'profiles':profiles},separators=(',',':')).replace('</','<\\/')).replace('__SYSTEM__',json.dumps(system)).replace('__INVENTORY__',json.dumps(inventory)).replace('__SCREENSHOTS__',''.join('<figure><a href="'+p+'"><img src="'+p+'" alt="'+html.escape(c)+'" loading="lazy"></a><figcaption>'+html.escape(c)+' · actual app, November 6, 2026.</figcaption></figure>' for p,c in shots));write(d/'index.html',guide)
table='| Budget | Reader | Completed | Java seconds | Check seconds | CPU seconds | Sampled private MiB |\n|---|---|---:|---:|---:|---:|---:|\n'
for x in analysis['profiles']:
 for mode,a in x['arms'].items():table+=f"| {x['budget']['id']} | {mode} | {a['completed']}/6 | {a['completeMillis']/1000:.2f} | {a['loadMillis']/1000:.3f} | {a['cpuMillis']/1000:.2f} | {a['peakSampledPrivateBytes']/1048576:.1f} |\n"
write(r/'build/table082.md',table)
print(json.dumps({'prepared':True,'archives':len(archives),'sources':len(inventory),'java':len(tests),'classes':len(classes)}))
