from pathlib import Path
import re,json
s=Path('build/desktop082.log').read_text(encoding='utf8')
x={k:int(re.search(r'^(?:#|\u2139)\s+'+k+r' (\d+)',s,re.M).group(1)) for k in ['tests','pass','fail','skipped','cancelled','todo']}
assert x['tests']==x['pass'] and all(x[k]==0 for k in ['fail','skipped','cancelled','todo'])
x.update(passed=True,source=Path('build/regression082-source.txt').read_text(encoding='utf8').strip())
Path('build/desktop082.json').write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
print(json.dumps(x))
