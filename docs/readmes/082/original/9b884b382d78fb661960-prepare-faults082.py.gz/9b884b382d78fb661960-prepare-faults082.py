from pathlib import Path
r=Path.cwd();p=r/'workspace-desktop/test/procedures082-faults.cjs'
s=(r/'workspace-desktop/test/procedures081-faults.cjs').read_text(encoding='utf8').replace('FRAYNIX081_PRIMARY','FRAYNIX082_PRIMARY').replace('../build/ui081-primary','../build/ui082-one-384').replace('FRAYNIX081_FAULTS_OUTPUT','FRAYNIX082_FAULTS_OUTPUT').replace('../build/ui081-faults','../build/ui082-faults')
needle="try{await save();({app}=await launch(project));assert.deepEqual"
extra="""try{await save();({app}=await launch(project));
  const repo=path.resolve(__dirname,'../..');record.resources=await api('/api/resources082/state');assert.equal(record.resources.profile.cpus,1);assert.equal(record.resources.configuredMaxHeapBytes,384*1024*1024);
  const osRead=action=>JSON.parse(require('node:child_process').execFileSync('pwsh',['-NoProfile','-File',path.join(repo,'scripts/Measure-Resources082.ps1'),'-Action',action,'-TargetPid',String(record.resources.pid),'-Processors','1','-Checkout',repo],{encoding:'utf8',windowsHide:true}));
  record.pinned=osRead('pin');assert.equal(BigInt(record.pinned.affinity).toString(2).split('1').length-1,1);
  assert.deepEqual"""
assert needle in s;s=s.replace(needle,extra)
s=s.replace("record.passed=true;await fs.writeFile", "record.finalOS=osRead('read');assert.equal(record.finalOS.affinity,record.pinned.affinity);record.passed=true;await fs.writeFile")
p.write_text(s,encoding='utf8',newline='\n')
f=r/'build/run082.ps1';s=f.read_text(encoding='utf8').replace('FRAYNIX081_PRIMARY','FRAYNIX082_PRIMARY').replace('FRAYNIX081_FAULTS_OUTPUT','FRAYNIX082_FAULTS_OUTPUT').replace('test/procedures081-faults.cjs','test/procedures082-faults.cjs');f.write_text(s,encoding='utf8',newline='\n')
