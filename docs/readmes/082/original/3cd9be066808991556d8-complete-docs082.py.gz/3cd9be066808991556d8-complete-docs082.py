from pathlib import Path
import json,gzip,hashlib,shutil
r=Path.cwd();d=r/'docs/readmes/082';sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def js(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf8',newline='\n')
review=load(r/'build/docs082-review/result.json');visual=load(r/'build/visual-review082.json');assert review['passed'] and visual['passed']
v=load(d/'verification.json');v['offlineReview']=review;v['visualReview']=visual;js(d/'verification.json',v)
original=load(d/'original-evidence.json');seen={x['logicalPath'] for x in original['files']}
for p in [*sorted((r/'build/docs082-review').glob('*')),r/'build/visual-review082.json',r/'build/documentation082-browser.log']:
 if not p.is_file():continue
 logical='validation/'+p.relative_to(r/'build').as_posix()
 if logical in seen:continue
 raw=p.read_bytes();z=gzip.compress(raw,mtime=0);dest=d/'original'/(sha(logical.encode())[:20]+'-'+p.name[-50:]+'.gz');dest.write_bytes(z);original['files'].append({'path':dest.relative_to(r).as_posix(),'logicalPath':logical,'source':str(p),'bytes':len(z),'sha256':sha(z),'rawBytes':len(raw),'rawSha256':sha(raw)})
 if p.suffix=='.png':shutil.copyfile(p,d/('offline-'+p.name))
js(d/'original-evidence.json',original)
print('Retained actual offline browser interactions, captures and visual review before freezing')
