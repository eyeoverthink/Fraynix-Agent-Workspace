from pathlib import Path
import json,hashlib,subprocess,gzip,re
r=Path.cwd()
def canonical(p,binary=False):
 b=p.read_bytes();return b if binary else b.decode('utf-8-sig').replace('\r\n','\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
p=r/'docs/readmes/editions.json';manifest=json.loads(p.read_text(encoding='utf-8-sig'))
prior=json.loads(subprocess.check_output(['git','show','409afc5:docs/readmes/editions.json']).decode('utf8'))
assert manifest==prior and manifest['latest']==81
entry=dict(number=82,date='2026-11-06',title='Measured resource limits and continuing-world sequences',status='validated-local',markdown='README-082.md',markdownSha256=sha(canonical(r/'README-082.md')),companion='docs/readmes/082/index.html',tag='readme-082',sourceBaseline=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),snapshotDirectory='docs/readmes/082',snapshotFiles=[])
for f in sorted((r/'docs/readmes/082').rglob('*')):
 if f.is_file():
  binary=f.suffix in ['.png','.gz'];entry['snapshotFiles'].append(dict(path=f.relative_to(r).as_posix(),kind='binary' if binary else 'text',sha256=sha(canonical(f,binary))))
manifest['latest']=82;manifest['editions'].append(entry)
patterns=[rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{40,}',rb'sk-[A-Za-z0-9_-]{30,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
scanned=0
for f in (r/'docs/readmes/082').rglob('*'):
 if f.is_file() and f.suffix!='.png':
  b=gzip.decompress(f.read_bytes()) if f.suffix=='.gz' else f.read_bytes();scanned+=1
  for pattern in patterns:assert not re.search(pattern,b),('Credential signature found',str(f))
p.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(dict(frozenFiles=len(entry['snapshotFiles']),credentialSignatureScanFiles=scanned,earlierEditionsUnchanged=True)))
