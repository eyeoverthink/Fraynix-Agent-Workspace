from pathlib import Path
import subprocess,json
r=Path.cwd()
def run(*a,**kw):return subprocess.run(a,check=True,**kw)
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
assert json.loads((r/'build/documentation-check.json').read_text(encoding='utf8'))['passed']
run('git','fetch','origin','main');run('git','merge-base','--is-ancestor','origin/main','HEAD')
files=['AGENTS.md','README.md','README-082.md','docs/PROJECT_MEMORY.md','docs/DEVELOPMENT_LOG.md','docs/ARCHITECTURE.md','docs/obsidian/00-home.md','docs/obsidian/90-resource-sequences.md','docs/obsidian/resource-sequences.canvas','docs/readmes/INDEX.md','docs/readmes/editions.json','docs/readmes/082']
run('git','add',*files);run('git','diff','--cached','--check');run('git','-c','gc.auto=0','commit','-m','Document edition 082 resource measurements, continuing worlds and exact evidence')
release=git('rev-parse','HEAD');print('Release',release,flush=True);run('python','build/audit-publication082.py','HEAD',release)
run('git','tag','-a','readme-082','-m','Edition 082: measured resource budgets and verified continuing-world sequences')
with (r/'build/push082.log').open('wb') as f:run('git','-c','pack.threads=4','push','--no-thin','--atomic','origin','HEAD:refs/heads/main','HEAD:refs/heads/edition082','refs/tags/readme-082',stdout=f,stderr=subprocess.STDOUT)
print((r/'build/push082.log').read_text(encoding='utf8'),flush=True)
run('git','fetch','origin','refs/heads/main:refs/verify/edition082-main','refs/heads/edition082:refs/verify/edition082-branch','refs/tags/readme-082:refs/verify/edition082-tag')
assert git('rev-parse','refs/verify/edition082-branch')==release
assert git('rev-parse','refs/verify/edition082-tag^{commit}')==release
run('python','build/audit-publication082.py','refs/verify/edition082-main',release)
