from pathlib import Path
import subprocess,json,gzip
r=Path.cwd()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
def js(p,x):write(p,json.dumps(x,indent=2)+'\n')
a=load(r/'build/publication-audit082.json');assert a['passed'] and a['remoteFetched'];release=a['commit'];tag=git('rev-parse','refs/verify/edition082-tag');assert git('rev-parse','refs/verify/edition082-tag^{commit}')==release
v=load(r/'docs/readmes/082/verification.json');doc=load(r/'build/documentation-check.json');assert doc['passed']
js(r/'docs/publication082/release-audit.json',a);js(r/'docs/publication082/documentation.json',doc);(r/'docs/publication082/push.log.gz').write_bytes(gzip.compress((r/'build/push082.log').read_bytes(),mtime=0))
js(r/'docs/PUBLICATION_082.json',{**a,'releaseCommit':release,'annotatedTag':'readme-082','tagObject':tag,'publishedRefs':['refs/heads/main','refs/heads/edition082','refs/tags/readme-082'],'documentation':doc,'evidence':'docs/readmes/082/verification.json'})
p=r/'README.md';s=p.read_text(encoding='utf8');old='Edition 082 is validated locally; publication verification is pending.';assert old in s;write(p,s.replace(old,'Edition 082 is published to main with code, measurements, screenshots and original evidence. [Fetched GitHub verification](docs/PUBLICATION_082.json).'))
result='; '.join(f"{x['budget']['id']}: {x['arms']['reference']['completed']}/6 reference, {x['arms']['parallel']['completed']}/6 parallel, complete-time change {x['completeReductionPercent']:.2f}% lower, checking change {x['loaderReductionPercent']:.2f}% lower" for x in v['analysis']['profiles'])
entry=f'''\n\n## Edition 082 · Published and fetched back on 2026-11-06

Atomic no-thin push to Fraynix-Agent-Workspace main, edition082 and readme-082 succeeded. Release {release}; annotated tag {tag}. Freshly fetched Git trees verified {a['canonicalSourceFiles']} canonical sources, {a['frozenHashes']} frozen hashes across82 editions, and {a['original082EvidenceFiles']} exact original archives including decompressed bytes. Documentation passes {doc['canvases']} canvases and {doc['references']} references. [Publication receipt](docs/PUBLICATION_082.json).

{result}. One matched six-goal sequence pair per budget on D:; historical C: times are not a matched baseline. All original verification retained, no automatic policy promotion or model-weight learning claim. JVM heap is distinct from total process memory; actual affinity, CPU/GC and OS memory evidence retained. Fresh profile-specific setup costs and restart/retention boundaries reported separately.

{v['javaDistinct']} Java tests/{v['javaClasses']} classes and {v['desktop']['tests']} desktop checks pass. Actual owner-budget mismatch refusal/reconnect, continuing-world/cold-restart/skill persistence, independent source/native/cost/commit inspection, tight-budget original-evidence refusal and actual app/offline visual checks recorded. Original physics/controllers/GoalRunner/ledger/proof/cost classes unchanged. README082, actual captures, source/original inventory, Obsidian90/map and notes published. Test apps closed; normal045/qa046/private data preserved. Next: repeated cold/retention calibration and longer-sequence simple-control comparisons before automatic resource policy. This receipt follows the immutable release tag.
'''
for name in ['AGENTS.md','docs/PROJECT_MEMORY.md','docs/DEVELOPMENT_LOG.md']:
 p=r/name;s=p.read_text(encoding='utf8');i=s.index('\n');write(p,s[:i]+(entry.replace('](docs/','](') if name.startswith('docs/') else entry)+s[i:])
print('Prepared receipt for verified GitHub release',release)
