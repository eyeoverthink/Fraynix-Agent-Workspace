param([ValidateSet('owner','four-768','two-512','one-384','faults')][string]$Mode)
$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$env:JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=4 -Xmx768m'
$env:PATH=$env:JAVA_HOME+'/bin;'+$env:PATH
Push-Location workspace-desktop
try{
 if($Mode -eq 'owner'){
  & node test/resources082-owner.cjs *> ../build/owner082.log
 }elseif($Mode -eq 'faults'){
  $env:FRAYNIX_WORKSPACE_JAVA_HEAP_MIB='384';$env:FRAYNIX_WORKSPACE_JAVA_PROCESSORS='1'
  $env:FRAYNIX082_PRIMARY='../build/ui082-one-384';$env:FRAYNIX082_FAULTS_OUTPUT='../build/ui082-faults'
  & node test/procedures082-faults.cjs *> ../build/faults082.log
 }else{
  & node test/procedures082-integration.cjs $Mode *> ('../build/integration082-'+$Mode+'.log')
 }
 if($LASTEXITCODE){throw ('Edition082 '+$Mode+' failed; preserve original output')}
}finally{Pop-Location}
