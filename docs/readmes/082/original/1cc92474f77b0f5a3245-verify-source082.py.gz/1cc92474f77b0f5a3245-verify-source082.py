from pathlib import Path
import json,hashlib,zipfile,subprocess
r=Path.cwd();base=Path('C:/Users/eyeka/Documents/Codex/2026-10-26/is/work/fraynix-workspace-edition081')
sha=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads((base/'docs/readmes/081/file-inventory.json').read_text(encoding='utf8'))
changed=[];same=[]
for row in old:
 b=(r/row['path']).read_bytes()
 if row['hashKind']=='utf8-lf':b=b.decode('utf8').replace('\r\n','\n').encode()
 (same if sha(b)==row['sha256'] else changed).append(row['path'])
allowed={'workspace-desktop/main.cjs','workspace-desktop/runtime-connection042.cjs','workspace-desktop/package.json','workspace-engine/src/main/java/fraymus/workspace/WorkspaceServer.java'}
assert set(changed)==allowed,changed
lib='workspace-engine/build/install/workspace-engine/lib/workspace-engine.jar'
classes=[];class_changed=[]
with zipfile.ZipFile(base/lib) as a,zipfile.ZipFile(r/lib) as b:
 for name in a.namelist():
  if not name.endswith('.class'):continue
  (classes if a.read(name)==b.read(name) else class_changed).append(name)
assert set(class_changed)=={'fraymus/workspace/WorkspaceServer.class'},class_changed
result={'passed':True,'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'baseline':'409afc56a86d70d851af58426c4caf8955beaa57','unchangedCanonicalSourceCount':len(same),'changedCanonicalSources':changed,'unchangedCompiledClasses':len(classes),'changedCompiledClasses':class_changed,'scope':'Every original canonical source compared; every original workspace-engine class compared directly against installed edition081. Physics, controllers, proof reader, cost arithmetic, GoalRunner and WorldLedger unchanged.'}
(r/'build/unchanged082.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result))
