const {chromium}=require('../workspace-desktop/node_modules/playwright');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{pathToFileURL,fileURLToPath}=require('node:url');
(async()=>{
 const d=path.resolve('docs/readmes/073'),data=JSON.parse(fs.readFileSync(path.join(d,'replay-data.json'),'utf8')),b=await chromium.launch({channel:'msedge',headless:true}),checks=[],errors=[];
 try{for(const width of [1440,390]){
  const p=await b.newPage({viewport:{width,height:1000}});p.on('pageerror',e=>errors.push(e.message));
  await p.goto(pathToFileURL(path.join(d,'index.html')).href);
  await p.waitForFunction(()=>document.images.length>5&&[...document.images].every(i=>i.complete&&i.naturalWidth>0));
  assert.equal(await p.locator('#case option').count(),4);
  for(let i=0;i<data.length;i++){
   await p.locator('#case').selectOption(String(i));const sample=data[i];
   const bodies=sample.definition.objects.filter(o=>o.massKg>0);assert.equal(await p.locator('#body option').count(),bodies.length);
   for(const body of bodies){
    await p.locator('#body').selectOption(body.id);
    for(const frame of [0,Math.floor(sample.actual.length/2),sample.actual.length-1]){
     await p.locator('#frame').fill(String(frame));await p.locator('#frame').dispatchEvent('input');
     const actual=sample.actual[frame],pos=actual.bodies.find(o=>o.id===body.id).position;
     assert((await p.locator('#frame-info').innerText()).includes('Tick '+actual.tick));
     assert((await p.locator('#plot').textContent()).includes(pos[0].toFixed(4)+'m'));
     assert.equal((await p.locator('#plot polyline').last().getAttribute('points')).split(' ').length,sample.actual.length);
    }
   }
   assert((await p.locator('#lineage').innerText()).includes(sample.child));
   assert((await p.locator('#metrics').innerText()).includes('failed'));
  }
  await p.locator('#case').selectOption('0');await p.locator('#play').click();
  await p.waitForFunction(()=>Number(document.getElementById('frame').value)>2);await p.locator('#play').click();
  const paused=await p.locator('#frame').inputValue();await p.waitForTimeout(150);assert.equal(await p.locator('#frame').inputValue(),paused);
  await p.locator('#map button').last().click();assert.equal(await p.locator('#module-title').innerText(),'Integrated witness');
  assert((await p.locator('#module-source').getAttribute('href')).endsWith('rehearsal073.js'));
  await p.locator('#filter').fill('Rehearsal073.java');assert.equal(await p.locator('#files li').count(),1);
  await p.locator('#filter').fill('');
  for(const href of await p.locator('a').evaluateAll(a=>a.map(x=>x.href))){const u=new URL(href);if(u.protocol==='file:')assert(fs.existsSync(fileURLToPath(u)),href);}
  await p.getByRole('link',{name:'Actual app',exact:true}).click();assert.equal(new URL(p.url()).hash,'#screens');
  await p.evaluate(()=>window.scrollTo(0,0));assert(await p.evaluate(()=>document.documentElement.scrollWidth<=document.documentElement.clientWidth+1));
  await p.screenshot({path:path.join(d,'guide-'+width+'.png')});
  await p.locator('#replay').scrollIntoViewIfNeeded();await p.screenshot({path:path.join(d,'guide-replay-'+width+'.png')});
  checks.push({width,cases:4,allBodies:true,initialMiddleFinalSamples:true,actualAndForecast:true,playPause:true,lineage:true,failedAlternatives:true,moduleSelection:true,sourceSearch:true,localLinks:true,images:await p.locator('img').count(),noOverflow:true});await p.close();
 }
 assert.deepEqual(errors,[]);fs.writeFileSync(path.join(d,'documentation-browser.json'),JSON.stringify({passed:true,browser:'Installed Microsoft Edge',checks,errors},null,2)+'\n');console.log(JSON.stringify(checks));
 }finally{await b.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
