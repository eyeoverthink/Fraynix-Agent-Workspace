from pathlib import Path
import json,hashlib,gzip,subprocess,shutil,sys,html,re,xml.etree.ElementTree as ET
r=Path.cwd();out=Path(sys.argv[1]);d=r/'docs/readmes/073';d.mkdir(parents=True,exist_ok=True)
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
result=json.loads((out/'result.json').read_text(encoding='utf8'));assert result['passed']
final=json.loads((r/'build/final-app073.json').read_text(encoding='utf8'));assert final['passed']
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();archives=[];packed_paths=set()
def pack(p,dest):
 if str(dest) in packed_paths:return
 packed_paths.add(str(dest))
 b=p.read_bytes();z=gzip.compress(b,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archives.append(dict(path=dest.relative_to(r).as_posix(),bytes=len(z),sha256=sha(z),rawBytes=len(b),rawSha256=sha(b),source=str(p)))
for directory in [out,*sorted((r/'workspace-desktop/test-output').glob('rehearsal073-*'))]:
 for p in sorted(directory.glob('*')):
  dest=d/'original/app'/directory.name/(p.name+'.gz')
  if p.is_file() and p.suffix in ['.json','.txt','.log']:pack(p,dest)
for p in sorted((r/'build').glob('*073*.log')):pack(p,d/'original/logs'/(p.name+'.gz'))
for p in sorted((r/'build/development073-first').glob('*')):
 if p.is_file():pack(p,d/'original/development-first'/(p.name+'.gz'))
cases={};invocations=[]
for folder in ['focused073','regression073','factory073']:
 rows=[]
 for p in sorted((r/'build'/folder).glob('TEST-*.xml')):
  tree=ET.parse(p).getroot()
  for c in tree.findall('testcase'):
   key=c.attrib['classname']+'#'+c.attrib['name'];passed=all(c.find(n) is None for n in ['failure','error','skipped']);cases[key]=passed;rows.append(dict(case=key,passed=passed))
  pack(p,d/'original/java'/folder/(p.name+'.gz'))
  for native_path in re.findall(r'MEMORY073_NATIVE_SOURCE ([^\r\n<]+)',p.read_text(encoding='utf8')):
   for name in ['original.json','reconstruction.json']:
    pack(Path(native_path)/name,d/'original/java'/folder/(name+'.gz'))
 if rows:invocations.append(dict(name=folder,cases=rows))
assert cases and all(cases.values())
for name in ['final-app073.json','final-replay073.json','native-analysis073.json','desktop073.json','source-isolation.json']:
 p=r/'build'/name;assert p.exists();pack(p,d/'original/logs'/(name+'.gz'))
if (r/'build/backup073.json').exists():pack(r/'build/backup073.json',d/'original/logs/backup073.json.gz')
for name in ['document073.py','guide073.html']:pack(r/'build'/name,d/'original/documentation'/(name+'.gz'))
for p in sorted(out.glob('*.png')):shutil.copyfile(p,d/p.name)
for p in sorted((r/'build/final-captures073').glob('*.png')):shutil.copyfile(p,d/p.name)
data=[]
for row in result['variants']:
 g=row['goal'];m=g['rehearsal073'];name=m['change']['property']+'-'+str(m['change']['after']);replay=json.loads((out/(name+'-originals.json')).read_text(encoding='utf8'));actual=replay['actual'];forecast=None
 for item in replay['alternatives']['originalAttempts']:
  packed=item['run'];raw=gzip.decompress(__import__('base64').b64decode(packed['gzipBase64']));assert sha(raw)==packed['rawSha256'];run=json.loads(raw)
  if run['id']==g['counterfactual045']['comparison']['forecastRunId']:forecast=run
 assert forecast
 data.append(dict(change=m['change'],goalId=g['id'],parent=m['parentEpisodeId'],child=m['childEpisode']['id'],world=g['worldBinding']['worldId'],revision=g['worldCommit']['revision'],rebuild=m['rebuild'],comparison=g['counterfactual045']['comparison'],costs=m['costs'],retrievalMillis=m['retrieval']['millis'],rebuildAttempts=m['rebuildAttempts'],candidates=g['counterfactual045']['candidates'],definition=actual['definition'],actual=[dict(tick=f['tick'],bodies=f['bodies']) for f in actual['samples']],forecast=[dict(tick=f['tick'],bodies=f['bodies']) for f in forecast['samples']]))
js(d/'replay-data.json',data)
paths={x['path'] for x in json.loads((r/'docs/readmes/072/file-inventory.json').read_text(encoding='utf8'))}
paths.update(x for x in subprocess.check_output(['git','diff','--name-only','--diff-filter=A','3aace07','HEAD'],text=True).splitlines() if x.startswith(('workspace-engine/','workspace-desktop/','scripts/','fraynix-modules/')))
inventory=[]
for name in sorted(paths):
 b=(r/name).read_bytes()
 try:b=b.decode('utf8').replace('\r\n','\n').encode();kind='utf8-lf'
 except UnicodeError:kind='binary'
 inventory.append(dict(path=name,bytes=len(b),hashKind=kind,sha256=sha(b)))
js(d/'file-inventory.json',inventory);write(d/'FILE_TREE.md','# Edition073 complete source tree\n\n[Canonical bytes and hashes](file-inventory.json).\n\n```text\n'+'\n'.join(x['path'] for x in inventory)+'\n```\n')
verification=dict(edition=73,source=source,contract='4a1168d',implementation='c89b021',javaDistinct=len(cases),javaClasses=len({k.split('#')[0] for k in cases}),javaAllPassed=True,javaInvocations=invocations,desktop=json.loads((r/'build/desktop073.json').read_text()),actualApp=result['checks'],finalApp=final,analysis=json.loads((r/'build/native-analysis073.json').read_text()),scope='Initial-at-rest declared native box worlds. No physical calibration, arbitrary moving restore, retrieval speedup, LLM-weight training or new engine claim.')
verification['additionalHarnesses']=['FactoryRuntimeTest','WorldTransactionTest','JournalContinuityTest','LocalSkillsTest','FactoryKernelIntegrationTest']
verification['harnessQualification']='Passed in regression073.log; separate main-method harnesses, not added to the JUnit count. Symlink creation was unavailable to LocalSkillsTest; traversal and absolute-path checks ran.'
verification['modelQualification']='Actual deterministic Java chat route verified; zero new LLM planning calls. Selected model shown in screenshots is not a new inference test.'
js(d/'verification.json',verification);js(d/'original-evidence.json',dict(format='Exact original bytes, including failed development attempts, compressed with gzip; synthetic isolated validation projects only.',files=archives))
modules=[('memory','Verified episode memory','Rehearsal073.java','Owned immutable source, native trace, report, commit and parent/child lineage.'),('goals','Reconstruct and execute','GoalRunner.java','One goal owns reconstruction, alternatives, fresh action, original checks and final retention.'),('alternatives','Bounded physical alternatives','Counterfactual045.java','Preserved existing controller-order, reverse-order and half-force candidates; failures retained.'),('world','Persistent verified world','WorldLedger.java','Separate variant, exact revision ownership, stale refusal and verified commit.'),('chat','Java chat planning','Domain044.java','Typed experiment.rehearse; exact requested role, component, value and review intent.'),('view','Integrated witness','rehearsal073.js','Original/rebuilt/forecast/actual native replay with byte-checked compressed traces.')]
mapping=[dict(id=i,name=n,source=('workspace-desktop/renderer/' if p.endswith('.js') else 'workspace-engine/src/main/java/fraymus/workspace/')+p,description=t) for i,n,p,t in modules];js(d/'system-map.json',mapping)
rows='\n'.join('| '+x['change']['property']+' | '+str(x['change']['before'])+' → '+str(x['change']['after'])+' | '+str(x['rebuild']['maxPositionResidualM'])+' | '+str(x['comparison']['maxPositionResidualM'])+' | '+str(sum(c['status']=='completed' for c in x['candidates']))+'/3 | '+str(x['revision'])+' |' for x in data)
readme=f'''# Fraynix Agent Workspace · Edition073

**Executable experiment memory: retrieve, reconstruct, vary, compare and verify.** November5,2026.

[Previous edition072](README-072.md) · [Offline interactive guide](docs/readmes/073/index.html) · [Complete source tree](docs/readmes/073/FILE_TREE.md) · [Verification](docs/readmes/073/verification.json) · [Exact original evidence](docs/readmes/073/original-evidence.json) · [Edition history](docs/readmes/INDEX.md)

## From a remembered experiment to a fresh result

The user's idea was to treat the runtime as a place where the agent can try an idea, observe the outcome and retain an executable memory. Edition073 implements the first complete version of that loop in the existing Java goal runner. A memory contains the original source state, physical properties, controller plan, every retained native motion sample, original report identity and committed world outcome. It can be reconstructed and tested again. Its description alone does not establish success.

The app remains one integrated workspace. Java owns episode identity, retrieval, state reconstruction, task progress and verification. The desktop presents the world, chat, replay and original charts. Existing native physics and the virtual force/torque gripper remain the execution layer. No external memory framework, model download, remote service or separate editor was added. The existing Bullet/Minie, Chromium/Electron and JSON dependencies remain; this is owned Java orchestration over the current engine, not a claim that all of those dependencies were rewritten.

![Actual linked experiment evidence](docs/readmes/073/friction-0.2-evidence.png)

*Actual app capture from the isolated labelled validation project. The UI connects the remembered original, reconstruction, changed component, alternatives, child episode and world revision.*

## What is implemented

1. **Remember a verified experiment.** Select a completed persistent-world arrangement. Java rechecks its original native trace, report and world commit. A stored `passed` label or imported JSON cannot create that authority. Repeating the operation returns the same episode instead of duplicating it.
2. **Retrieve a compatible starting point.** An explicit episode ID is supported. Without one, Java filters incompatible memories and ranks the remaining episodes by the requested source role, property and normalized distance from the new value, with stable ID ties. It records the ranking, exclusions and retrieval time. This is a transparent local rule, not semantic neural retrieval.
3. **Reconstruct before changing anything.** The original source and original controller plan run in a separate native world. Sample coverage, position and orientation residuals are checked against the saved trace. A failed reconstruction stops the workflow before changed alternatives or live action.
4. **Substitute one component.** Friction or a dynamic body's mass changes by stable source role. Geometry, declared units, gravity, other components and target poses remain the same. The entire changed plan is validated before creating its import and separate persistent world.
5. **Run bounded alternatives.** The existing policy tries controller order, reversed target order and half force. It retains failures and applies the original admissibility and ranking rules. A visual replay does not substitute for native simulation.
6. **Execute and compare.** The chosen plan runs again under ownership of the variant world's current revision. Java compares prediction with actual motion and checks the original body, force, torque, release and protected-body gates.
7. **Verify the visible report and retain the result.** The existing canvas must pass its13 original assertions. Only then can the world advance and a linked child episode be retained. Export contains parent, reconstruction, all original alternative attempts and actual execution.

```mermaid
flowchart LR
  A[Completed verified goal] --> B[Immutable episode]
  B --> C[Cold reconstruction and comparison]
  C --> D[One component variant]
  D --> E[Three bounded native alternatives]
  E --> F[Optional review pause]
  F --> G[Fresh owned execution]
  G --> H[Prediction, native and visible report checks]
  H --> I[World revision and linked child]
  I --> B
```

## Try it step by step

Open **Spatial → One evolving world → Experiment memory**. Start with an ordinary labelled world arrangement and finish its actual verification. Select that completed goal and press **Remember verified experiment**. A descriptive chat answer on its own is not an eligible experiment.

Choose the remembered experiment, its actual object role, a component and the new value. Press **Rehearse through chat**. The button sends the same typed request available through chat. For the labelled test source, an example is: `Rehearse experiment, change A friction to0.2 and execute.` An explicit UUID after `experiment` selects that memory; otherwise Java ranks eligible memories. Use `massKg` for payload mass. Missing or ambiguous component requests are refused with an actionable explanation.

Select **Review alternatives before moving** to pause after prediction. In chat, `review before executing` requests the same pause. A request without explicit execution also defaults to review. Resume rechecks the chosen plan against the current world head. Changing that head while review is paused invalidates the old decision.

The variant is a separate saved world. The original user world remains intact. The normal integrated world view observes the accepted task without changing another tool's action binding. **Open variant world** returns to its actual retained state. Use the existing Java goal Stop and Resume controls; a stopped or refused task does not earn a successful child memory.

Select a retained rehearsal and press **Load linked replay**. Choose the parent, reconstruction, an alternative, or actual execution. Scrub the frame slider or play the recorded samples. The top/front projections use the original positions and quaternions, labelled in metres and native ticks. A dashed forecast accompanies the actual run at matching ticks. The original full trace remains available through JSON export. Replay cannot write poses or issue forces.

![Actual motion replay](docs/readmes/073/final-replay.png)

*Final app capture: recorded native geometry and motion after interruption, restart and explicit recovery. The projection fits oriented geometry and uses equal metre scale.*

## Measured results and costs

The frozen acceptance values were friction0.2 and1.2, mass0.7kg and1.5kg, a20kg unsupported request and malformed/static-body changes. The full app ran each accepted variant through actual chat, native execution and canvas verification. All four accepted variants completed and retained linked children. Every original source reconstruction matched its retained samples; these are deterministic simulator results, not a measurement of physical-camera accuracy.

| Component | Original → changed | Rebuild max position residual · m | Forecast/actual max position residual · m | Completed alternatives | Committed revision |
| --- | --- | --- | --- | --- | --- |
{rows}

Each full case contains one reconstruction, three alternative executions and one fresh actual execution. Failed low-force alternatives remain in the comparison and exported evidence. The original source world was compared before and after the variants and restart and remained unchanged. The checks also covered cold app/Java restart, idempotent retention, review before movement, changed-head refusal, Stop without promotion, a real exported JSON file and wide/narrow layouts.

A fifth follow-up selected a compatible memory automatically from five retained episodes, then interrupted an actually running reconstruction by closing the app and Java. After restart, explicit Resume created a fresh reconstruction while preserving the interrupted attempt. The friction 0.65 variant completed all checks and retained its child. A separate Stop during an actually running reconstruction left revision zero and no child. The final app had no recorded page errors.

The portable [trace inspector](scripts/Inspect-Rehearsal073.cjs) independently recomputed motion, component differences, force/torque effort, protected-body drift, ranking and lineage from all five exported cases. Six controlled altered exports were rejected. This is independent arithmetic over saved native outputs, not a second physics solver. Actual chat used the deterministic Java procedure with zero new LLM planning calls; the selected model in a screenshot is not evidence of new model inference.

Costs are visible: retrieval wall time, reconstruction attempts and duration, alternative native ticks and measured wall time, and actual execution ticks. A reconstruction intentionally costs computation. These tests establish correctness and reproducibility of memory reuse; they do **not** establish that retrieval is faster or more useful than planning without memory. That claim requires a separate matched-budget comparison. Wall time is observed elapsed time, not isolated CPU time; interrupted attempts can have incomplete timing information.

The validation record covers {len(cases)} distinct targeted Java checks across {len({k.split('#')[0] for k in cases})} classes, 127 desktop checks, five additional runtime/transaction/continuity/skill/kernel harnesses, real app cases and the final follow-up. Exact invocation scope and original output are in [verification.json](docs/readmes/073/verification.json); this is not a new full-history rerun of every expensive study. The local symlink check was unavailable; its traversal and absolute-path checks ran.

## Restore contract, bounds and honest limits

The supported restore point is **initial at rest**: original geometry and stable roles, elapsed tick0, zero linear/angular velocity, no held object, original controller initialization and the existing fixed timestep. It does not claim to restore arbitrary moving contact manifolds, solver caches, runtime script stacks, external devices or random simulation state. Resumed original native traces are outside this first episode contract. Restore eligibility is checked before committing a new remembered variant; a successful native endpoint alone cannot erase that limitation.

Reconstruction requires at least95% matched sample coverage, at most0.00001m maximum position difference and0.001degree maximum orientation difference, plus the original native gates. Changed-plan prediction versus actual execution keeps the existing stricter evidence path and its original0.01m/0.5degree comparison thresholds. Neither set is a real-world accuracy claim.

One uninterrupted goal allows one reconstruction, up to three original alternatives and one fresh actual run, with a ten-minute goal budget and90-second reconstruction/alternative budgets. At most two explicit reconstruction retries are allowed; prior attempts remain. Existing runner/history limits remain:32 memories, bounded imports/native histories and the original counterfactual study capacity. This is a bounded workbench, not an unbounded background search process.

The input accepts friction0–2 and a positive mass up to20kg, but the unchanged lifted-route planner supports upright0.2–4kg boxes. The20kg acceptance test therefore verifies an early refusal before world creation; it is not presented as a simulated payload failure. A static floor cannot be converted into a dynamic payload by this operation. Moving geometry, material deformation, arbitrary-component mutation and general robot manipulation remain separate future capabilities.

Native version identity is preserved. The new memory checks the current controller identity against the retained episode. Corrupt or incompatible records stay on disk and are reported as ineligible; rehashing a changed file does not bypass checks against the original owned goal and native trace. This is corruption detection and evidence binding within the local application, not protection against a machine administrator rewriting every authority store.

## Development evidence and corrections

The acceptance contract was committed as `4a1168d` before implementation and new outcomes. The first targeted run found a test reader using a generic4MB budget for a larger native episode; the test was corrected to use the declared32MB episode envelope budget. The first real app run completed native reconstruction, alternatives, fresh execution, report checks and child retention, then exposed a viewer assumption that compressed original traces were already decoded. The viewer now checks their original byte length and SHA256 before decoding. A source-encoding startup rejection and its correction are also retained.

The integrated view was changed to observe a new world without trying to rebind an action tool while the agent owns a task. Projection bounds now use oriented box corners and equal metre scale. These corrections changed display/validation handling; the native controller, alternative policy, experiment values and acceptance thresholds were not retuned after seeing results. Earlier failed attempts remain under the exact-original archive, separate from final passing evidence.

## Architecture, source and next steps

The implementation is concentrated in [Rehearsal073](workspace-engine/src/main/java/fraymus/workspace/Rehearsal073.java), [GoalRunner](workspace-engine/src/main/java/fraymus/workspace/GoalRunner.java), [Java domain planning](workspace-engine/src/main/java/fraymus/workspace/Domain044.java), the registered tool catalogs and the [integrated replay panel](workspace-desktop/renderer/rehearsal073.js). Existing [Counterfactual045](workspace-engine/src/main/java/fraymus/workspace/Counterfactual045.java), [WorldLedger](workspace-engine/src/main/java/fraymus/workspace/WorldLedger.java) and native physics verification remain authoritative. The [complete source inventory](docs/readmes/073/file-inventory.json) includes the inherited game, assets, modules and current implementation.

This turns the Game Lab analogy into a concrete form of experimental memory: propose, reconstruct, change, observe, verify and retain. The new episode is an entity with components and provenance that another task can reuse. A video alone would lose much of that information; state/action traces plus a visual witness preserve both inspectability and a starting point for another experiment. This does not demonstrate consciousness or automatically improve language-model weights.

The next useful gates are:

- Compare retrieval with no retrieval under the same total native tick/time budget on new scenes. Count failed reconstructions and lookup costs, not just successful outcomes.
- Add complete restore contracts for moving scenes only after measuring controller, contact-cache and randomness compatibility. Reject unsupported state explicitly.
- Build typed skill-graph nodes around these episodes, with prerequisites, source-qualified success conditions and recovery branches.
- Use verified counterexamples to propose changed procedures, then evaluate on held-out goals before promotion and keep rollback.
- Investigate unexpected outcomes using owned source/bytecode inspection. The earlier reverse-engineering assessment remains a proposal; no binary execution or RE stack is installed by this edition.

The original roadmap remains linked through [the rehearsal-memory assessment](docs/REHEARSAL_MEMORY_072.md) and the [edition073 contract](docs/EDITION_073_CONTRACT.md). Existing camera/world calibration qualifications and edition072's failed useful-observation promotion remain unchanged.
'''
write(r/'README-073.md',readme)
write(r/'docs/obsidian/81-experiment-memory.md','''# Executable experiment memory

The Java goal runner retrieves a verified at-rest episode, reconstructs it before variation, changes one component, compares bounded native alternatives, verifies a fresh actual run and retains a linked child. Replay is a read-only visual witness.

- [[README-073]]
- [[docs/EDITION_073_CONTRACT]]
- [[docs/REHEARSAL_MEMORY_072]]
- [[docs/obsidian/80-useful-observation]]

Scope: declared native box physics, not arbitrary moving checkpoints or physical calibration. Future promotion requires a matched-budget usefulness study and held-out conditions. No new LLM weights or consciousness claim.
''')
nodes=[dict(id=x['id'],type='file',file=x['source'],x=(i%3)*420,y=(i//3)*240,width=390,height=200) for i,x in enumerate(mapping)]
js(r/'docs/obsidian/experiment-memory.canvas',dict(nodes=nodes,edges=[dict(id='e'+str(i),fromNode=nodes[i]['id'],fromSide='right',toNode=nodes[i+1]['id'],toSide='left') for i in range(len(nodes)-1)]))
page=(r/'build/guide073.html').read_text(encoding='utf8')
for key,value in [('DATA',data),('MAP',mapping),('INVENTORY',inventory)]:page=page.replace('__'+key+'__',json.dumps(value,ensure_ascii=False).replace('</','<\\/'))
page=page.replace('__SHOTS__',''.join('<figure><img src="'+p.name+'" alt="Actual app '+html.escape(p.stem)+'"><figcaption>'+html.escape(p.stem)+' · actual isolated app · November5,2026</figcaption></figure>' for p in sorted(d.glob('*.png'))))
write(d/'index.html',page);print(json.dumps(dict(java=len(cases),sourceFiles=len(inventory),originals=len(archives),source=source)))
