from pathlib import Path
import json,hashlib,gzip,subprocess,sys,html,re,shutil,base64,datetime,xml.etree.ElementTree as ET
r=Path.cwd();out=Path(sys.argv[1]);d=r/'docs/readmes/078';d.mkdir(parents=True,exist_ok=True)
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
result=load(out/'result.json');assert result['passed'];study=load(out/'study.json');analysis=load(r/'build/native-analysis078.json');tamper=load(r/'build/inspector-probes078.json');assert analysis['passed'] and tamper['passed'];source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();project=Path(result['project']);archives=[]
def pack(p,dest):
 b=p.read_bytes();z=gzip.compress(b,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archives.append(dict(path=dest.relative_to(r).as_posix(),bytes=len(z),sha256=sha(z),rawBytes=len(b),rawSha256=sha(b),source=str(p)))
for p in sorted(out.iterdir()):
 if p.is_file() and p.suffix in ['.json','.log','.txt']:pack(p,d/'original/app'/(p.name+'.gz'))
for label,studyId in [('primary',study['id']),('recovery',result['recoveryId'])]:
 root=project/'procedures-078'/studyId
 for p in sorted(root.rglob('*.json')):
  if p.name in ['original.json','study.json'] or 'bank' in p.parts:pack(p,d/'original'/label/p.relative_to(root).with_suffix('.json.gz'))
for p in sorted((r/'build').glob('*078*.log')):pack(p,d/'original/logs'/(p.name+'.gz'))
cases={};invocations=[]
for folder in ['preflight078','native078','regression078']:
 rows=[]
 for p in sorted((r/'build'/folder).glob('TEST-*.xml')):
  root=ET.parse(p).getroot()
  for c in root.findall('testcase'):
   key=c.attrib['classname']+'#'+c.attrib['name'];passed=all(c.find(n) is None for n in ['failure','error','skipped']);cases[key]=passed;rows.append(dict(case=key,passed=passed))
  pack(p,d/'original/java'/folder/(p.name+'.gz'))
  for loc in re.findall(r'(?:PROOF078_NATIVE_SOURCE|MEMORY073_NATIVE_SOURCE) ([^\r\n<]+)',p.read_text(encoding='utf8')):
   for f in Path(loc).glob('*.json'):
    if f.suffix=='.json':pack(f,d/'original/java'/folder/(f.name+'.gz'))
 if rows:invocations.append(dict(name=folder,cases=rows))
assert cases and all(cases.values())
for name in ['native-analysis078.json','inspector-probes078.json','desktop078.json','final-app078.json','original-preservation078.json','unchanged-native078.json','regress078.ps1','document078.py','guide078.html']:
 pack(r/'build'/name,d/'original/validation'/(name+'.gz'))
for p in sorted((r/'build/preflight078-first').glob('*.xml')):pack(p,d/'original/preflight-first'/(p.name+'.gz'))
for p in sorted(out.glob('*.png')):
 if p.name!='failure.png':shutil.copyfile(p,d/p.name)
for p in sorted((r/'build/final-captures078').glob('*.png')):shutil.copyfile(p,d/p.name)
data={k:study[k] for k in ['id','evaluation','trainingTicks','trainingWallMillis','auditMillis','bank','protocol','code','bankFrozenAt']};data['trainingElapsedMillis']=(datetime.datetime.fromisoformat(study['bankFrozenAt'])-datetime.datetime.fromisoformat(study['createdAt'])).total_seconds()*1000;data['rows']=[]
for row in study['training']+study['rows']:
 x=load(out/(row['id']+'-originals.json'));row=json.loads(json.dumps(row));row['replays']={m:[] for m in row['results']}
 for item in x['originals']:
  packet=item['run'];raw=gzip.decompress(base64.b64decode(packet['gzipBase64']));assert sha(raw)==packet['rawSha256'];run=json.loads(raw);a=item['attempt'];n=len(run['samples']);indices=sorted(set([round(i*(n-1)/min(239,max(1,n-1))) for i in range(min(240,n))]));frames=[]
  for i in indices:
   f=run['samples'][i];frames.append(dict(tick=f['tick'],originalSampleIndex=i,bodies=[{k:b[k] for k in ['id','position','rotation']} for b in f['bodies']]))
  row['replays'][item['method']].append(dict(id=run['id'],stage=a['stage'],family=a['family'],status=a['status'],definition=run['definition'],originalSampleCount=n,samples=frames,targets=run['plan']['intent']['targets'],waypoint=row['results'][item['method']]['programs'][a['family']]['waypoints'][a['stage']]))
 data['rows'].append(row)
write(d/'comparison-data.json',json.dumps(data,separators=(',',':'),ensure_ascii=False)+'\n')
paths={x['path'] for x in load(r/'docs/readmes/077/file-inventory.json')};paths.update(x for x in subprocess.check_output(['git','diff','--name-only','--diff-filter=A','7cb6071','HEAD'],text=True).splitlines() if x.startswith(('workspace-engine/','workspace-desktop/','scripts/','fraynix-modules/')));inventory=[]
for name in sorted(paths):
 b=(r/name).read_bytes()
 try:b=b.decode('utf8').replace('\r\n','\n').encode();kind='utf8-lf'
 except UnicodeError:kind='binary'
 inventory.append(dict(path=name,bytes=len(b),hashKind=kind,sha256=sha(b)))
js(d/'file-inventory.json',inventory);write(d/'FILE_TREE.md','# Edition 078 complete source tree\n\n[Canonical bytes and hashes](file-inventory.json).\n\n```text\n'+'\n'.join(x['path'] for x in inventory)+'\n```\n')
v=dict(edition=78,primaryNativeAttempts=sum(len(a['attempts']) for row in study['training']+study['rows'] for a in row['results'].values()),source=source,contract='d68de31',runtimeImplementation='84e47ac',javaDistinct=len(cases),javaClasses=len({k.split('#')[0] for k in cases}),javaAllPassed=True,javaInvocations=invocations,desktop=load(r/'build/desktop078.json'),actualApp=result['checks'],actualAppSource=result['source'],finalApp=load(r/'build/final-app078.json'),coldAudit=result['coldAudit'],originalPreservation=load(r/'build/original-preservation078.json'),validationSource=result.get('validationSource',result['source']),analysis=analysis,tamper=tamper,scope='Frozen synthetic native box tasks: all failures, work and recovery retained. Same native solver/controller. Java reconstructs geometric search and baseline ordering; independent reader verifies original pose/wrench arithmetic, target membership, fresh execution, memory ranking and costs. No new LLM inference, independent physics solver or physical-world accuracy claim.')
js(d/'verification.json',v);js(d/'original-evidence.json',dict(format='Exact original export/checkpoint/log/XML bytes, gzip-compressed. Primary study, separate recovery and retained preflight failures are distinct. Synthetic isolated projects; no personal database or model weights.',files=archives))
modules=[('proof','Byte-verified proof cache','ProofMemo078.java','Bounded boot-local reuse after exact source/code/evidence checks; full checking after restart.'),('procedure','Typed procedures','Procedure078.java','Direct, equal-fraction and clearance-aware decomposition; unchanged original authority and native verifier.'),('study','Durable Java study','ProcedureStudy078.java','Owns training, immutable receipts, matched control runs, budgets, recovery, verification and export.'),('frame','Measured world frames','WorldFrames.java','Carries exact positions, rotations, velocities and elapsed ticks while preserving original geometry and IDs.'),('verify','Original physics gates','WorldVerify.java','Original integrated wrench, lifecycle, endpoint and protected-body checks remain authoritative.'),('view','Integrated evidence view','procedures078.js','Actual progress, training/test controls, per-arm costs, native stage replay and exact exports.'),('inspect','Independent arithmetic','Inspect-Procedures078.cjs','Checks original trace arithmetic, staged handoffs, frozen ranking, fresh execution and all costs outside Java.')]
mapping=[dict(id=i,name=n,note='docs/obsidian/86-proof-reuse.md',source=('workspace-desktop/renderer/' if p.endswith('.js') else 'scripts/' if p.endswith('.cjs') else 'workspace-engine/src/main/java/fraymus/workspace/')+p,description=t) for i,n,p,t in modules]
system=dict(modules=mapping,screenshots=[dict(path='docs/readmes/078/'+p.name,label=p.stem) for p in sorted(d.glob('*.png'))],evidence=[dict(path=q) for q in ['docs/readmes/078/verification.json','docs/readmes/078/original-evidence.json','docs/EDITION_078_CONTRACT.md']]);js(d/'system-map.json',system)
e=study['evaluation'];m=e['methods'];methods=['simple','geometry','memory','cached'];summary='\n'.join(f"| {name} | {m[name]['successes']}/8 | {m[name]['ticks']:,} | {m[name]['runs']} | {m[name]['wallMillis']/1000:.2f} | {m[name]['fullChecks']} / {m[name]['cacheHits']} |" for name in methods);pairs='\n'.join(f"| Cached versus {name} | {x['saved']} | {x['harmed']} | {m['cached']['ticks']-m[name]['ticks']:,} | {(m['cached']['wallMillis']-m[name]['wallMillis'])/1000:.2f} |" for name,x in e['paired'].items());qual='PASSED' if e['qualified'] else 'NOT PASSED'
caseRows='\n'.join('| '+row['id']+' | '+' | '.join(('success' if row['results'][name]['success'] else ('not verified' if row['results'][name]['status']=='completed' else row['results'][name]['status']))+' / '+str(row['results'][name]['chargedTicks']) for name in methods)+' |' for row in study['rows'])
trainRows='\n'.join('| '+row['id']+' | '+' | '.join(('verified' if row['results'][f]['success'] else 'not verified')+' / '+str(row['results'][f]['chargedTicks']) for f in ['direct','two-stage','three-stage','clear-two','clear-three'])+' |' for row in study['training']);families=', '.join(sorted(set(b['family'] for b in study['bank'])))
relation=f"Cached memory solved {m['cached']['successes']}/8 and uncached memory {m['memory']['successes']}/8. Cached selection used {m['cached']['fullChecks']} full checks and {m['cached']['cacheHits']} reused checks, compared with {m['memory']['fullChecks']} full checks for uncached memory. Lookup time was {m['cached']['lookupMillis']/1000:.2f}s versus {m['memory']['lookupMillis']/1000:.2f}s; active time was {m['cached']['wallMillis']/1000:.2f}s versus {m['memory']['wallMillis']/1000:.2f}s. These are matched source/recipe comparisons; broader practical and training-inclusive gates remain separate."
fastest=min(methods,key=lambda k:m[k]['wallMillis']);relation+=f" In this batch, {fastest} had the lowest active time. Cached memory reduced lookup time by {(1-m['cached']['lookupMillis']/m['memory']['lookupMillis'])*100:.1f}% and complete active time by {(1-m['cached']['wallMillis']/m['memory']['wallMillis'])*100:.1f}% versus uncached memory."

readme=(r/'build/README-078-template.md').read_text(encoding='utf8')
values={'RESULTS':summary,'PAIRS':pairs,'CASES':caseRows,'TRAINING':trainRows,'QUALIFIED':qual,'EFFICIENT':'PASSED' if e['efficient'] else 'NOT PASSED','BATCH':'PASSED' if e['firstBatchEfficient'] else 'NOT PASSED','RELATION':relation,'BANK':str(len(study['bank'])),'FAMILIES':families,'TRAIN_TICKS':f"{study['trainingTicks']:,}",'TRAIN_WALL':f"{study['trainingWallMillis']/1000:.2f}",'SEALED':f"{e['trainingSealedElapsedMillis']/1000:.2f}",'AUDIT':f"{study['auditMillis']/1000:.2f}",'WITH_TRAINING':f"{e['cachedWithTrainingTicks']:,}",'JAVA':str(v['javaDistinct']),'CLASSES':str(v['javaClasses']),'DESKTOP':str(v['desktop']['tests']),'PROBES':str(len(tamper['probes'])),'ATTEMPTS':str(v['primaryNativeAttempts']),'STUDY':study['id']}
for k,value in values.items():readme=readme.replace('__'+k+'__',value)
assert not re.search(r'__[A-Z_]+__',readme)
write(r/'README-078.md',readme)
shots=''.join(f'<figure><a href="{html.escape(p.name)}"><img src="{html.escape(p.name)}" alt="Actual edition078 {html.escape(p.stem)}"></a><figcaption>{html.escape(p.stem)} · actual isolated app capture, November6,2026.</figcaption></figure>' for p in sorted(d.glob('*.png')))
guide=(r/'build/guide078.html').read_text(encoding='utf8').replace('__SHOTS__',shots).replace('__DATA__',json.dumps(data,separators=(',',':')).replace('<','\\u003c')).replace('__MAP__',json.dumps(system,separators=(',',':')).replace('<','\\u003c')).replace('__INVENTORY__',json.dumps(inventory,separators=(',',':')).replace('<','\\u003c'));write(d/'index.html',guide)
write(r/'docs/obsidian/86-proof-reuse.md',f"""# Verified proof reuse · edition078

[[README-078|Edition078]] · [[README-077|Previous077]] · [[docs/readmes/078/index.html|Offline evidence]] · [[docs/obsidian/proof-reuse.canvas|System map]]

Five unchanged recipes, exact-byte proof reuse and measured stage state. Geometric previews are hypotheses; native outputs alone advance execution. Three training sources and eight unfamiliar tasks plus four unsupported controls. Training retained {len(study['bank'])} verified receipts and cost {study['trainingTicks']} ticks. Proof-cache qualification {qual}; practical efficiency {values['EFFICIENT']}; first-batch efficiency {values['BATCH']}. No automatic promotion, evaluation ingestion, active-world edits or new model inference.

[[workspace-engine/src/main/java/fraymus/workspace/ProofMemo078.java|Proof cache]] retains only fully checked unchanged evidence; restart begins cold. [[workspace-engine/src/main/java/fraymus/workspace/Procedure078.java|Procedures]] retain original force and verification. [[workspace-engine/src/main/java/fraymus/workspace/ProcedureStudy078.java|Runner]] owns immutable bank, budgets, restart and audit. [[workspace-desktop/renderer/procedures078.js|Panel]] shows actual traces and separate planned targets. [[scripts/Inspect-Procedures078.cjs|Independent arithmetic]] checks originals, candidate membership and costs; Java additionally reconstructs complete search/baseline decisions.

Next gates: selective retrieval against geometry, typed durable goal integration with unchanged fresh execution, then broader body/contact and real-camera calibration tasks. Do not infer useful learning from changed weights or remembered success alone. Preserve frozen001–078.
""")
nodes=[dict(id='readme',type='file',file='README-078.md',x=0,y=0,width=380,height=200)];edges=[]
for i,m in enumerate(mapping):
 nodes.append(dict(id=m['id'],type='file',file=m['source'],x=(i%3)*420,y=270+(i//3)*260,width=380,height=210));edges.append(dict(id='e'+str(i),fromNode='readme',fromSide='bottom',toNode=m['id'],toSide='top',label=m['name']))
js(r/'docs/obsidian/proof-reuse.canvas',dict(nodes=nodes,edges=edges))
print(json.dumps(dict(words=len(readme.split()),archives=len(archives),canonicalFiles=len(inventory),javaDistinct=v['javaDistinct'],qualification=e['qualified'])))
