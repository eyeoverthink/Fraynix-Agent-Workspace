from pathlib import Path
import json,copy
r=Path.cwd();p=json.loads((r/'workspace-engine/src/main/resources/procedures077-protocol.json').read_text(encoding='utf8'))
p['version']='proof-reuse-078-v1';p['methods']=['simple','geometry','memory','cached']
for s in p['training']+p['cases']:s['source']['title']=s['source']['title'].replace('077','078');s['group']='proof-reuse'
for i,s in enumerate(p['cases'][:8]):
 a=next(o for o in s['source']['objects'] if o['sourceId']=='A');a['massKg']=[.9,1.3,3.4,3.0,2.4,1.45,1.05,1.4][i]
 for o in s['source']['objects']:
  if o['sourceId']=='B':o['friction']+=.07
  if o['sourceId'].startswith('obstacle'):o['position'][0]+=.07
 s['targets'][0]['positionM'][0]+=.08;s['targets'][0]['positionM'][2]-=.06
(r/'workspace-engine/src/main/resources/procedures078-protocol.json').write_text(json.dumps(p,indent=2)+'\n',encoding='utf8',newline='\n')
