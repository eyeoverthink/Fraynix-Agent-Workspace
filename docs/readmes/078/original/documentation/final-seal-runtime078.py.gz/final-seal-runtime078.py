from pathlib import Path
import json,subprocess,hashlib
r=Path.cwd();p=r/'workspace-engine/src/main/java/fraymus/workspace/ProcedureStudy078.java';s=p.read_text(encoding='utf8').replace('Waypoints077.class,ProofMemo078.class','Waypoints077.class,ProofMemo078.class,MemoryPolicy075.class,SpatialScene.class,AgentFiles042.class,MapCheckpoint.class');p.write_text(s,encoding='utf8',newline='\n')
old=json.loads((r.parent/'fraynix-workspace-edition077/build/unchanged-native077.json').read_text(encoding='utf8'))
paths=[x['path'] for x in old['files']]+['workspace-engine/src/main/java/fraymus/workspace/'+n+'.java' for n in ['ProcedureStudy077','Procedure077','Waypoints077']]
rows=[]
for name in sorted(set(paths)):
 original=subprocess.check_output(['git','show','7cb6071:'+name]);actual=(r/name).read_bytes().replace(b'\r\n',b'\n');assert actual==original.replace(b'\r\n',b'\n'),name;rows.append({'path':name,'sha256':hashlib.sha256(actual).hexdigest()})
(r/'build/unchanged-native078.json').write_text(json.dumps({'passed':True,'baseline':'7cb6071','files':rows},indent=2)+'\n',encoding='utf8')
# Passive snapshot is integrated before lifecycle testing, avoiding a second monitor process.
p=r/'workspace-desktop/test/procedures078-integration.cjs';s=p.read_text(encoding='utf8');needle="  await app.close();await open();assert.deepEqual((await api('/api/procedures078/read'"
insert="""  const evidenceRoot=path.join(project,'procedures-078',started.id),originalFiles={};for(const name of await fs.readdir(path.join(evidenceRoot,'attempts'))){const relative='attempts/'+name+'/original.json';try{originalFiles[relative]=require('node:crypto').createHash('sha256').update(await fs.readFile(path.join(evidenceRoot,relative))).digest('hex');}catch(e){if(e.code!=='ENOENT')throw e;}}await fs.writeFile(path.resolve(__dirname,'../../build/original-before078.json'),JSON.stringify({root:evidenceRoot,phase:completed.phase,progress:completed.progress,files:originalFiles},null,2));
"""
assert needle in s;s=s.replace(needle,insert+needle);p.write_text(s,encoding='utf8')
