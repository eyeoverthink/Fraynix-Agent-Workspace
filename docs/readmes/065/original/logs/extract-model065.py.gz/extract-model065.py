from pathlib import Path
import json,gzip,hashlib
source=Path('docs/readmes/064/original/native064-final/original-experiment.json.gz')
raw=gzip.decompress(source.read_bytes());j=json.loads(raw)
bundle={k:j[k] for k in ['id','manifest064','calibration064','intervalModel064','intervalModelSha256064','evaluation064']}
bundle.update(sourceRelease='50be9a6568037915c4060804a247e6df60326062',sourcePath=source.as_posix(),originalRawSha256=hashlib.sha256(raw).hexdigest())
p=Path('workspace-engine/src/main/resources/fraymus/workspace/calibration065.json.gz');p.parent.mkdir(parents=True,exist_ok=True)
p.write_bytes(gzip.compress(json.dumps(bundle,separators=(',',':')).encode(),mtime=0))
print(json.dumps(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())))
