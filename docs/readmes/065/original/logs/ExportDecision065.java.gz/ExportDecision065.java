package fraymus.workspace;
import java.nio.file.*;
import org.json.*;
public class ExportDecision065 {
 public static void main(String[] args)throws Exception{
  var job=new JSONObject(Files.readString(Path.of(args[0])));DecisionStudy065.audit(job);var output=new JSONObject().put("source",DecisionStudy065.source()).put("model",Calibration065.info()).put("evaluation",job.getJSONObject("evaluation065")).put("shiftedEvaluation",job.getJSONObject("shiftedEvaluation065")).put("nativeExecutions",job.getInt("nativeExecutions"));
  for(String key:new String[]{"tasks065","shifted065"}){var rows=new JSONArray();for(Object raw:job.getJSONArray(key)){var row=WorldFrames.copy((JSONObject)raw);for(String method:DecisionPolicy065.METHODS){var result=row.getJSONObject("results").getJSONObject(method);var record=result.optJSONObject("record");if(record!=null){var series=new JSONArray();for(Object sample:record.getJSONArray("samples")){var p=Stopping063.projected(record.getJSONObject("definition"),(JSONObject)sample);series.put(new JSONArray().put(p.getDouble("timeS")).put(p.getDouble("distanceM")).put(p.getDouble("tangentMps")).put(p.getDouble("rotationDeg")));}result.remove("record");result.put("recordSha256",record.getString("sha256")).put("series",series);}}rows.put(row);}output.put(key,rows);}
  Files.writeString(Path.of(args[1]),output.toString());
  if(args.length>2)try(var prior=new BrainService(Path.of(args[2]))){var id=prior.state().getJSONArray("jobs").getJSONObject(0).getString("id");var failed=prior.read(id);Files.writeString(Path.of(args[3]),failed.toString());int compared=0;for(int i=0;i<failed.getJSONArray("tasks065").length();i++){if(!failed.getJSONArray("tasks065").getJSONObject(i).getJSONObject("plan").similar(job.getJSONArray("tasks065").getJSONObject(i).getJSONObject("plan")))throw new IllegalStateException("Supported policy plan changed after admission fix");compared++;}Files.writeString(Path.of(args[4]),new JSONObject().put("passed",true).put("unchangedSupportedPlans",compared).put("failedSource",failed.getJSONObject("manifest065").getString("source")).put("finalSource",DecisionStudy065.source()).put("meaning","Admission fix preserves all completed supported-task plans; no outcome used for tuning").toString(2));}
  System.out.println("Exported audited decision evidence and actual Java-derived trajectories");
 }
}
