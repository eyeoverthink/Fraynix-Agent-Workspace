from pathlib import Path
import json,copy,math
r=Path.cwd();old=json.loads((r/'workspace-engine/src/main/resources/procedures076-protocol.json').read_text(encoding='utf8'))
def obj(s,n):return next(o for o in s['source']['objects'] if o['sourceId']==n)
def case(base,name,split):
 s=copy.deepcopy(base);s.update(id=name,split=split,group='obstacle-waypoints');s['source']['title']='LABELLED077 '+split+' '+name;return s
def blockers(s,fractions,shift=0,yaw=0):
 a=obj(s,'A');end=s['targets'][0]['positionM'];s['source']['objects']=[o for o in s['source']['objects'] if not o['sourceId'].startswith('obstacle')]
 for i,f in enumerate(fractions):
  p=[a['position'][k]+(end[k]-a['position'][k])*f for k in range(3)];p[1]=.35;p[0]+=shift
  s['source']['objects'].append(dict(sourceId='obstacle'+str(i),label='Fixed obstacle '+str(i),shape='box',position=p,size=[.6,.7,.65],massKg=0,friction=.5,restitution=0,rotation=[0,math.sin(math.radians(yaw)/2),0,math.cos(math.radians(yaw)/2)]))
 return s
short=case(old['training'][0],'train-open','training')
long=case(old['training'][2],'train-occupied','training');blockers(long,[1/3,2/3])
turn=case(old['training'][1],'train-turn','training');blockers(turn,[.5],.2,20)
training=[short,long,turn];cases=[]
s=case(long,'offset-payload','unseen');obj(s,'A')['massKg']=.85;obj(s,'A')['friction']=.4;obj(s,'A')['position'][0]-=.15;s['targets'][0]['positionM'][2]+=.15;blockers(s,[1/3,2/3],.12,30);cases.append(s)
s=case(long,'rotated-blockers','unseen');obj(s,'A')['massKg']=1.1;obj(s,'A')['size'][0]=.65;s['targets'][0]['positionM'][0]+=.15;blockers(s,[.3,.65],-.15,-35);cases.append(s)
s=case(turn,'heavy-turn','unseen');obj(s,'A')['massKg']=3.6;obj(s,'A')['friction']=.6;s['torqueLimitNm']=.16;s['targets'][0]['yawDeg']=-145;blockers(s,[.5],-.12,-25);cases.append(s)
s=case(turn,'shifted-turn','unseen');obj(s,'A')['massKg']=3.15;obj(s,'A')['position'][0]+=.2;s['torqueLimitNm']=.22;s['targets'][0]['yawDeg']=175;blockers(s,[.45],.15,40);cases.append(s)
s=case(long,'combined-load','unseen');obj(s,'A')['massKg']=2.2;obj(s,'A')['friction']=.85;s['torqueLimitNm']=.45;s['targets'][0]['yawDeg']=-165;blockers(s,[1/3,2/3],-.1,15);cases.append(s)
s=case(short,'open-control','unseen');obj(s,'A')['massKg']=1.35;obj(s,'A')['friction']=.45;s['targets'][0]['yawDeg']=75;cases.append(s)
s=case(long,'protected-neighbor','unseen');obj(s,'A')['massKg']=.95;obj(s,'bystander')['position']=[-1.4,.25,-.05];blockers(s,[1/3,2/3],.05,10);cases.append(s)
s=case(old['cases'][7],'novel-role','unseen');obj(s,'A')['massKg']=1.25;obj(s,'C')['position'][2]= -3.1;s['targets'][2]['yawDeg']=-120;blockers(s,[.5],.1,15);cases.append(s)
for base in old['cases'][-4:]:
 s=case(base,base['id'],'unsupported');obj(s,'B')['friction']=.35;cases.append(s)
p=dict(version='obstacle-procedures-077-v1',families=['direct','two-stage','three-stage','clear-two','clear-three'],methods=['legacy','simple','geometry','memory'],budgetTicks=115200,armWallMillis=1200000,attemptWallMillis=90000,maxResumes=2,training=training,cases=cases)
(r/'workspace-engine/src/main/resources/procedures077-protocol.json').write_text(json.dumps(p,indent=2)+'\n',encoding='utf8')
print('Prospective protocol: 3 training, 8 unfamiliar, 4 unsupported; 63 arms.')
