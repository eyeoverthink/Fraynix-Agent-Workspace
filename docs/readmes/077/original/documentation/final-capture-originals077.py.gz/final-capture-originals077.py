from pathlib import Path
import json,time,hashlib
root=Path(r'C:/Users/eyeka/AppData/Local/Temp/fraynix-procedures077-ui-cqS9LY/procedures-077/399dce73-a0da-49c2-887b-dad84e8f8de3')
while True:
 s=json.loads((root/'study.json').read_text(encoding='utf8'))['data']
 if s['status'] in ['interrupted','cancelled']:raise RuntimeError(s.get('reason'))
 if s['progress']==63:break
 time.sleep(2)
files={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('attempts/*/original.json'))}
Path('build/original-before077.json').write_text(json.dumps({'root':str(root),'phase':s['phase'],'progress':s['progress'],'files':files},indent=2)+'\n',encoding='utf8')
print('Captured complete original native hashes before subsequent lifecycle checks:',len(files),flush=True)
