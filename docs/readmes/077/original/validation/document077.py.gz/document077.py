from pathlib import Path
import json,hashlib,gzip,subprocess,sys,html,re,shutil,base64,datetime,xml.etree.ElementTree as ET
r=Path.cwd();out=Path(sys.argv[1]);d=r/'docs/readmes/077';d.mkdir(parents=True,exist_ok=True)
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
result=load(out/'result.json');assert result['passed'];study=load(out/'study.json');analysis=load(r/'build/native-analysis077.json');tamper=load(r/'build/inspector-probes077.json');assert analysis['passed'] and tamper['passed'];source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();project=Path(result['project']);archives=[]
def pack(p,dest):
 b=p.read_bytes();z=gzip.compress(b,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archives.append(dict(path=dest.relative_to(r).as_posix(),bytes=len(z),sha256=sha(z),rawBytes=len(b),rawSha256=sha(b),source=str(p)))
for p in sorted(out.iterdir()):
 if p.is_file() and p.suffix in ['.json','.log','.txt']:pack(p,d/'original/app'/(p.name+'.gz'))
for label,studyId in [('primary',study['id']),('recovery',result['recoveryId'])]:
 root=project/'procedures-077'/studyId
 for p in sorted(root.rglob('*.json')):
  if p.name in ['original.json','study.json'] or 'bank' in p.parts:pack(p,d/'original'/label/p.relative_to(root).with_suffix('.json.gz'))
for p in sorted((r/'build').glob('*077*.log')):pack(p,d/'original/logs'/(p.name+'.gz'))
cases={};invocations=[]
for folder in ['preflight077','native077','regression077']:
 rows=[]
 for p in sorted((r/'build'/folder).glob('TEST-*.xml')):
  root=ET.parse(p).getroot()
  for c in root.findall('testcase'):
   key=c.attrib['classname']+'#'+c.attrib['name'];passed=all(c.find(n) is None for n in ['failure','error','skipped']);cases[key]=passed;rows.append(dict(case=key,passed=passed))
  pack(p,d/'original/java'/folder/(p.name+'.gz'))
  for loc in re.findall(r'(?:PROCEDURE077_NATIVE_SOURCE|MEMORY073_NATIVE_SOURCE) ([^\r\n<]+)',p.read_text(encoding='utf8')):
   for f in Path(loc).glob('*.json'):
    if f.name.startswith(('forecast-','actual-')) or f.name in ['original.json','reconstruction.json']:pack(f,d/'original/java'/folder/(f.name+'.gz'))
 if rows:invocations.append(dict(name=folder,cases=rows))
assert cases and all(cases.values())
for name in ['native-analysis077.json','inspector-probes077.json','desktop077.json','final-app077.json','original-preservation077.json','unchanged-native077.json','regress077.ps1','document077.py','guide077.html']:
 pack(r/'build'/name,d/'original/validation'/(name+'.gz'))
for p in sorted((r/'build/preflight077-first').glob('*.xml')):pack(p,d/'original/preflight-first'/(p.name+'.gz'))
for p in sorted(out.glob('*.png')):
 if p.name!='failure.png':shutil.copyfile(p,d/p.name)
for p in sorted((r/'build/final-captures077').glob('*.png')):shutil.copyfile(p,d/p.name)
data={k:study[k] for k in ['id','evaluation','trainingTicks','trainingWallMillis','auditMillis','bank','protocol','code','bankFrozenAt']};data['trainingElapsedMillis']=(datetime.datetime.fromisoformat(study['bankFrozenAt'])-datetime.datetime.fromisoformat(study['createdAt'])).total_seconds()*1000;data['rows']=[]
for row in study['training']+study['rows']:
 x=load(out/(row['id']+'-originals.json'));row=json.loads(json.dumps(row));row['replays']={m:[] for m in row['results']}
 for item in x['originals']:
  packet=item['run'];raw=gzip.decompress(base64.b64decode(packet['gzipBase64']));assert sha(raw)==packet['rawSha256'];run=json.loads(raw);a=item['attempt'];n=len(run['samples']);indices=sorted(set([round(i*(n-1)/min(239,max(1,n-1))) for i in range(min(240,n))]));frames=[]
  for i in indices:
   f=run['samples'][i];frames.append(dict(tick=f['tick'],originalSampleIndex=i,bodies=[{k:b[k] for k in ['id','position','rotation']} for b in f['bodies']]))
  row['replays'][item['method']].append(dict(id=run['id'],stage=a['stage'],family=a['family'],status=a['status'],definition=run['definition'],originalSampleCount=n,samples=frames,targets=run['plan']['intent']['targets'],waypoint=row['results'][item['method']]['programs'][a['family']]['waypoints'][a['stage']]))
 data['rows'].append(row)
write(d/'comparison-data.json',json.dumps(data,separators=(',',':'),ensure_ascii=False)+'\n')
paths={x['path'] for x in load(r/'docs/readmes/076/file-inventory.json')};paths.update(x for x in subprocess.check_output(['git','diff','--name-only','--diff-filter=A','a94f8b9','HEAD'],text=True).splitlines() if x.startswith(('workspace-engine/','workspace-desktop/','scripts/','fraynix-modules/')));inventory=[]
for name in sorted(paths):
 b=(r/name).read_bytes()
 try:b=b.decode('utf8').replace('\r\n','\n').encode();kind='utf8-lf'
 except UnicodeError:kind='binary'
 inventory.append(dict(path=name,bytes=len(b),hashKind=kind,sha256=sha(b)))
js(d/'file-inventory.json',inventory);write(d/'FILE_TREE.md','# Edition 077 complete source tree\n\n[Canonical bytes and hashes](file-inventory.json).\n\n```text\n'+'\n'.join(x['path'] for x in inventory)+'\n```\n')
v=dict(edition=77,primaryNativeAttempts=sum(len(a['attempts']) for row in study['training']+study['rows'] for a in row['results'].values()),source=source,contract='73ebe37',schemaCorrection='4e9c72e',runtimeImplementation='4bc8fd4',javaDistinct=len(cases),javaClasses=len({k.split('#')[0] for k in cases}),javaAllPassed=True,javaInvocations=invocations,desktop=load(r/'build/desktop077.json'),actualApp=result['checks'],actualAppSource=result['source'],finalApp=load(r/'build/final-app077.json'),coldAudit=result['coldAudit'],originalPreservation=load(r/'build/original-preservation077.json'),validationSource=result.get('validationSource',result['source']),analysis=analysis,tamper=tamper,scope='Frozen synthetic native box tasks: all failures, work and recovery retained. Same native solver/controller. Java reconstructs geometric search and baseline ordering; independent reader verifies original pose/wrench arithmetic, target membership, fresh execution, memory ranking and costs. No new LLM inference, independent physics solver or physical-world accuracy claim.')
js(d/'verification.json',v);js(d/'original-evidence.json',dict(format='Exact original export/checkpoint/log/XML bytes, gzip-compressed. Primary study, separate recovery and retained preflight failures are distinct. Synthetic isolated projects; no personal database or model weights.',files=archives))
modules=[('waypoints','Clear landing search','Waypoints077.java','Bounded geometry search, hypothetical previews and source-bound waypoint receipts.'),('procedure','Typed procedures','Procedure077.java','Direct, equal-fraction and clearance-aware decomposition; unchanged original authority and native verifier.'),('study','Durable Java study','ProcedureStudy077.java','Owns training, immutable receipts, matched control runs, budgets, recovery, verification and export.'),('frame','Measured world frames','WorldFrames.java','Carries exact positions, rotations, velocities and elapsed ticks while preserving original geometry and IDs.'),('verify','Original physics gates','WorldVerify.java','Original integrated wrench, lifecycle, endpoint and protected-body checks remain authoritative.'),('view','Integrated evidence view','procedures077.js','Actual progress, training/test controls, per-arm costs, native stage replay and exact exports.'),('inspect','Independent arithmetic','Inspect-Procedures077.cjs','Checks original trace arithmetic, staged handoffs, frozen ranking, fresh execution and all costs outside Java.')]
mapping=[dict(id=i,name=n,note='docs/obsidian/85-obstacle-waypoints.md',source=('workspace-desktop/renderer/' if p.endswith('.js') else 'scripts/' if p.endswith('.cjs') else 'workspace-engine/src/main/java/fraymus/workspace/')+p,description=t) for i,n,p,t in modules]
system=dict(modules=mapping,screenshots=[dict(path='docs/readmes/077/'+p.name,label=p.stem) for p in sorted(d.glob('*.png'))],evidence=[dict(path=q) for q in ['docs/readmes/077/verification.json','docs/readmes/077/original-evidence.json','docs/EDITION_077_CONTRACT.md']]);js(d/'system-map.json',system)
e=study['evaluation'];m=e['methods'];methods=['legacy','simple','geometry','memory'];summary='\n'.join(f"| {name} | {m[name]['successes']}/8 | {m[name]['ticks']:,} | {m[name]['runs']} | {m[name]['wallMillis']/1000:.2f} | {m[name]['utility']:.6f} |" for name in methods);pairs='\n'.join(f"| Memory versus {name} | {x['saved']} | {x['harmed']} | {x['tickDelta']:,} | {x['utilityDelta']:.6f} |" for name,x in e['paired'].items());qual='PASSED' if e['qualified'] else 'NOT PASSED'
caseRows='\n'.join('| '+row['id']+' | '+' | '.join(('success' if row['results'][name]['success'] else ('not verified' if row['results'][name]['status']=='completed' else row['results'][name]['status']))+' / '+str(row['results'][name]['chargedTicks']) for name in methods)+' |' for row in study['rows'])
trainRows='\n'.join('| '+row['id']+' | '+' | '.join(('verified' if row['results'][f]['success'] else 'not verified')+' / '+str(row['results'][f]['chargedTicks']) for f in ['direct','two-stage','three-stage','clear-two','clear-three'])+' |' for row in study['training']);families=', '.join(sorted(set(b['family'] for b in study['bank'])))
relation=f"Memory solved {m['memory']['successes']}/8, simple {m['simple']['successes']}/8, geometry {m['geometry']['successes']}/8 and legacy {m['legacy']['successes']}/8. Memory used {m['memory']['ticks']:,} native ticks and {m['memory']['wallMillis']/1000:.2f} active seconds; geometry used {m['geometry']['ticks']:,} ticks and {m['geometry']['wallMillis']/1000:.2f} seconds. These are the measured methods in this declared task family, not a claim of superiority to all simple controllers."

readme=(r/'build/README-077-template.md').read_text(encoding='utf8')
values={'RESULTS':summary,'PAIRS':pairs,'CASES':caseRows,'TRAINING':trainRows,'QUALIFIED':qual,'EFFICIENT':'PASSED' if e['efficient'] else 'NOT PASSED','BATCH':'PASSED' if e['firstBatchEfficient'] else 'NOT PASSED','RELATION':relation,'BANK':str(len(study['bank'])),'FAMILIES':families,'TRAIN_TICKS':f"{study['trainingTicks']:,}",'TRAIN_WALL':f"{study['trainingWallMillis']/1000:.2f}",'SEALED':f"{e['trainingSealedElapsedMillis']/1000:.2f}",'AUDIT':f"{study['auditMillis']/1000:.2f}",'WITH_TRAINING':f"{e['memoryWithTrainingTicks']:,}",'JAVA':str(v['javaDistinct']),'CLASSES':str(v['javaClasses']),'DESKTOP':str(v['desktop']['tests']),'PROBES':str(len(tamper['probes'])),'ATTEMPTS':str(v['primaryNativeAttempts']),'STUDY':study['id']}
for k,value in values.items():readme=readme.replace('__'+k+'__',value)
assert not re.search(r'__[A-Z_]+__',readme)
write(r/'README-077.md',readme)
shots=''.join(f'<figure><a href="{html.escape(p.name)}"><img src="{html.escape(p.name)}" alt="Actual edition077 {html.escape(p.stem)}"></a><figcaption>{html.escape(p.stem)} · actual isolated app capture, November5,2026.</figcaption></figure>' for p in sorted(d.glob('*.png')))
guide=(r/'build/guide077.html').read_text(encoding='utf8').replace('__SHOTS__',shots).replace('__DATA__',json.dumps(data,separators=(',',':')).replace('<','\\u003c')).replace('__MAP__',json.dumps(system,separators=(',',':')).replace('<','\\u003c')).replace('__INVENTORY__',json.dumps(inventory,separators=(',',':')).replace('<','\\u003c'));write(d/'index.html',guide)
write(r/'docs/obsidian/85-obstacle-waypoints.md',f"""# Obstacle-aware procedures · edition077

[[README-077|Edition077]] · [[README-076|Previous076]] · [[docs/readmes/077/index.html|Offline evidence]] · [[docs/obsidian/obstacle-waypoints.canvas|System map]]

Five typed recipes, finite clear-landing search and measured stage state. Geometric previews are hypotheses; native outputs alone advance execution. Three training sources and eight unfamiliar tasks plus four unsupported controls. Training retained {len(study['bank'])} verified receipts and cost {study['trainingTicks']} ticks. Utility qualification {qual}; practical efficiency {values['EFFICIENT']}; first-batch efficiency {values['BATCH']}. No automatic promotion, evaluation ingestion, active-world edits or new model inference.

[[workspace-engine/src/main/java/fraymus/workspace/Waypoints077.java|Search]] supplies clear stage targets. [[workspace-engine/src/main/java/fraymus/workspace/Procedure077.java|Procedures]] retain original force and verification. [[workspace-engine/src/main/java/fraymus/workspace/ProcedureStudy077.java|Runner]] owns immutable bank, budgets, restart and audit. [[workspace-desktop/renderer/procedures077.js|Panel]] shows actual traces and separate planned targets. [[scripts/Inspect-Procedures077.cjs|Independent arithmetic]] checks originals, candidate membership and costs; Java additionally reconstructs complete search/baseline decisions.

Next gates: selective retrieval against geometry, source-bound proof reuse with unchanged fresh execution, typed durable goal integration, then broader body/contact and real-camera calibration tasks. Do not infer useful learning from changed weights or remembered success alone. Preserve frozen001–077.
""")
nodes=[dict(id='readme',type='file',file='README-077.md',x=0,y=0,width=380,height=200)];edges=[]
for i,m in enumerate(mapping):
 nodes.append(dict(id=m['id'],type='file',file=m['source'],x=(i%3)*420,y=270+(i//3)*260,width=380,height=210));edges.append(dict(id='e'+str(i),fromNode='readme',fromSide='bottom',toNode=m['id'],toSide='top',label=m['name']))
js(r/'docs/obsidian/obstacle-waypoints.canvas',dict(nodes=nodes,edges=edges))
print(json.dumps(dict(words=len(readme.split()),archives=len(archives),canonicalFiles=len(inventory),javaDistinct=v['javaDistinct'],qualification=e['qualified'])))
