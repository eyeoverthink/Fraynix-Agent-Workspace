$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$env:JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=4 -Xmx768m'
$env:PATH=$env:JAVA_HOME+'/bin;'+$env:PATH
$running=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'java.exe' -and $_.CommandLine -like '*fraynix-workspace-edition077*' -and $_.CommandLine -like '*WorkspaceServer*' })
if($running.Count){throw 'Close the isolated study app before regression builds.'}
$classes=@('Procedure076Test','Waypoints077Test','Procedure077Test','MemoryPolicy075Test','RebuildCertificate075Test','MemoryPolicy074Test','Agency043Test','Agent042Test','ChatChain052Test','Counterfactual045Test','Domain044Test','GoalRunnerTest','Rehearsal073Test','SkillGraph046Test','WorldCheckpoint071Test','WorldExportTest','WorldLedgerTest')
$testArgs=@(':workspace-engine:test','--offline','--no-daemon','--max-workers=4')
foreach($class in $classes){$testArgs+=@('--tests',('fraymus.workspace.'+$class))}
$testArgs+=@('verifySourceIsolation')
& ./gradlew.bat @testArgs *> build/regression077.log
if($LASTEXITCODE){throw 'Targeted Java regression failed; original output retained.'}
New-Item -ItemType Directory -Force build/regression077 | Out-Null
Copy-Item -Path workspace-engine/build/test-results/test/TEST-*.xml -Destination build/regression077/
Push-Location workspace-desktop
try { & npm.cmd test *> ../build/desktop077.log; if($LASTEXITCODE){throw 'Desktop regression failed.'} } finally {Pop-Location}
Write-Output 'Targeted Java and desktop regression passed.'
