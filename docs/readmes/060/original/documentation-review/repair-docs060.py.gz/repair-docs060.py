from pathlib import Path
import json,hashlib,gzip,re,subprocess
r=Path(__file__).resolve().parent.parent;d=r/'docs/readmes/060'
p=d/'IDEAS_060_REVIEW.md';s=p.read_text(encoding='utf8').replace('(../scripts/ProbeSuppliedEncoder060.java)','(../../../scripts/ProbeSuppliedEncoder060.java)').replace('(../README-060.md)','(../../../README-060.md)');p.write_text(s,encoding='utf8')
inventory=json.loads((d/'file-inventory.json').read_text(encoding='utf8'))
for row in inventory:
 if row['path']=='scripts/Verify-Documentation.ps1':
  b=(r/row['path']).read_text(encoding='utf8').replace('\r\n','\n').encode();row.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
(d/'file-inventory.json').write_text(json.dumps(inventory,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
p=d/'index.html';s=p.read_text(encoding='utf8');s=re.sub(r'(<script id="inventory-data" type="application/json">).*?(</script>)',lambda m:m[1]+json.dumps(inventory)+m[2],s,flags=re.S);p.write_text(s,encoding='utf8')
original=json.loads((d/'original-evidence.json').read_text(encoding='utf8'))
for name in ['documentation060-first.json','documentation060-first.log','finalize-docs060.py','repair-docs060.py']:
 p=r/'build'/name;b=p.read_bytes();z=gzip.compress(b,mtime=0);dest=d/'original/documentation-review'/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z)
 original['files'].append({'path':dest.relative_to(r).as_posix(),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest(),'rawBytes':len(b),'rawSha256':hashlib.sha256(b).hexdigest(),'source':str(p),'format':'gzip of original bytes'})
(d/'original-evidence.json').write_text(json.dumps(original,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
for name in ['docs/readmes/060/verification.json','docs/VALIDATION_060.json']:
 p=r/name;v=json.loads(p.read_text(encoding='utf8'));v['documentationDevelopment']={'source':source,'firstResult':'23 findings: two copied-review relative links and 21 historical embedded-data comparisons affected by Windows PowerShell default decoding. No frozen hash mismatches. Original report and log retained.','correction':'Repair only the new snapshot links. Read manifest/map/inventory/canvas JSON as UTF-8; stream binary SHA-256 and directly assign UTF-8 LF bytes for text, avoiding pipeline byte boxing. All original hash and link checks remain.'};p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
p=r/'README-060.md';s=p.read_text(encoding='utf8');s=s.replace('## Try it in the application','The publication verifier now reads JSON explicitly as UTF-8 in Windows PowerShell and streams binary hashes. The first documentation check exposed two copied-review links and a legacy-shell decoding mismatch; its report is retained. All frozen hash and reference checks remain enabled.\n\n## Try it in the application');p.write_text(s,encoding='utf8')
print('Corrected new links, source inventory and verifier provenance; retained original failed documentation check')
