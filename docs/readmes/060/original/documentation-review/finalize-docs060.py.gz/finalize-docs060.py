from pathlib import Path
import json
r=Path(__file__).resolve().parent.parent
for name in ['docs/readmes/060/verification.json','docs/VALIDATION_060.json']:
 p=r/name;v=json.loads(p.read_text(encoding='utf8'))
 for key in ['compactChat','reused']:v['timing'][key]['source']=v['runtimeComponents']['actualPhases'][key]
 v['screenshotReview']={'actualImages':8,'reviewed':True,'replay':'Reopened the exact completed report after Stop validation. Focused the Electron window so its compositor captured the scrolled replay. No physics run repeated. The sidebar shows the latest cancelled test goal, while the replay belongs to the earlier completed wide report. Original capture and read-only recapture metadata retained under original/development-ui/ui060-replay-capture.'}
 p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
p=r/'README-060.md';s=p.read_text(encoding='utf8');s=s.replace('![Recorded motion under the new edge payload]', '![Recorded motion under the new edge payload]')
needle='![Recorded motion under the new edge payload]'
lines=s.splitlines()
for i,line in enumerate(lines):
 if needle in line:
  lines.insert(i+1,'\nThe completed wide report was reopened after the Stop check for this capture. The replay shows its original recorded poses; the sidebar shows the separate latest cancelled goal.\n');break
p.write_text('\n'.join(lines)+'\n',encoding='utf8')
print('Finalized phase source attribution and actual screenshot provenance')
