from pathlib import Path
p=Path('workspace-desktop/test/construction060-integration.cjs');s=p.read_text();a="record.report=await app.evaluate(()=>global.workspaceTest.canvasRead(`";b="record.report=await until(async()=>{try{return await app.evaluate(()=>global.workspaceTest.canvasRead(`";assert a in s;s=s.replace(a,b);a="length};})()`));assert.equal(record.report.rows.length";b="length};})()`));}catch{return null;}},60000);assert.equal(record.report.rows.length";assert a in s;s=s.replace(a,b)
s=s.replace("await capture('results');await page.locator('#p057-export').click();", "await capture('results');if(!record.visibleExport){await page.locator('#p057-export').click();")
s=s.replace("record.visibleExport=receipt;\n   await page.locator", "record.visibleExport=receipt;}\n   await page.locator")
p.write_text(s)
