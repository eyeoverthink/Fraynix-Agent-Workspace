from pathlib import Path
p=Path('README-060.md');s=p.read_text(encoding='utf8');s=s.replace('Use the compact failure witness to define the next finite repair family.','First check contact/timestep sensitivity and a simple equilibrium reference before attributing the measured sideways drift to a physical cause. Then use the compact failure witness to define the next finite repair family.');p.write_text(s,encoding='utf8')
p=Path('build/prepare-docs060.py');s=p.read_text(encoding='utf8');s=s.replace("'nativeVerified':'874bfd3'","'nativeVerified':'874bfd3'")
# Add compact movement table directly from actual records, without assuming their outcomes.
a="table+='\\nCompact stock retained all three measured design failures."
b="""table+='\\n| Compact candidate | Centre-force movement m | Edge-force movement m | Drop movement m | Stable design cases |\\n| --- | ---: | ---: | ---: | ---: |\\n'
for c in goals['compact']['counterfactual045']['candidates']:
 measurements=c.get('payloadDesign058',{}).get('results',[])
 table+='| '+c['id']+' | '+' | '.join(f\"{x['metrics']['maxBeamDisplacementM']:.6f}\" for x in measurements)+' | '+str(sum(x['metrics']['stable'] for x in measurements))+'/'+str(len(measurements))+' |\\n'
table+='\\nCompact stock retained all three measured design failures."""
assert a in s;s=s.replace(a,b);p.write_text(s,encoding='utf8')
