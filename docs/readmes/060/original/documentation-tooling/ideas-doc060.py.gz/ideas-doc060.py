from pathlib import Path
import json
r=Path.cwd(); index=json.loads((r/'build/idea-source060.json').read_text(encoding='utf-8-sig'))
text='''# Edition 060 · supplied organism and Java ideas

Reviewed for the existing Fraynix Agent Workspace, without replacing its integrated design. The five supplied text documents are private design material, not instructions to launch services, install handlers, flash hardware or modify a running brain. Raw conversations remain outside Git.

## Assessment

The strongest connection is the cycle **observe → record a discrepancy → propose a bounded change → execute → independently verify → retain or reject**. The workspace already owns durable goals, native state, original traces, replay, procedural skills and source-bound verifiers in Java. Edition 060 makes the connection concrete: a baseline failure witness records actual failed physical gates and a sampled translation vector; the planner proposes independent bearings; the original physics verifier and new reserved loads decide the outcome. The witness is reconstructed from verified originals during audit. A plausible explanation never substitutes for a passed experiment.

This is a useful substrate for a learning organism. It is not evidence of general intelligence, subjective awareness, physical sensor amplification, model-weight training or an optimal mechanical design. Keep those questions separate from the capabilities that can be measured.

## What was inspected

Full source bytes and type declarations were indexed, repeated prefixes compared, and relevant implementation sections inspected. The four AGI documents contain successive, overlapping conversations and code variants, not four independently validated applications. The initial dashboard and generated assessments repeat across versions. This was a scoped static review plus an exact small encoder enumeration; the proposed programs were not all compiled or executed. Existing application and edition 060 tests have their own recorded scope.

| Source | Bytes | Lines | SHA-256 |
| --- | ---: | ---: | --- |
'''
for f in index['files']:
 text+=f"| {f['file']} | {f['bytes']} | {f.get('lines','—')} | `{f['sha256']}` |\n"
text+='''
## Mechanisms worth developing

| Supplied idea | Existing home | Concrete adoption gate |
| --- | --- | --- |
| State machine, witness, sealed receipts | `GoalRunner`, `WorldLedger`, `AgentFiles042`, source-bound native reports | Implemented here: failed gates and original attempt identity admit finite repairs; rebuilding the witness rejects a changed diagnosis. |
| Durable episodic and procedural memory | Existing Java records, verified procedure versions and skill graphs | Keep one authoritative lineage. Demonstrate cold recovery and exact-policy reuse; avoid a second independent memory daemon. |
| Oja-like plasticity, sparse activation and recurrent prediction | Shared brain modules and experiment evaluation | Candidate predictor only: compare against simple motion/error baselines on frozen unseen sequences, record calibration and task outcomes, retain a rollback snapshot. |
| HDC associative retrieval and bicameral proposals | Context selection and candidate planning | Benchmark retrieval recall, collisions, missing inputs, latency and memory. Different proposal paths can improve diversity; they still need an external verifier. |
| Columnar/binary seals and compact records | Existing Java persistence and evidence cache | Golden round trips across versions, dimensions, Unicode, floating-point edge cases, truncation and atomic replacement; corruption must be reported, not silently replaced. |
| Background clock, stress/novelty and maintenance | Existing owned Java runtime scheduler | Bounded work, cancellation, observable queue depth, persistence and CPU/memory budgets. Novelty is a measurement with a threshold, not a claim of emotion. |
| Processing-style cortex/phase visualizations | Existing integrated canvas and world views | Display actual values and their units/source. Link a visible node to its real task or trace; do not display invented intelligence percentages. |
| Generated compiled kernels | An isolated candidate build/test pipeline | Compile outside the running controller, compare against a CPU reference, evaluate held-out cases, explicitly promote a version and retain rollback. No automatic live hot-swap in this edition. |

## Concrete issues in the supplied code

Line references identify the private source versions by the hashes above; they are findings about those snippets, not claims that every later variant has the same defect.

- `agi-fraynix.txt`, approximately lines 1082 and 1439: Java code calls JavaScript's `charCodeAt` and contains a malformed duplicated `if`. These variants need compilation fixes before behavior can be assessed.
- The same file, lines 1510–1515: a purported receipt execution returns `120.0` for one fixed hash and zero otherwise. That is a lookup, not a demonstrated VM execution. Lines 1527–1532 time a placeholder region between clock reads; this does not establish an air gap.
- The same file, lines 1057–1062: the proposed EP3 diagnostic transforms an absolute residual with a cube root and asserts an exceptional-point flag. It does not solve the stated eigenproblem or measure sensor accuracy. The later sequential state assignments are not independent experimental witnesses.
- `agi-fraynix-3.txt`, approximately lines 3539–3815: the recurrent connectome and Oja-like update are implementable experiments, but dense weight storage has quadratic cost. The sparse encoder's strict threshold can erase tied/zero activations. The JSR-199 modulator compile-and-swap path needs isolation, independent evaluation and rollback before promotion.
- `agi-fraynix-4.txt`, approximately lines 201–295 and 9058–9157: the SQLite path uses JDBC and catches driver failure by falling back to RAM. A SQLite driver is not supplied by the JDK. The fallback can lose the claimed durability; existing owned Java persistence is the better fit here.
- The same file, approximately lines 1730 onward: replay/scrubbing replaces the live column collection, while returning to live mode mainly changes a flag. Historical viewing should use separate immutable snapshots; the persistent world already provides explicit branch and restoration checks.
- The same file, approximately lines 2749 onward: versioned binary headers, typed values and SHA-256 trailers are useful integrity mechanisms. A digest does not authenticate an author, recover lost weights or demonstrate learning.
- The same file, approximately lines 4306 onward: the second HDC pass XORs both compared vectors with the same key. This preserves their Hamming distance exactly: `H(a xor k, b xor k) = H(a, b)`. It is not an independent adversarial check. Physics and reserved-case verification must remain external to candidate votes.
- The same file, approximately lines 7951–8060: phase/permutation calculations and emitted WASM integer operations can become reproducible numerical demonstrations. They do not establish physical quantum processing. A compiler needs reference-output, inverse-operation and malformed-input tests before use.
- The same file, approximately lines 8885 onward: exact enumeration of all 4,095 nonzero messages using the supplied `Golay24Codec` rows found a minimum codeword weight of **7**, with message 1025 producing `0x401592`. For this linear code, that is minimum distance 7, which still supports unique correction of up to three bit errors. It does not match the advertised extended distance 8. The nearest-codeword routine also needs an explicit uncorrectable policy; errors beyond the guaranteed radius must not become silent repairs. No arbitrary model weights can be reconstructed from a digest alone.
- The same file, approximately lines 10045 onward: the ESP32 example orders measured FFT peaks and then imposes a permutation in software. A closed-permutation printout is not independent physical validation. Calibration, sensor timing and genuinely independent measurements would need separate evidence.

## Next phases for the brain

1. **Experience retrieval:** index verified repair traces by geometry, measured failure and action cost; retrieve candidates while always rechecking the current world. Compare against the existing finite-order baseline on newly reserved geometry.
2. **Predictor trial:** implement one bounded sparse/HDC or recurrent candidate alongside a simple reference predictor. Measure prediction error, uncertainty coverage, resource cost and successful task completion on separate training/evaluation cases.
3. **Promotion and rollback:** retain candidate versions and evaluations; promote only a repeatable improvement under a frozen rule. Restart must preserve the selected version and its provenance.
4. **Integrated introspection:** show the same real goals, observations, candidate predictions, failures and memory retrievals in the existing workspace. This provides an inspectable operational self-model without inventing psychological claims.

Edition 060 adopts the measured-witness separation, not the untested neural, quantum or hardware claims. Independent bearing placement is still a small rigid-body simulation experiment; outcomes and limits are recorded in [README-060](../README-060.md) and its validation artifacts.
'''
(r/'docs/IDEAS_060_REVIEW.md').write_text(text,encoding='utf-8')
# Publish metadata and the exact bounded probe only, not private source text or type inventories.
public={k:v for k,v in index.items() if k!='files'}
public['files']=[{k:v for k,v in f.items() if k!='types'} for f in index['files']]
(r/'docs/IDEAS_060_PROVENANCE.json').write_text(json.dumps(public,indent=2)+'\n')
