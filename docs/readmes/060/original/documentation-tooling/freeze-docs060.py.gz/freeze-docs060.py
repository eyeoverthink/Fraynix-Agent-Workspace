from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).resolve().parent.parent;d=r/'docs/readmes/060'
def canon(p):return p.read_text(encoding='utf8').replace('\r\n','\n').encode()
snap=[]
for p in sorted(d.rglob('*')):
 if p.is_file():
  binary=p.suffix in ['.png','.jpg','.gz','.zip']
  snap.append({'path':p.relative_to(r).as_posix(),'kind':'binary' if binary else 'text','sha256':hashlib.sha256(p.read_bytes() if binary else canon(p)).hexdigest()})
p=r/'docs/readmes/editions.json';m=json.loads(p.read_text(encoding='utf8'));assert m['latest'] in [59,60]
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
e={'number':60,'date':'2026-11-04','title':'Independent bearings and measured compact repairs','status':'validated-local','markdown':'README-060.md','markdownSha256':hashlib.sha256(canon(r/'README-060.md')).hexdigest(),'companion':'docs/readmes/060/index.html','tag':'readme-060','sourceBaseline':source,'snapshotDirectory':'docs/readmes/060','snapshotFiles':snap}
m['editions']=[x for x in m['editions'] if x['number']!=60]+[e];m['latest']=60;p.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n',encoding='utf8');print('Frozen',len(snap),'new snapshot files; earlier entries unchanged')
