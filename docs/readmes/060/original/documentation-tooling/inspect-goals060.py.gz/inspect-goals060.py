from pathlib import Path
import struct,io,json,hashlib
p=Path(r'C:/Users/eyeka/AppData/Local/Temp/fraynix-construction060-whSj47/goals/tasks.fworld');raw=p.read_bytes();magic,version,length=struct.unpack('>III',raw[:12]);assert magic==0x4657524c and version==1 and len(raw)-44==length and hashlib.sha256(raw[44:]).digest()==raw[12:44];f=io.BytesIO(raw[44:])
def integer():return struct.unpack('>i',f.read(4))[0]
def string():return f.read(integer()).decode()
revision=struct.unpack('>q',f.read(8))[0];rows=[]
for _ in range(integer()):
 eid=string();name=string()
 for _ in range(integer()):
  cid=string();kind=string();ver=integer();fields={}
  for _ in range(integer()):
   key=string();fields[key]=string()
  for k,v in fields.items():
   try:d=json.loads(v)
   except:continue
   if isinstance(d,dict) and 'status' in d and 'step' in d:rows.append({k:d.get(k) for k in ['id','status','step','reason','updatedAt','report','savedSkill']})
print(json.dumps({'revision':revision,'goals':rows},indent=2))
