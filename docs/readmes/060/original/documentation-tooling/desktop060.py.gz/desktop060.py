from pathlib import Path
p=Path('workspace-desktop/renderer/construction051.js');s=p.read_text(encoding='utf8')
s=s.replace('<button id="d059-example">','<button id="d060-example">Independent bearings · compact stock</button><button id="d059-example">')
s=s.replace('<label class="design053-check"><input id="d059-enable"','<label class="design053-check"><input id="d060-enable" type="checkbox">Edition 060: independent support positions and rotations</label><p>Test compact stock with the original layout, a rotated right bearing, then two rotated bearings. Actual baseline failure admits repairs. Keep the same parts and force limits; fresh execution and four unfamiliar payloads decide whether the procedure can be saved.</p><label class="design053-check"><input id="d059-enable"')
s=s.replace("$('d059-enable').onchange=()=>{if($('d059-enable').checked){", "$('d059-enable').onchange=()=>{if($('d059-enable').checked){$('d060-enable').checked=false;")
anchor="  $('d059-example').onclick="
assert anchor in s
s=s.replace(anchor,"  $('d060-enable').onchange=()=>{if($('d060-enable').checked){$('d059-enable').checked=false;$('d058-enable').checked=true;$('d058-enable').onchange();}};\n  $('d060-example').onclick=()=>this.action(async()=>{this.requireSaved();await this.geometryChoices();$('c054-preset').value='compact';this.geometryFields();$('c054-span').value=1;$('d060-enable').checked=true;$('d060-enable').onchange();$('d058-allow').checked=true;$('d053-force').value=40;const w=await this.call('create',{title:'LABELLED060 · independent bearings on compact stock',...this.geometryInput()});this.id=w.id;await this.refresh();$('design053-options').open=true;});\n"+anchor)
s=s.replace("$('d058-example').onclick=()=>this.action(async()=>{", "$('d058-example').onclick=()=>this.action(async()=>{$('d060-enable').checked=false;")
s=s.replace("applyTaskControls056(task,name){", "applyTaskControls056(task,name){$('d060-enable').checked=!!task.independentSupports060;")
s=s.replace("asymmetricSupports059:$('d059-enable').checked,", "asymmetricSupports059:$('d059-enable').checked,independentSupports060:$('d060-enable').checked,")
s=s.replace("${design&&$('d058-enable').checked&&$('d059-enable').checked?", "${design&&$('d058-enable').checked&&$('d060-enable').checked?'; compare independent supports using the edition 060 payload protocol':''}${design&&$('d058-enable').checked&&$('d059-enable').checked?")
# Add evidence readout with text-only output (no imported HTML).
s=s.replace('<ol id="d053-trials"></ol>', '<ol id="d053-trials"></ol><div id="d060-evidence" class="muted" role="status"></div>')
anchor="const list=$('d053-trials');list.replaceChildren();"
assert anchor in s
s=s.replace(anchor,anchor+"const witness=design?.repairEvidence060;$('d060-evidence').textContent=witness?('Baseline witness: '+(witness.baselineQualifies?'all design cases passed; repair trials not admitted':witness.failures.map(f=>f.caseId+': '+f.failedGates.join(', ')+(f.sampledTranslation?' · sampled Δ(x,y,z) '+f.sampledTranslation.deltaM.map(n=>Number(n).toFixed(4)).join(', ')+' m':'')).join(' | '))):'';")
# Append actual independent pose hypotheses to trial summary string after list constructed.
needle="$('d054-summary').textContent="
assert needle in s
s=s.replace(needle,"if(design?.candidates){[...list.children].forEach((li,i)=>{const h=design.candidates[i]?.hypothesis053;if(h?.supportA060&&h?.supportB060){const p=document.createElement('p');p.textContent=['supportA060','supportB060'].map((k,n)=>{const v=h[k];return `Bearing ${n?'B':'A'}: x ${v.x.toFixed(3)} m, z ${v.z.toFixed(3)} m, yaw ${v.yawDeg}°`;}).join(' · ');li.append(p);}});}"+needle)
p.write_text(s,encoding='utf8')
p=Path('workspace-desktop/policy.cjs');s=p.read_text();s=s.replace('asymmetricSupports059?,','asymmetricSupports059?,independentSupports060?,').replace('"asymmetricSupports059": {"type": "boolean"},','"asymmetricSupports059": {"type": "boolean"}, "independentSupports060": {"type": "boolean"},');p.write_text(s)
p=Path('workspace-desktop/exports.cjs');s=p.read_text();needle="(value.format==='fraynix.payload-redesign-059-v1'&&value.originals?.manifest?.edition===59)";assert needle in s;s=s.replace(needle,needle+"||(value.format==='fraynix.payload-redesign-060-v1'&&value.originals?.manifest?.edition===60)");p.write_text(s)
