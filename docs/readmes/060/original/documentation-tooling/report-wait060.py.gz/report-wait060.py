from pathlib import Path
p=Path('workspace-desktop/test/construction060-integration.cjs');s=p.read_text();a="!!document.querySelector(\"#redesign058-table tbody tr\")";b=a+" && !!document.querySelector(\"#repair060-witness\")";assert a in s;s=s.replace(a,b);p.write_text(s)
