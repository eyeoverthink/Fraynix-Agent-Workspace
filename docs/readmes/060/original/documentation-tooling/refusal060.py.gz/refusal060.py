from pathlib import Path
p=Path('workspace-engine/src/main/java/fraymus/workspace/SupportRepair060.java');s=p.read_text();a='var plan=WorldPlan.build(scene,Construction051.intent(scene,c,intent.getDouble("forceLimitN"),intent.getDouble("torqueLimitNm")));';b='''JSONObject plan;
            try{plan=WorldPlan.build(scene,Construction051.intent(scene,c,intent.getDouble("forceLimitN"),intent.getDouble("torqueLimitNm")));}
            catch(IllegalArgumentException refused){
                if(i==0)throw refused;
                // A measured comparison retains a geometry refusal without inventing an executable route.
                plan=new JSONObject().put("version","refused-independent-placement-060-v1").put("intent",new JSONObject().put("binding",SpatialStore.binding(scene)).put("construction051",c).put("forceLimitN",intent.getDouble("forceLimitN")).put("torqueLimitNm",intent.getDouble("torqueLimitNm"))).put("orderedTargets",new JSONArray()).put("liftHeightM",0).put("passed",false).put("reason",refused.getMessage()).put("rejectedGeometry060",true);
            }''';assert a in s;s=s.replace(a,b);p.write_text(s)
p=Path('workspace-engine/src/test/java/fraymus/workspace/Design060Test.java');s=p.read_text();a='if(original.getJSONObject("payloadDesign058").getBoolean("qualifies"))assertEquals("not-needed",c.getString("status"));';b='if(c.getString("status").equals("rejected")){assertTrue(c.getJSONArray("attempts").isEmpty());assertFalse(c.has("payloadDesign058"));}else if(original.getJSONObject("payloadDesign058").getBoolean("qualifies"))assertEquals("not-needed",c.getString("status"));';assert a in s;s=s.replace(a,b);p.write_text(s)
p=Path('workspace-engine/src/test/java/fraymus/workspace/Support060Test.java');s=p.read_text();i=s.rfind('\n}');s=s[:i]+'''
 @Test public void tooNarrowRotatedBearingIsRetainedAsRefusalNotAnExecutableRoute()throws Exception{
  var root=Files.createTempDirectory("support060-refusal-");var worlds=new WorldLedger(root);var input=Load056Test.input(worlds,"wide",1.9,0);var source=worlds.source(worlds.observe(input.getString("worldId")));var proposals=SupportRepair060.proposals(source,worlds.preview(input));assertTrue(proposals.getJSONObject(0).getJSONObject("plan").getBoolean("passed"));for(int i=1;i<3;i++){var p=proposals.getJSONObject(i).getJSONObject("plan");assertFalse(p.getBoolean("passed"));assertTrue(p.getBoolean("rejectedGeometry060"));assertTrue(p.getJSONArray("orderedTargets").isEmpty());assertTrue(p.getString("reason").contains("cover beam width"));}
 }
'''+s[i:];p.write_text(s)
