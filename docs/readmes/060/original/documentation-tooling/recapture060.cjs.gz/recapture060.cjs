const {launch}=require('../workspace-desktop/test/calibration-integration.cjs');
const fs=require('node:fs/promises'),path=require('node:path'),assert=require('node:assert/strict');
const wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const out=path.resolve(__dirname,'../workspace-desktop/test-output'),record=JSON.parse(await fs.readFile(path.join(out,'construction060-live.json'),'utf8'));
 process.env.FRAYNIX_WORKSPACE_PERSISTENT='0';process.env.FRAYNIX_WORKSPACE_PLAN_CPU_ONLY='1';
 const {app,page}=await launch(record.project);
 try{
  await page.locator('#spatial-tab').click();await page.locator('#construction051').evaluate(e=>e.open=true);
  await page.waitForFunction(()=>!document.querySelector('#c051-world').disabled);await page.locator('#c051-world').selectOption(record.worldId);
  await page.locator('#d053-report').click();
  let ready=false;for(let n=0;n<120&&!ready;n++){try{ready=await app.evaluate(()=>global.workspaceTest.canvasRead('!!document.querySelector("#payload057-scene")'));}catch{}if(!ready)await wait(500);}
  assert(ready);await wait(1000);
  let replay;for(let n=0;n<120&&!replay;n++){try{replay=await app.evaluate(()=>global.workspaceTest.canvasRead(`(async()=>{const s=document.querySelector('#payload057-case');s.value='selected-reserved/reserved060-edge';s.dispatchEvent(new Event('change'));const t=document.querySelector('#payload057-time');t.value=119;t.dispatchEvent(new Event('input'));document.querySelector('#payload057-scene').scrollIntoView({block:'center',behavior:'instant'});await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return{tick:Number(document.querySelector('#payload057-scene').dataset.tick),caseId:s.value,scrollY,rect:document.querySelector('#payload057-scene').getBoundingClientRect().toJSON()};})()`));
  }catch{}if(!replay)await wait(500);}assert(replay);assert.equal(replay.tick,1440);
  await app.evaluate(({BrowserWindow,webContents})=>{const w=BrowserWindow.getAllWindows().find(w=>w.getTitle().includes('Fraynix'));w.show();w.focus();webContents.fromId(global.workspaceTest.surfaces().canvas).focus();});await wait(1000);
  replay.after=await app.evaluate(()=>global.workspaceTest.canvasRead('({scrollY,tick:document.querySelector("#payload057-scene").dataset.tick})'));
  await fs.mkdir(path.join(__dirname,'ui060-replay-capture'),{recursive:true});await fs.copyFile(path.join(out,'construction060-replay.png'),path.join(__dirname,'ui060-replay-capture/first.png'));
  await fs.writeFile(path.join(out,'construction060-replay.png'),Buffer.from(await app.evaluate(()=>global.workspaceTest.capture()),'base64'));
  await fs.writeFile(path.join(__dirname,'ui060-replay-capture/result.json'),JSON.stringify({source:record.source,project:record.project,reason:'First screenshot captured the previous compositor frame after programmatic scrolling. Reopened the exact saved report and waited for its rendered frame; no experiment repeated.',replay},null,2));
  console.log(JSON.stringify(replay));
 }finally{await app.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
