from pathlib import Path
r=Path.cwd();old=r.parent/'fraynix-workspace-edition059/build';b=r/'build'
for name in ['freeze-docs059.py','check-docs059.cjs','audit-publication059.py','record-publication059.py','publish059.ps1','stage059.py','preflight059.py']:
 s=(old/name).read_text(encoding='utf8').replace('059','060')
 s=s.replace('number\']==59','number\']==60').replace('m[\'latest\'] in [58,59]','m[\'latest\'] in [59,60]').replace("'number':59","'number':60").replace("x['number']!=59","x['number']!=60").replace("m['latest']=59","m['latest']=60").replace("m['latest']==59","m['latest']==60").replace("m['editions'][:58]","m['editions'][:59]").replace("'priorManifestEntriesExact':58","'priorManifestEntriesExact':59").replace('d872b1f','e029c4d')
 s=s.replace('Faster evidence and asymmetric supports','Independent bearings and measured compact repairs').replace('Faster evidence. Asymmetric supports.','Independent bearings. Measured repairs.').replace('verified evidence reuse and asymmetric support payload evaluation','independent bearings, measured compact repair limits and new reserved payloads')
 s=s.replace('67-asymmetric-evidence','68-independent-bearings').replace('asymmetric-evidence.canvas','independent-bearings.canvas')
 if name=='check-docs059.cjs':s=s.replace('document.images.length===7','document.images.length===8').replace('images:7','images:8').replace('Evidence060.java','SupportRepair060.java').replace('Richer repair space','Experience retrieval and restraint experiments')
 if name=='stage059.py':s=s.replace("'docs/VALIDATION_060.json',","'docs/VALIDATION_060.json','docs/IDEAS_060_REVIEW.md','docs/IDEAS_060_PROVENANCE.json',")
 (b/name.replace('059','060')).write_text(s,encoding='utf8')
# Build the new preparation script from the established original-evidence archiver.
s=(old/'prepare-docs059.py').read_text(encoding='utf8').replace('059','060')
a=s.index("shots=[('stock'");z=s.index("shots=[('construction060",a)
s=s[:a]+"shots=[('stock','Compact stock before assembly'),('compact','Measured compact failure; no world promotion'),('review','Wide original layout awaiting review'),('results','Fresh wide design and unfamiliar payload results'),('report','Actual verified report and phase table'),('replay','Recorded motion under the new edge payload'),('chat','Completed local-model saved-skill reuse'),('narrow','Changed-centre compact outcome at narrow width')]\n"+s[z:]
s=s.replace("for key in ['chat','reused']:","for key in ['compactChat','reused']:")
s=s.replace("goals={'wide':live['first'],'changedCentre':live['chat']['completion044']['javaGoal'],'compact':live['compactGoal']}","goals={'wide':live['first'],'changedCompact':live['compactChangedGoal'],'compact':live['compact'],'reuseWide':live['reuseGoal']}")
s=s.replace("'edition':59", "'edition':60").replace("'nativeVerified':'111ddd0'","'nativeVerified':'874bfd3'").replace("'rendererTextCorrection':'ada2b96',",'').replace("['first','chat','reused']","['first','compactChat','reused']").replace("'desktopUnitTests':126","'desktopUnitTests':127")
a=s.index('performance=json.loads(');z=s.index("first=results['wide']",a);s=s[:a]+s[z:]
a=s.index("table+='\\nThe original symmetric");z=s.index("s=(r/'README-060.md')",a)
s=s[:a]+'''table+='\\nCompact stock retained all three measured design failures. The wide workflow uses its original 1.9 m spacing; rotated alternatives are geometrically refused because the rotated stock cannot cover the wider beam. That is successful validation of the original wide layout, not evidence that compact repair succeeded.\\n\\n'
table+=f"**{len(passed)} distinct targeted Java cases across {len(classes)} classes**, **127 desktop checks**, and the actual app/local-model workflow passed with source-qualified evidence.\\n\\n"
table+=f"The first wide workflow took **{timing['first']['wallSeconds']:.3f} seconds**, including intentional review and restart. Changed-centre compact chat took **{timing['compactChat']['wallSeconds']:.3f} seconds** and ended **{timing['compactChat']['status']}**; cold saved-skill reuse took **{timing['reused']['wallSeconds']:.3f} seconds** and ended **{timing['reused']['status']}**. These include persistence and verification, not just model generation.\\n\\n"
for name,g in goals.items():
 data=g.get('payload057');table+=f"- **{name}:** {g['status']}. "
 if data:table+=f"Fresh design: {data['freshDesignPassed']}; selected reserved: {data['selectedReservedPassed']}. {data['attempts']} payload attempts, {data['totalTicks']} design/reserved ticks, {data['completeTaskTicks']} complete native ticks."
 else:table+=g.get('reason','No completed evaluation')+' No successful world or skill promotion.'
 table+='\\n'
table+='\\nThe compact native runs and actual app attempts retain their displacement, contact and repeat measurements. Failed development checks are also preserved: the initial wide candidate planner incorrectly aborted the valid baseline when a rotated alternative was geometrically invalid. The corrected planner retains that alternative as a refusal with no route or actuation.\\n\\n'
''' +s[z:]
s=s.replace("note='docs/obsidian/67-asymmetric-evidence.md'","note='docs/obsidian/68-independent-bearings.md'")
s=s.replace('Faster evidence and asymmetric supports','Independent bearings and measured repairs').replace('Java selects a support-pair offset using measured design failures','Java tests independent support placements using measured design failures').replace('docs/obsidian/66-payload-redesign','docs/obsidian/67-asymmetric-evidence')
a=s.index('modules=[');z=s.index("data={'edition'",a)
s=s[:a]+'''modules=[('decision','Independent bearing hypotheses','Fixed same-stock positions and rotations; measured failure admits alternatives.','workspace-engine/src/main/java/fraymus/workspace/SupportRepair060.java','Verified'),('witness','Measured repair witness','Failed gates and sampled translation reconstructed from original measurements.','docs/IDEAS_060_REVIEW.md','Reviewed and tested scope'),('goal','Java goal and exact skill','Fresh execution, paired evaluation, original report and promotion gates.','workspace-engine/src/main/java/fraymus/workspace/GoalRunner.java','Verified'),('report','Verified phase report','Actual tables, curves and replay checked against original records.','workspace-engine/src/main/java/fraymus/workspace/PayloadReport057.java','Verified'),('view','Integrated controls and chat','Visible example, actual local-model task, saved policy and original export.','workspace-desktop/renderer/construction051.js','Actual app verified'),('next','Experience retrieval and restraint experiments','New finite repairs with declared part/action costs and newly reserved conditions.','docs/EDITION_060_CONTRACT.md','Planned')]
''' +s[z:]
s=s.replace("'edition':59","'edition':60").replace("docs/readmes/058/file-inventory.json","docs/readmes/059/file-inventory.json").replace("'d872b1f'","'e029c4d'")
s=s.replace('Faster evidence. Asymmetric supports.','Independent bearings. Measured repairs.').replace('Same stock and span. New loads. Verified evidence reused after hashing original bytes.','Independent poses. Same stock. Measured compact failures retained. New reserved loads and exact saved skills.').replace('../058/index.html','../059/index.html')
s=s.replace('Spatial → Gripper assembly → Asymmetric supports · new payloads.','Spatial → Gripper assembly → Independent bearings · compact stock.').replace('Java tests the original layout and admits left/right shifted layouts only after measured design failure.','Java measures the original layout, then independently positioned/rotated bearings only after measured design failure.').replace('Try Evidence060.java','Try SupportRepair060.java')
a=s.index("body=body.replace('<section id=\"features\">'");z=s.index("write(d/'index.html'",a);s=s[:a]+s[z:]
s=s.replace('asymmetric-evidence.canvas','independent-bearings.canvas')
s=s.replace('Edition 058','Edition 059').replace('README-058','README-059').replace('is **058**','is **059**')
s=s.replace('is **059**\',\'is **060**','is **059**\',\'is **060**')
# Replace entry-point update and historical index update with specific current-edition logic.
a=s.index("p=r/'README.md'");z=s.index("p=r/'docs/JAVA_CHAT_044.md'",a)
s=s[:a]+'''p=r/'README.md';content=p.read_text(encoding='utf-8');content=re.sub(r'> \\*\\*\\[Edition 059.*','> **[Edition 060 · Independent bearings and measured repairs](README-060.md)** · [Offline guide](docs/readmes/060/index.html) · [Operation](docs/JAVA_CHAT_044.md) · [Edition history](docs/readmes/INDEX.md)',content,count=1);write(p,content)
p=r/'docs/readmes/INDEX.md';content=p.read_text(encoding='utf-8');write(p,content.replace('\\nLatest implementation','\\n| [060](../../README-060.md) | 2026-11-04 | Independent bearings and measured repairs | [Viewer](060/index.html) · [tree](060/FILE_TREE.md) |\\n\\nLatest implementation').replace('is **059**','is **060**'))
''' +s[z:]
s=s.replace('Asymmetric supports · new payloads creates labelled stock','Independent bearings · compact stock creates labelled stock').replace('126 desktop checks','127 desktop checks').replace('immutable001–058','immutable001–059').replace('seven actual screenshots','eight actual screenshots').replace('Next: individually placed supports or braces with predeclared costs and newly reserved conditions.','Next: new finite restraint/support options and evidence retrieval, with explicit costs and newly reserved conditions; compact repair remains unverified.')
s=s.replace("p.name in ['state.json'","p.name in ['forecast-originals.json','state.json'")
s=s.replace("for p in sorted(out.glob('construction060-*.json')):","for name in ['IDEAS_060_REVIEW.md','IDEAS_060_PROVENANCE.json','EDITION_060_CONTRACT.md']:shutil.copyfile(r/'docs'/name,d/name)\nfor p in sorted(out.glob('construction060-*.json')):")
(b/'prepare-docs060.py').write_text(s,encoding='utf8')
