from pathlib import Path
import statistics
import json,hashlib,re,subprocess,shutil,gzip,datetime,xml.etree.ElementTree as ET,html

r=Path(__file__).resolve().parent.parent;d=r/'docs/readmes/060';out=r/'workspace-desktop/test-output';d.mkdir(exist_ok=True)
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
live=json.loads((out/'construction060-live.json').read_text(encoding='utf-8'));assert live['passed'];source=live['source']
phaseSources={}
for evidence in sorted(out.glob('construction060-failed-*.json'))+[out/'construction060-live.json']:
 record=json.loads(evidence.read_text(encoding='utf-8'))
 for phase in ['compact','compactChat','first','reportFiles','reused','cancelled']:
  if phase in record:phaseSources.setdefault(phase,record.get(phase+'Source',record['source']))

shots=[('stock','Compact stock before assembly'),('compact','Measured compact failure; no world promotion'),('review','Wide original layout awaiting review'),('results','Fresh wide design and unfamiliar payload results'),('report','Actual verified report and phase table'),('replay','Recorded motion under the new edge payload'),('chat','Completed local-model saved-skill reuse'),('narrow','Changed-centre compact outcome at narrow width')]
shots=[('construction060-'+name+'.png',title) for name,title in shots]
for name,_ in shots:shutil.copyfile(out/name,d/name)
shutil.copyfile(out/'construction060-live.json',d/'desktop-live.json');shutil.copyfile(r/'build/runtime060-process.json',d/'runtime-process.json');shutil.copyfile(r/'build/encoder060-java.json',d/'encoder-java-result.json');shutil.copyfile(r/'scripts/ProbeSuppliedEncoder060.java',d/'ProbeSuppliedEncoder060.java')
archives=[];seen=set();roots=set();byraw={}
def pack(p,dest):
 if len(str(dest))>=235:dest=d/'original/long-path-records'/(sha(dest.relative_to(d).as_posix().encode())+'.gz')
 if dest in seen:return
 seen.add(dest);b=p.read_bytes();digest=sha(b)
 if digest in byraw:
  byraw[digest].setdefault('aliases',[]).append({'source':str(p),'proposedPath':dest.relative_to(r).as_posix()});return
 z=gzip.compress(b,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archives.append({'path':dest.relative_to(r).as_posix(),'bytes':len(z),'sha256':sha(z),'rawBytes':len(b),'rawSha256':sha(b),'source':str(p),'format':'gzip of original bytes'});byraw[digest]=archives[-1]
invocations=[];cases={}
for base in sorted((r/'build').glob('native060-*')):
 src=(base/'source.txt').read_text(encoding='utf-8-sig').strip();rows=[]
 for p in sorted(base.rglob('TEST-*.xml')):
  tree=ET.parse(p).getroot()
  for c in tree.findall('testcase'):rows.append({'case':c.attrib['classname']+'#'+c.attrib['name'],'passed':c.find('failure') is None and c.find('error') is None and c.find('skipped') is None,'seconds':float(c.attrib['time'])})
  for match in re.findall(r'C:\\Users\\eyeka\\AppData\\Local\\Temp\\[^\s<]+',p.read_text(encoding='utf-8')):
   path=Path(match.strip())
   if path.is_dir():roots.add(path)
  pack(p,d/'java'/base.name/(p.name+'.gz'))
 v={'label':base.name,'source':src,'count':len(rows),'failures':sum(not x['passed'] for x in rows),'cases':rows};invocations.append(v);js(d/(base.name+'.json'),v)
 for row in rows:cases.setdefault(row['case'],[]).append(row)
 for p in base.glob('*.log'):pack(p,d/'java'/base.name/(p.name+'.gz'))
passed=[k for k,rows in cases.items() if any(x['passed'] for x in rows)];classes={x.split('#')[0] for x in passed}
for p in sorted((r/'build').glob('test060*.log')):pack(p,d/'logs'/(p.name+'.gz'))
pack(r/'build/ProbeSuppliedEncoder060-first.java',d/'original/analysis/ProbeSuppliedEncoder060-first.java.gz')
for p in sorted((r/'build').glob('*060.*')):
 if p.suffix in ['.py','.cjs','.ps1','.gradle']:pack(p,d/'original/documentation-tooling'/(p.name+'.gz'))
def project(base,label):
 for p in base.rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(base).as_posix()
  if p.name in ['forecast-originals.json','state.json','studies.json','tasks.json','tasks.fworld','results.json','summary.json','result.json','original.json','test-desktop-process.log','engine.log','evaluation-summary.json','design-summary.json','all-originals.json','partial-originals.json','fresh-assembly.json','performance.json','original-pin.json'] or p.name.endswith('-original.json') or ('payload-058/' in rel or 'evaluation/' in rel or 'loads/' in rel or rel.startswith('exports/')) and p.suffix in ['.json','.jsonl','.bin'] or ('checkpoints/' in rel or rel.startswith('receipts/')) and p.suffix=='.json' or p.name.endswith('.pending'):pack(p,d/'original'/label/(rel+'.gz'))
project(Path(live['project']),'actual-app')
for root in sorted(roots):project(root,'native/'+root.name)
for name in ['IDEAS_060_REVIEW.md','IDEAS_060_PROVENANCE.json','EDITION_060_CONTRACT.md']:shutil.copyfile(r/'docs'/name,d/name)
for p in sorted(out.glob('construction060-*.json')):pack(p,d/'original/exports'/(p.name+'.gz'))
failures=[]
for p in sorted(out.glob('construction060-failed-*.json')):
 v=json.loads(p.read_text(encoding='utf-8'));failures.append({'record':p.name,'source':v['source'],'error':v['error'],'project':v['project']})
 if Path(v['project'])!=Path(live['project']):project(Path(v['project']),p.stem)
for p in (r/'build').glob('ui060-*.json'):pack(p,d/'original/development-ui'/(p.name+'.gz'))
for base in sorted((r/'build').glob('ui060-*')):
 for p in base.rglob('*'):
  if p.is_file():pack(p,d/'original/development-ui'/base.name/(p.relative_to(base).as_posix()+'.gz'))
timing={'first':{'wallSeconds':(datetime.datetime.fromisoformat(live['firstFinishedAt'])-datetime.datetime.fromisoformat(live['firstStartedAt'])).total_seconds(),'scope':'Initial goal observation to verified completion, including the intentional review and desktop restart'}}
for key in ['compactChat','reused']:
 t=live[key];start=datetime.datetime.fromisoformat(t['createdAt']);end=datetime.datetime.fromisoformat(t.get('finishedAt',t['history'][-1]['at']))
 timing[key]={'wallSeconds':(end-start).total_seconds(),'endBasis':'finishedAt or last terminal history event','status':t['status'],'timing052':t.get('timing052',{}),'planningCalls':sum(h['kind']=='plan' for h in t['history']),'repairs':[h['detail'] for h in t['history'] if h['kind']=='repair'],'source':live.get(key+'Source',source)}
goals={'wide':live['first'],'changedCompact':live['compactChangedGoal'],'compact':live['compact'],'reuseWide':live['reuseGoal']}
results={name:g.get('payload057',{}) for name,g in goals.items()}
v={'edition':60,'date':'2026-11-04','source':source,'runtimeComponents':{'nativeVerified':'874bfd3','observedIsolatedProcess':json.loads((r/'build/runtime060-process.json').read_text(encoding='utf-8-sig')),'installedJava':(r/'build/install-source060.txt').read_text(encoding='utf-8').strip(),'actualPhases':phaseSources},'passed':True,'javaCount':len(passed),'javaSuites':len(classes),'javaInvocations':invocations,'javaScope':'Distinct targeted passing cases across source-qualified invocations; not a single full-suite run. Original attempts and any development failures remain archived.','desktopUnitTests':127,'integration':live['checks'],'timing':timing,'developmentFailures':failures,'results':results,'goalStatus':{name:{k:g.get(k) for k in ['status','reason','worldCommit','savedSkill']} for name,g in goals.items()},'sourceProjects':[str(p) for p in sorted(roots)],'continuations':live.get('continuations',[]),'desktopReopenObservations':live.get('opens',[]),'scope':'Predeclared independent-bearing same-stock native rigid-body redesign and paired reserved payload cases. Reserved conditions excluded from selection. Deterministic repeats are not independent physical trials. No material-strength, hardware, general learning or model-weight-training claim.'}
v['candidateResults']={name:[{'id':c['id'],'status':c.get('status'),'reason':c.get('reason'),'hypothesis':c.get('hypothesis053'),'stableDesignCases':sum(x['metrics']['stable'] for x in c.get('payloadDesign058',{}).get('results',[])),'designCases':len(c.get('payloadDesign058',{}).get('results',[]))} for c in g.get('counterfactual045',{}).get('candidates',[])] for name,g in goals.items()}
js(d/'verification.json',v);js(r/'docs/VALIDATION_060.json',v);js(d/'original-evidence.json',{'scope':'Complete original synthetic native attempts, contacts, decisions, interruptions and source-qualified development failures. Private mat/camera data excluded.','files':archives})
first=results['wide'];groups={g['phase']:g['summary'] for g in first['groups']};baseline=groups['baseline-reserved'];selected=groups['selected-reserved']
table='| Reserved payload | Original layout | Selected fresh layout | Original movement m | Selected movement m |\n| --- | --- | --- | ---: | ---: |\n'
for a,b in zip(baseline['results'],selected['results']):table+='| '+a['caseId']+' | '+('Stable' if a['metrics']['stable'] else '**Unstable**')+' | '+('Stable' if b['metrics']['stable'] else '**Unstable**')+f" | {a['metrics']['maxBeamDisplacementM']:.6f} | {b['metrics']['maxBeamDisplacementM']:.6f} |\n"
table+='\n| Compact candidate | Centre-force movement m | Edge-force movement m | Drop movement m | Stable design cases |\n| --- | ---: | ---: | ---: | ---: |\n'
for c in goals['compact']['counterfactual045']['candidates']:
 measurements=c.get('payloadDesign058',{}).get('results',[])
 table+='| '+c['id']+' | '+' | '.join(f"{x['metrics']['maxBeamDisplacementM']:.6f}" for x in measurements)+' | '+str(sum(x['metrics']['stable'] for x in measurements))+'/'+str(len(measurements))+' |\n'
table+='\nCompact stock retained all three measured design failures. The wide workflow uses its original 1.9 m spacing; rotated alternatives are geometrically refused because the rotated stock cannot cover the wider beam. That is successful validation of the original wide layout, not evidence that compact repair succeeded.\n\n'
table+=f"**{len(passed)} distinct targeted Java cases across {len(classes)} classes**, **127 desktop checks**, and the actual app/local-model workflow passed with source-qualified evidence.\n\n"
table+=f"The first wide workflow took **{timing['first']['wallSeconds']:.3f} seconds**, including intentional review and restart. Changed-centre compact chat took **{timing['compactChat']['wallSeconds']:.3f} seconds** and ended **{timing['compactChat']['status']}**; cold saved-skill reuse took **{timing['reused']['wallSeconds']:.3f} seconds** and ended **{timing['reused']['status']}**. These include persistence and verification, not just model generation.\n\n"
for name,g in goals.items():
 data=g.get('payload057');table+=f"- **{name}:** {g['status']}. "
 if data:table+=f"Fresh design: {data['freshDesignPassed']}; selected reserved: {data['selectedReservedPassed']}. {data['attempts']} payload attempts, {data['totalTicks']} design/reserved ticks, {data['completeTaskTicks']} complete native ticks."
 else:table+=g.get('reason','No completed evaluation')+' No successful world or skill promotion.'
 table+='\n'
table+='\nThe compact native runs and actual app attempts retain their displacement, contact and repeat measurements. Failed development checks are also preserved: the initial wide candidate planner incorrectly aborted the valid baseline when a rotated alternative was geometrically invalid. The corrected planner retains that alternative as a refusal with no route or actuation.\n\n'
s=(r/'README-060.md').read_text(encoding='utf-8');assert '{{MEASURED_RESULTS}}' in s and '{{SCREENSHOTS}}' in s
screens='\n\n'.join(f'### {title}\n\n![{title}](docs/readmes/060/{name})\n\nNovember 4, 2026 UTC · actual app capture · labelled synthetic practice scene. [Original image](docs/readmes/060/{name}).' for name,title in shots)
write(r/'README-060.md',s.replace('{{MEASURED_RESULTS}}',table).replace('{{SCREENSHOTS}}',screens))
note='docs/obsidian/68-independent-bearings.md';write(r/note,'# Independent bearings and measured repairs\n\nJava tests independent support placements using measured design failures, pins its decision, executes freshly and evaluates reserved payloads on both baseline and selected construction. Original evidence, negative outcomes and exact procedural policy remain retained.\n\n- [[README-060]]\n- [[docs/EDITION_060_CONTRACT]]\n- [[docs/obsidian/67-asymmetric-evidence]]\n\nNext: individually placed supports or braces with declared material/action costs and newly reserved conditions.\n')
modules=[('decision','Independent bearing hypotheses','Fixed same-stock positions and rotations; measured failure admits alternatives.','workspace-engine/src/main/java/fraymus/workspace/SupportRepair060.java','Verified'),('witness','Measured repair witness','Failed gates and sampled translation reconstructed from original measurements.','docs/IDEAS_060_REVIEW.md','Reviewed and tested scope'),('goal','Java goal and exact skill','Fresh execution, paired evaluation, original report and promotion gates.','workspace-engine/src/main/java/fraymus/workspace/GoalRunner.java','Verified'),('report','Verified phase report','Actual tables, curves and replay checked against original records.','workspace-engine/src/main/java/fraymus/workspace/PayloadReport057.java','Verified'),('view','Integrated controls and chat','Visible example, actual local-model task, saved policy and original export.','workspace-desktop/renderer/construction051.js','Actual app verified'),('next','Experience retrieval and restraint experiments','New finite repairs with declared part/action costs and newly reserved conditions.','docs/EDITION_060_CONTRACT.md','Planned')]
data={'edition':60,'modules':[dict(id=i,name=n,summary=s,source=p,status=status,note=note) for i,n,s,p,status in modules],'screenshots':[{'path':'docs/readmes/060/'+name,'title':title+' · November 4, 2026 · synthetic practice world'} for name,title in shots],'evidence':[{'path':'docs/readmes/060/verification.json','title':'Source-qualified results'},{'path':'docs/readmes/060/original-evidence.json','title':'Original evidence and failures'}]};js(d/'system-map.json',data)
paths={x['path'] for x in json.loads((r/'docs/readmes/059/file-inventory.json').read_text(encoding='utf-8'))};new=subprocess.check_output(['git','diff','--name-only','--diff-filter=A','e029c4d','HEAD'],cwd=r,text=True).splitlines();paths.update(p for p in new if p.startswith(('workspace-engine/','workspace-desktop/')));paths.add('scripts/ProbeSuppliedEncoder060.java')
inventory=[]
for name in sorted(paths):
 b=(r/name).read_bytes()
 try:b=b.decode('utf-8').replace('\r\n','\n').encode();kind='utf8-lf'
 except UnicodeDecodeError:kind='binary'
 inventory.append({'path':name,'bytes':len(b),'hashKind':kind,'sha256':sha(b)})
js(d/'file-inventory.json',inventory);write(d/'FILE_TREE.md','# Edition 060 source tree\n\n```text\n'+'\n'.join(sorted(paths))+'\n```\n')
old=(r/'docs/readmes/058/index.html').read_text(encoding='utf-8');css=re.search(r'<style>(.*?)</style>',old,re.S)[1];script=old[old.index('<script>'):old.index('</script>',old.index('<script>'))+9]
body='<header><small>FRAYNIX AGENT WORKSPACE · EDITION 060 · NOVEMBER 4, 2026</small><h1>Independent bearings. Measured repairs.</h1><p>Independent poses. Same stock. Measured compact failures retained. New reserved loads and exact saved skills.</p><nav aria-label="Guide links"><a href="#walkthrough">Walkthrough</a><a href="#features">System map</a><a href="#captures">Actual screenshots</a><a href="#sources">Source inventory</a><a href="../../../README-060.md">Full README</a><a href="../059/index.html">Previous edition</a></nav></header><section id="walkthrough"><h2>Follow the actual task</h2><ol><li>Spatial → Gripper assembly → Independent bearings · compact stock.</li><li>Java measures the original layout, then independently positioned/rotated bearings only after measured design failure.</li><li>If compact fails, retain that outcome and use separate wide stock at its original 1.9 m spacing for the successful workflow.</li><li>Review the saved decision before execution; restart preserves it.</li><li>Fresh construction repeats design checks before unfamiliar payloads are evaluated.</li><li>Compare original and selected reserved outcomes in the verified report.</li><li>Export all originals; reuse the exact skill on new geometry with fresh evidence.</li></ol><p>Virtual rigid bodies; no material-strength or model-weight-training claim.</p><p><a href="verification.json">Validation and complete costs</a> · <a href="original-evidence.json">Original evidence</a> · <a href="../../EDITION_060_CONTRACT.md">Frozen contract</a></p></section><section id="results"><h2>Paired unfamiliar payload results</h2><p>Separate wide stock at the original 1.9 m span. The original layout passed; rotated alternatives were geometrically refused. Compact original and both admissible repairs failed the edge-force design case.</p><div class="results-table"><table id="results060"><thead><tr><th>Case</th><th>Original</th><th>Selected</th></tr></thead><tbody>'
for a,b in zip(baseline['results'],selected['results']):body+='<tr><td>'+html.escape(a['caseId'])+'</td><td>'+('Stable' if a['metrics']['stable'] else 'Unstable')+'</td><td>'+('Stable' if b['metrics']['stable'] else 'Unstable')+'</td></tr>'
body+='</tbody></table></div></section><section id="features"><h2>System map and next phases</h2><label for="feature-search">Find a component</label><input id="feature-search" type="search" placeholder="Try decision, Java or planned"><ul id="map"></ul></section><section id="captures"><h2>Actual application screenshots</h2><div id="gallery"></div></section><section id="sources"><h2>Source paths</h2><label for="file-search">Filter the inventory</label><input id="file-search" type="search" placeholder="Try SupportRepair060.java"><p id="file-count" aria-live="polite"></p><ul id="file-list"></ul><a href="FILE_TREE.md">Full source tree</a></section>'
body=body.replace('<ul id="map"></ul>','<ul id="map"></ul><section id="feature-detail" hidden aria-live="polite"><h3 id="feature-title"></h3><p id="feature-summary"></p><div id="feature-links"></div></section>')
script=script.replace("const node=element('li');\n    node.append", "const node=element('li');const select=element('button','Inspect connection');select.type='button';select.onclick=()=>{byId('feature-detail').hidden=false;byId('feature-title').textContent=item.name+' · '+item.status;byId('feature-summary').textContent=item.summary;byId('feature-links').replaceChildren(link(item.source,'Source or contract'),document.createTextNode(' · '),link(item.note,'Notes'));};node.append(select);\n    node.append")
css+=' #feature-detail{border:1px solid #69cdb1;padding:1rem;border-radius:12px} #map button{background:#153a37;color:#e0fff6;border:1px solid #64b99f;border-radius:6px;padding:.5rem .8rem;cursor:pointer}'
write(d/'index.html','<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Fraynix 060 · Measured redesign</title><style>'+css+'</style></head><body><main>'+body+'</main><script id="system-data" type="application/json">'+json.dumps(data)+'</script><script id="inventory-data" type="application/json">'+json.dumps(inventory)+'</script>'+script+'</body></html>\n')
nodes=[{'id':i,'type':'file','file':p,'x':(k%3)*410,'y':(k//3)*240,'width':380,'height':190} for k,(i,n,s,p,status) in enumerate(modules)];js(r/'docs/obsidian/independent-bearings.canvas',{'nodes':nodes,'edges':[{'id':'e'+str(k),'fromNode':nodes[k]['id'],'fromSide':'right','toNode':nodes[k+1]['id'],'toSide':'left'} for k in range(len(nodes)-1)]})
p=r/'README.md';content=p.read_text(encoding='utf-8');content=re.sub(r'> \*\*\[Edition 059.*','> **[Edition 060 · Independent bearings and measured repairs](README-060.md)** · [Offline guide](docs/readmes/060/index.html) · [Operation](docs/JAVA_CHAT_044.md) · [Edition history](docs/readmes/INDEX.md)',content,count=1);content=content.replace('Edition 059 reuses verified evidence after checking original bytes, compares asymmetric supports at the same span, and tests new payloads under a fixed decision. [Measured results and originals](docs/readmes/059/verification.json).','Edition 060 adds independent support positions and rotations, retains measured compact-stock failures, and verifies the original wider stock against new payloads. [Measured results and originals](docs/readmes/060/verification.json).');content=re.sub(r'Edition 05[89] is published to main[^\n]*\n\n','',content);write(p,content)
p=r/'docs/readmes/INDEX.md';content=p.read_text(encoding='utf-8');write(p,content.replace('\nLatest implementation','\n| [060](../../README-060.md) | 2026-11-04 | Independent bearings and measured repairs | [Viewer](060/index.html) · [tree](060/FILE_TREE.md) |\n\nLatest implementation').replace('is **059**','is **060**'))
p=r/'docs/JAVA_CHAT_044.md';write(p,p.read_text(encoding='utf-8')+'\n\n## Failure-driven payload redesign 060\n\nSpatial → Gripper assembly → Independent bearings · compact stock creates labelled stock. Chat can request redesign from measured failures and unfamiliar payloads. Java freezes a decision from design cases, executes freshly and compares original/selected reserved payloads before promotion. Saved procedures retain the exact policy. Report, replay and exports preserve failed and interrupted attempts. [Edition 060 walkthrough](../README-060.md).\n')
entry=f'\n\n## Edition 060 · Validated locally; publication audit next\n\nActual app source `{source}`. Frozen design-only selection, fresh execution and paired reserved payloads checked. {len(passed)} targeted Java cases across {len(classes)} classes,127 desktop checks and actual CPU/four-thread local-model chat/reuse with complete originals. See validation060 for source-qualified invocations and contrary outcomes. New README060, eight actual screenshots, offline guide and Obsidian map prepared. No material-strength or model-weight-training claim.\n\nActual main/edition060/readme-060 push and fresh fetched audit remain pending. Preserve normal045/qa046 installed runtimes/private data, dependency junction053 and immutable001–059. Next: new finite restraint/support options and evidence retrieval, with explicit costs and newly reserved conditions; compact repair remains unverified.\n'
for name in ['AGENTS.md','docs/PROJECT_MEMORY.md','docs/DEVELOPMENT_LOG.md']:
 p=r/name;s=p.read_text(encoding='utf-8');i=s.index('\n');write(p,s[:i]+entry+s[i:])
print(json.dumps({'sourceFiles':len(inventory),'java':len(passed),'classes':len(classes),'archives':len(archives),'timing':timing}))
