from pathlib import Path
import json
p=Path('docs/IDEAS_060_PROVENANCE.json');d=json.loads(p.read_text());d['javaProbe']={'source':'scripts/ProbeSuppliedEncoder060.java','command':'java scripts/ProbeSuppliedEncoder060.java','result':json.loads(Path('build/encoder060-java.json').read_text(encoding='utf-8-sig')),'developmentCorrection':'Initial standalone transcription reversed matrix row bit order; expected-witness assertion failed. Corrected to the supplied most-significant-bit row order.'};p.write_text(json.dumps(d,indent=2)+'\n')
p=Path('build/prepare-docs060.py');s=p.read_text(encoding='utf8');s=s.replace("paths.update(p for p in new if p.startswith(('workspace-engine/','workspace-desktop/')))","paths.update(p for p in new if p.startswith(('workspace-engine/','workspace-desktop/')));paths.add('scripts/ProbeSuppliedEncoder060.java')")
s=s.replace("shutil.copyfile(out/'construction060-live.json',d/'desktop-live.json')","shutil.copyfile(out/'construction060-live.json',d/'desktop-live.json');shutil.copyfile(r/'build/encoder060-java.json',d/'encoder-java-result.json');shutil.copyfile(r/'scripts/ProbeSuppliedEncoder060.java',d/'ProbeSuppliedEncoder060.java')")
s=s.replace("'Predeclared same-stock native rigid-body redesign", "'Predeclared independent-bearing same-stock native rigid-body redesign")
p.write_text(s,encoding='utf8')
