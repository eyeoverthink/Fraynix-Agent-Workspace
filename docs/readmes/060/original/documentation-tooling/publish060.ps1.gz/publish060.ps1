$ErrorActionPreference='Stop'
function Check([string]$Step) { if ($LASTEXITCODE -ne 0) { throw "$Step failed with exit $LASTEXITCODE" } }
$release=(git rev-parse HEAD).Trim()
python build/audit-publication060.py HEAD $release
Check 'Local release audit'
git tag -a readme-060 -m 'Edition 060: independent bearings, measured compact repair limits and new reserved payloads' $release
Check 'Create release tag'
git push --atomic origin HEAD:main HEAD:edition060 refs/tags/readme-060
Check 'Atomic release push'
git fetch https://github.com/eyeoverthink/Fraynix-Agent-Workspace.git main:refs/verify/edition060-main refs/tags/readme-060:refs/verify/edition060-tag
Check 'Fresh GitHub fetch'
python build/audit-publication060.py refs/verify/edition060-main $release
Check 'Fetched release audit'
python build/record-publication060.py
Check 'Publication receipt'
git add AGENTS.md README.md docs/PROJECT_MEMORY.md docs/DEVELOPMENT_LOG.md docs/PUBLICATION_060.json
Check 'Stage receipt'
git commit -m 'Record fetched edition 060 publication and continuity'
Check 'Receipt commit'
git push --atomic origin HEAD:main HEAD:edition060
Check 'Continuity push'
$final=(git rev-parse HEAD).Trim()
git fetch https://github.com/eyeoverthink/Fraynix-Agent-Workspace.git main:refs/verify/edition060-final
Check 'Final fresh GitHub fetch'
python build/audit-publication060.py refs/verify/edition060-final $final
Check 'Final fetched audit'
git status --short
Write-Output "PUBLICATION060_COMPLETE $final"
