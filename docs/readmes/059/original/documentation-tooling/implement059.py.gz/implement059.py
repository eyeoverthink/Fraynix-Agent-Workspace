from pathlib import Path
root=Path(__file__).resolve().parent.parent
j=root/'workspace-engine/src/main/java/fraymus/workspace'
def edit(name, changes):
 p=j/name;s=p.read_text(encoding='utf-8')
 for a,b in changes:
  assert a in s,(name,a[:120]);s=s.replace(a,b)
 p.write_text(s,encoding='utf-8')
edit('Construction051.java',[
 ('"centerX","centerZ","supportSpanM"','"centerX","centerZ","supportSpanM","supportOffsetM"'),
 ('SpatialScene.number(out,"centerX",-1,1);','if(input.has("supportOffsetM")){SpatialScene.number(input,"supportOffsetM",-.3,.3);out.put("supportOffsetM",input.get("supportOffsetM"));}SpatialScene.number(out,"centerX",-1,1);'),
 ('if(o.has("supportSpanM"))','if(o.has("supportSpanM")||o.has("supportOffsetM"))')])
edit('Construction054.java',[
 ('if(span<sw+.2||span+sw>beam.getJSONArray("size").getDouble(0)-.16+1e-9)', 'double offset=o.optDouble("supportOffsetM",0);if(span<sw+.2||span+sw+2*Math.abs(offset)>beam.getJSONArray("size").getDouble(0)-.16+1e-9)'),
 ('x-span/2,sh/2,z','x+offset-span/2,sh/2,z'),('x+span/2,sh/2,z','x+offset+span/2,sh/2,z')])
edit('Design058.java',[
 ('static String code(){','static String code(){return Code.VALUE;}\n    private static final class Code {static final String VALUE=computeCode();}\n    private static String computeCode(){'),
 ('Design058.class,PayloadSeries058.class','Design058.class,PayloadSeries058.class,Evidence059.class,SupportDesign059.class'),
 ('static JSONObject policy(boolean allow){return new JSONObject().put("version","failure-redesign-058-v1")','static JSONObject policy(boolean allow){return policy(allow,false);}\n    static JSONObject policy(boolean allow,boolean asymmetric){return new JSONObject().put("version",asymmetric?"asymmetric-payload-059-v1":"failure-redesign-058-v1")'),
 ('.put("protocol",protocol()).put("designProtocol",new PayloadSeries058("design").protocol()).put("reservedProtocol",new PayloadSeries058("reserved").protocol())','.put("protocol",asymmetric?SupportDesign059.protocol():protocol()).put("designProtocol",new PayloadSeries058("design",asymmetric).protocol()).put("reservedProtocol",new PayloadSeries058("reserved",asymmetric).protocol())'),
 ('String s=text.toLowerCase(Locale.ROOT);return s.contains','String s=text.toLowerCase(Locale.ROOT);return SupportDesign059.requested(text)||s.contains'),
 ('var baseline=store.run(id,"maximum-force");','boolean asymmetric=SupportDesign059.enabled(store.read(id));var baseline=store.run(id,"maximum-force");'),
 ('new PayloadSeries058(phase.equals("fresh-design")?"design":"reserved")','new PayloadSeries058(phase.equals("fresh-design")?"design":"reserved",asymmetric)'),
 ('var study=store.audit(id);\n        for(Object raw:study.getJSONArray("candidates"))','var study=store.audit(id);boolean asymmetric=SupportDesign059.enabled(study);\n        for(Object raw:study.getJSONArray("candidates"))'),
 ('new JSONObject().put("version","failure-redesign-058-v1").put("scope",protocol().getString("scope"))','new JSONObject().put("version",asymmetric?"asymmetric-payload-059-v1":"failure-redesign-058-v1").put("scope",(asymmetric?SupportDesign059.protocol():protocol()).getString("scope"))'),
 ('var groups=store.payloadOriginals058(id).getJSONArray("groups");Path dir=folder(root,actual);','var groups=store.payloadOriginals058(id).getJSONArray("groups");boolean asymmetric=SupportDesign059.enabled(store.read(id));Path dir=folder(root,actual);'),
 ('.put("edition",58)','.put("edition",asymmetric?59:58)')])
edit('PayloadSeries058.java',[
 ('private final String phase;','private final String phase;\n    private final boolean asymmetric;'),
 ('PayloadSeries058(String phase) {','PayloadSeries058(String phase){this(phase,false);}\n    PayloadSeries058(String phase,boolean asymmetric) {\n        this.asymmetric=asymmetric;'),
 ('if (phase.equals("design")) for','if(asymmetric)cases=SupportDesign059.protocol().getJSONArray(phase.equals("design")?"designCases":"reservedCases");\n        else if (phase.equals("design")) for'),
 ('"payload-series-058-"+phase','(asymmetric?"payload-series-059-":"payload-series-058-")+phase'),
 ('var d=Payload057.load(file(root,run));','return validate(Payload057.load(file(root,run)),run);\n    }\n    private JSONObject validate(JSONObject d,JSONObject run)throws Exception {'),
 ('JSONObject read(Path root,JSONObject run)throws Exception {\n        var d=load(root,run);','private String binding(JSONObject run,String operation){return operation+":"+WorldFrames.hash(run)+":"+Design058.code()+":"+WorldFrames.hash(protocol);}\n    JSONObject read(Path root,JSONObject run)throws Exception {return Evidence059.derive(file(root,run),binding(run,"read"),d->readData(validate(d,run),run));}\n    JSONObject readUncached(Path root,JSONObject run)throws Exception {return readData(load(root,run),run);}\n    private JSONObject readData(JSONObject d,JSONObject run)throws Exception {'),
 ('.put("scope",Design058.protocol().getString("scope"))','.put("scope",(asymmetric?SupportDesign059.protocol():Design058.protocol()).getString("scope"))'),
 ('JSONObject costs(Path root,JSONObject run)throws Exception {var d=load(root,run);','JSONObject costs(Path root,JSONObject run)throws Exception {return Evidence059.derive(file(root,run),binding(run,"costs"),d->costData(validate(d,run)));}\n    private JSONObject costData(JSONObject d){'),
 ('JSONObject originals(Path root,JSONObject run)throws Exception {\n        var d=load(root,run);','JSONObject originals(Path root,JSONObject run)throws Exception {return Evidence059.derive(file(root,run),binding(run,"originals"),d->originalData(validate(d,run),run));}\n    private JSONObject originalData(JSONObject d,JSONObject run)throws Exception {')])
edit('Counterfactual045.java',[
 ('Design058.class,PayloadSeries058.class','Design058.class,PayloadSeries058.class,SupportDesign059.class,Evidence059.class'),
 ('boolean payloadDesign,boolean allowPayloadRedesign)throws Exception{','boolean payloadDesign,boolean allowPayloadRedesign)throws Exception{return prepare(binding,base,directFirst,requiredLoad,allowRedesign,payloadDesign,allowPayloadRedesign,false);}\n    synchronized JSONObject prepare(JSONObject binding,JSONObject base,boolean directFirst,int requiredLoad,boolean allowRedesign,boolean payloadDesign,boolean allowPayloadRedesign,boolean asymmetric)throws Exception{\n        if(asymmetric&&!payloadDesign)throw new IllegalArgumentException("Asymmetric design requires payload redesign");'),
 ('proposals=Design058.proposals(source,base);','proposals=asymmetric?SupportDesign059.proposals(source,base):Design058.proposals(source,base);'),
 ('if(payloadDesign)s.put("payloadDesign058",Design058.policy(allowPayloadRedesign));','if(asymmetric)s.put("asymmetricSupports059",true);if(payloadDesign)s.put("payloadDesign058",Design058.policy(allowPayloadRedesign,asymmetric));'),
 ('Design058.policy(s.getJSONObject("payloadDesign058").getBoolean("allowRedesign"))','Design058.policy(s.getJSONObject("payloadDesign058").getBoolean("allowRedesign"),SupportDesign059.enabled(s))'),
 ('if(index>0&&s.has("directFirst055")&&','if(index>0&&!SupportDesign059.enabled(s)&&s.has("directFirst055")&&'),
 ('new PayloadSeries058("design")','new PayloadSeries058("design",SupportDesign059.enabled(s))'),
 ('synchronized JSONObject payloadSeries058(String id,String candidate)throws Exception {return','synchronized JSONObject payloadSeries058(String id,String candidate)throws Exception {var s=study(id);return')])
print('Native 059 edits saved')
