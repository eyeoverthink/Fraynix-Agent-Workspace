from pathlib import Path
r=Path(__file__).resolve().parent.parent;old=r.parent/'fraynix-workspace-edition058/build'
for name in ['prepare-docs058.py','check-docs058.cjs','freeze-docs058.py','preflight058.py','stage058.py','audit-publication058.py','record-publication058.py']:
 s=(old/name).read_text(encoding='utf-8').replace('058','059').replace('2026-11-03','2026-11-04').replace('November 3, 2026','November 4, 2026').replace('38854e9','d872b1f').replace('125 desktop','126 desktop').replace("'desktopUnitTests':125","'desktopUnitTests':126")
 if name=='prepare-docs058.py':
  s=s.replace('import json,','import statistics\nimport json,',1).replace("'4ab6a9c'","'111ddd0'")
  s=s.replace("archives=[];seen=set();roots=set()","archives=[];seen=set();roots=set();byraw={}")
  s=s.replace("seen.add(dest);b=p.read_bytes();z=gzip.compress(b,mtime=0);", "seen.add(dest);b=p.read_bytes();digest=sha(b)\n if digest in byraw:\n  byraw[digest].setdefault('aliases',[]).append({'source':str(p),'proposedPath':dest.relative_to(r).as_posix()});return\n z=gzip.compress(b,mtime=0);")
  s=s.replace("'format':'gzip of original bytes'})","'format':'gzip of original bytes'});byraw[digest]=archives[-1]")
  s=s.replace("'fresh-assembly.json']", "'fresh-assembly.json','performance.json','original-pin.json']").replace("'payload-059/'", "'payload-058/'")
  needle="first=results['wide'];groups="
  s=s.replace(needle,"performance=json.loads(next(p/'performance.json' for p in sorted(roots) if (p/'performance.json').exists()).read_text());js(d/'performance.json',performance);v['evidencePerformance']=performance;js(d/'verification.json',v);js(r/'docs/VALIDATION_059.json',v)\n"+needle)
  s=s.replace("The original 0.8 m spacing failed the edge-force design cases. The selected wider layout used a 1.395 m span, preserving the same parts and limits.","The original symmetric 0.8 m span passed 2/3 design cases; shifting the pair left passed 1/3; shifting right by 0.30 m passed 3/3. The span, parts, beam position and actuator limits stayed fixed.")
  s=s.replace("for name,g in goals.items():", "cold=statistics.median(x['uncachedMillis'] for x in performance['timings']);warm=statistics.median(x['cachedMillis'] for x in performance['timings']);table+=f'\\n**Evidence reconstruction benchmark:** median {cold:.3f} ms uncached versus {warm:.3f} ms cached, **{cold/warm:.2f}× faster** on this actual six-attempt record. Five alternating pairs after warmup; serialized output hashes match. Each lookup still reads and hashes the original bytes. This measures reconstruction, not full chat or simulation speed.\\n\\n'\nfor name,g in goals.items():")
  s=s.replace('66-payload-redesign','67-asymmetric-evidence').replace('65-dynamic-payloads','66-payload-redesign').replace('payload-redesign.canvas','asymmetric-evidence.canvas')
  s=s.replace("'workspace-engine/src/main/java/fraymus/workspace/Design059.java'","'workspace-engine/src/main/java/fraymus/workspace/SupportDesign059.java'").replace('PayloadSeries059.java','PayloadSeries058.java')
  s=s.replace("('series','Original native series','Design and reserved payload cases share actual integration and retain all attempts.','workspace-engine/src/main/java/fraymus/workspace/PayloadSeries058.java','Verified')", "('cache','Verified evidence reuse','Complete original-byte digests, bounded typed snapshots and unchanged verifiers.','workspace-engine/src/main/java/fraymus/workspace/Evidence059.java','Verified')")
  s=s.replace('richer finite repair choices','individually placed supports or braces').replace('Finite stock, asymmetric supports and newly reserved disturbances with full costs.','Independent support placements or braces, explicit material costs and new reserved conditions.')
  s=s.replace("docs/readmes/057/file-inventory.json","docs/readmes/058/file-inventory.json").replace("docs/readmes/057/index.html","docs/readmes/058/index.html").replace('../057/index.html','../058/index.html')
  s=s.replace('Measure. Redesign. Test the unfamiliar.','Faster evidence. Asymmetric supports.').replace('Same stock. Preserved failures. A decision fixed before reserved evaluation.','Same stock and span. New loads. Verified evidence reused after hashing original bytes.')
  s=s.replace('Failure → redesign → new payloads','Asymmetric supports · new payloads').replace('admits a wider layout only after measured design failure','admits left/right shifted layouts only after measured design failure')
  s=s.replace("r'> \\*\\*\\[Edition057.*'", "r'> \\*\\*\\[Edition 058.*'")
  s=s.replace("is **057**','is **059**", "is **058**','is **059**")
  s=s.replace('Measured failure, redesign and unfamiliar payloads','Faster evidence and asymmetric supports').replace('Measured redesign and unfamiliar payloads','Faster evidence and asymmetric supports')
 elif name=='check-docs058.cjs':
  s=s.replace('Measure. Redesign. Test the unfamiliar.','Faster evidence. Asymmetric supports.').replace("'Design059.java'","'Evidence059.java'")
 elif name=='freeze-docs058.py':
  s=s.replace('in [57,58]','in [58,59]').replace("'number':58","'number':59").replace("!=58","!=59").replace("m['latest']=58","m['latest']=59").replace('Measured failure, redesign and unfamiliar payloads','Faster evidence and asymmetric supports')
 elif name=='preflight058.py':
  s=s.replace("[:57]","[:58]").replace("==58","==59").replace("EntriesExact':57","EntriesExact':58")
 elif name=='stage058.py':
  s=s.replace("==58","==59").replace('66-payload-redesign','67-asymmetric-evidence').replace('payload-redesign.canvas','asymmetric-evidence.canvas')
 elif name=='record-publication058.py':
  s=s.replace("'edition':58","'edition':59").replace('across 58 editions','across 59 editions').replace('immutable001–059. Next unused edition059','immutable001–059. Next unused edition060')
  s=s.replace('Original wide 0.8 m spacing failed measured edge-force design cases; selected 1.395 m same-stock spacing passed.','Same-span symmetric and left-shifted layouts failed design cases; right-shifted supports passed.').replace('original layout passed two of four unfamiliar payloads, selected layout passed all four','see validation059 for paired unfamiliar payload results')
  s=s.replace('Next unused edition059','Next unused edition060').replace('frozen001–057','frozen001–058')
 (r/'build'/name.replace('058','059')).write_text(s,encoding='utf-8')
print('Prepared documentation, review, freeze and fetched-publication audit helpers; do not run preparation until actual workflow passes')
