from pathlib import Path
r=Path(__file__).resolve().parent.parent;p=r/'build/prepare-docs059.py';s=p.read_text(encoding='utf-8')
s=s.replace("'actualPhases':{k:live.get(k+'Source',source) for k in ['first','chat','reused']}","'rendererTextCorrection':'ada2b96','actualPhases':{k:live.get(k+'Source',source) for k in ['first','chat','reused']}")
s=s.replace("for base in sorted((r/'build').glob('ui059-*')):","for p in (r/'build').glob('ui059-*.json'):pack(p,d/'original/development-ui'/(p.name+'.gz'))\nfor base in sorted((r/'build').glob('ui059-*')):")
needle="write(d/'index.html','<!doctype html>"
assert needle in s
s=s.replace(needle,"body=body.replace('<section id=\"features\">',f'<section id=\"performance\"><h2>Measured evidence reconstruction</h2><p>Median {cold:.3f} ms uncached versus {warm:.3f} ms cached: {cold/warm:.2f}× faster for this native record. Five alternating pairs after warmup, identical serialized output hashes, complete original bytes hashed on every lookup. This is not a whole-chat speedup.</p><a href=\"performance.json\">Original timing measurements</a></section><section id=\"features\">')\n"+needle)
p.write_text(s,encoding='utf-8');print('Added measured performance to the offline guide and source-qualified the display-text correction')
