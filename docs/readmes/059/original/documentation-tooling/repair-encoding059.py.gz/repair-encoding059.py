from pathlib import Path
import subprocess
r=Path(__file__).resolve().parent.parent
p=r/'build/exports059.py';s=p.read_text(encoding='utf-8').replace('.read_text()', ".read_text(encoding='utf-8')");p.write_text(s,encoding='utf-8')
for name in ['workspace-engine/src/main/java/fraymus/workspace/GoalRunner.java','workspace-desktop/main.cjs','workspace-desktop/exports.cjs','workspace-desktop/test/pose-exports.test.cjs']:
 (r/name).write_bytes(subprocess.check_output(['git','show','111ddd0:'+name],cwd=r))
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
