from pathlib import Path
import json
r=Path(__file__).resolve().parent.parent;p=r/'workspace-desktop/renderer/construction051.js';s=p.read_text(encoding='utf-8');fixed=s.encode('cp1252').decode('utf-8');assert 'Â·' not in fixed and 'Asymmetric supports · new payloads' in fixed;p.write_text(fixed,encoding='utf-8')
p=r/'build/integrate059.py';s=p.read_text(encoding='utf-8').replace('s=p.read_text();',"s=p.read_text(encoding='utf-8');");p.write_text(s,encoding='utf-8')
p=r/'build/ui059-encoding.json';p.write_text(json.dumps({'scope':'Display text encoding correction only; native installed source remains61bfc95. Actual in-flight workflow source is recorded independently; final captures will show corrected text.','nativeSource':'61bfc9564c00b13c1c76087c3d666f5e6d258e87','initialCapture':'workspace-desktop/test-output/construction059-stock.png'},indent=2),encoding='utf-8')
print('Restored exact UTF-8 punctuation; native code and test conditions unchanged')
