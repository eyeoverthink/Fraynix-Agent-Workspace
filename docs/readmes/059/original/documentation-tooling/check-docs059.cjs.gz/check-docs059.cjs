const {chromium}=require('../workspace-desktop/node_modules/playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL,fileURLToPath}=require('node:url');
(async()=>{
  const root=path.resolve(__dirname,'..'),dest=path.join(root,'docs/readmes/059');
  const browser=await chromium.launch({channel:'msedge',headless:true});
  const checks=[],errors=[];
  try{
    for(const width of [1440,390]){
      const page=await browser.newPage({viewport:{width,height:1000}});
      page.on('pageerror',e=>errors.push(String(e)));
      await page.goto(pathToFileURL(path.join(dest,'index.html')).href);
      await page.waitForFunction(()=>document.images.length===7&&[...document.images].every(i=>i.complete&&i.naturalWidth>0));
      assert.equal(await page.locator('h1').textContent(),'Faster evidence. Asymmetric supports.');
      assert.equal(await page.locator('#map li').count(),6);assert.equal(await page.locator('#results059 tbody tr').count(),4);
      await page.locator('#feature-search').fill('planned');
      assert.equal(await page.locator('#map li').count(),1);assert((await page.locator('#map').innerText()).includes('Richer repair space'));
      await page.locator('#feature-search').fill('');
      await page.locator('#file-search').fill('Evidence059.java');
      assert.equal(await page.locator('#file-list li').count(),1);
      await page.locator('#file-search').fill('');
      const links=await page.locator('a').evaluateAll(a=>a.map(x=>x.href));
      for(const link of links){
        const u=new URL(link);
        if(u.protocol==='file:')assert(fs.existsSync(fileURLToPath(u)),`missing ${u}`);
      }
      await page.getByRole('link',{name:'Actual screenshots',exact:true}).click();
      assert.equal(new URL(page.url()).hash,'#captures');
      await page.evaluate(()=>window.scrollTo(0,0));
      const dims=await page.evaluate(()=>({client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth}));
      assert(dims.scroll<=dims.client+1,JSON.stringify(dims));
      await page.screenshot({path:path.join(dest,`guide-${width}.png`),fullPage:false});
      checks.push({width,images:7,moduleFilter:true,sourceFilter:true,links:links.length,noHorizontalOverflow:true});
      await page.close();
    }
    assert.deepEqual(errors,[]);
    fs.writeFileSync(path.join(dest,'documentation-browser.json'),JSON.stringify({passed:true,browser:'Installed Microsoft Edge via Playwright',url:'Offline file URL; no remote assets',checks,errors},null,2)+'\n');
    console.log(JSON.stringify({passed:true,checks}));
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
