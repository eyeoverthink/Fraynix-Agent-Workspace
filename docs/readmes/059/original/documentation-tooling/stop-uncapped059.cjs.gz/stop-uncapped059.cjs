const {chromium}=require('../workspace-desktop/node_modules/playwright');
const fs=require('node:fs'),cp=require('node:child_process');
(async()=>{
 const ports=JSON.parse(cp.execFileSync('powershell.exe',['-NoProfile','-Command','@(Get-NetTCPConnection -State Listen -OwningProcess 39524 | Select-Object -ExpandProperty LocalPort) | ConvertTo-Json -Compress'],{encoding:'utf8'}));
 for(const port of ports){try{const metadata=await(await fetch('http://127.0.0.1:'+port+'/json/version')).json();if(!metadata.Browser)continue;
  const browser=await chromium.connectOverCDP('http://127.0.0.1:'+port);const pages=browser.contexts().flatMap(c=>c.pages());const page=pages.find(p=>p.url().includes('/renderer/index.html'));if(!page)throw Error('Expected edition059 test page missing');
  await page.locator('#spatial-tab').click();await page.locator('#construction051').evaluate(e=>e.open=true);await page.locator('#c051-stop').click();
  fs.writeFileSync('build/ui059-memory-stop.json',JSON.stringify({date:new Date().toISOString(),project:'C:/Users/eyeka/AppData/Local/Temp/fraynix-construction059-u4qcvG',action:'Visible Stop in isolated test app; retain original attempts and restart full test with explicit768MB heap',observedJavaWorkingSetBytes:5907873792,nativeSource:'61bfc9564c00b13c1c76087c3d666f5e6d258e87'},null,2));await browser.close();console.log('Stopped isolated uncapped test through visible control');return;
 }catch(e){if(port===ports.at(-1))throw e;}}
 throw Error('Expected test browser unavailable');
})().catch(e=>{console.error(e);process.exitCode=1;});
