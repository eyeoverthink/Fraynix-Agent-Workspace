from pathlib import Path
import json
root=Path(__file__).resolve().parent.parent
j=root/'workspace-engine/src/main/java/fraymus/workspace'
def edit(path, changes):
 s=path.read_text(encoding='utf-8')
 for a,b in changes:
  assert a in s,(path.name,a[:100]);s=s.replace(a,b)
 path.write_text(s,encoding='utf-8')
edit(j/'Counterfactual045.java',[(
 'if(index>0&&!SupportDesign059.enabled(s)&&s.has("directFirst055")&&',
 'if(index>0&&SupportDesign059.enabled(s)&&s.getJSONArray("candidates").getJSONObject(0).optJSONObject("payloadDesign058",new JSONObject()).optBoolean("qualifies")){study(id).getJSONArray("candidates").getJSONObject(index).put("status","not-needed").put("reason","Original design passed; no measured failure admits asymmetric trials");save();continue;}if(index>0&&!SupportDesign059.enabled(s)&&s.has("directFirst055")&&')])
edit(j/'GoalRunner.java',[
 ('"payloadDesign058","allowPayloadRedesign058"','"payloadDesign058","asymmetricSupports059","allowPayloadRedesign058"'),
 ('"payloadTests057","payloadDesign058"))','"payloadTests057","payloadDesign058","asymmetricSupports059"))'),
 ('Design058.policy(p.getJSONObject("defaults").getBoolean("allowPayloadRedesign058"))','Design058.policy(p.getJSONObject("defaults").getBoolean("allowPayloadRedesign058"),p.getJSONObject("defaults").optBoolean("asymmetricSupports059"))'),
 ('if(input.has("allowPayloadRedesign058")&&','if(input.optBoolean("asymmetricSupports059")&&!input.optBoolean("payloadDesign058"))throw new IllegalArgumentException("Asymmetric supports require the payload design workflow");if(input.has("allowPayloadRedesign058")&&'),
 ('if(input.optBoolean("payloadDesign058"))g.put','if(input.optBoolean("asymmetricSupports059"))g.put("asymmetricSupports059",true);if(input.optBoolean("payloadDesign058"))g.put'),
 ('input.optBoolean("payloadDesign058"),input.optBoolean("allowPayloadRedesign058",true))','input.optBoolean("payloadDesign058"),input.optBoolean("allowPayloadRedesign058",true),input.optBoolean("asymmetricSupports059"))'),
 ('Design058.policy(g.getBoolean("allowPayloadRedesign058"))','Design058.policy(g.getBoolean("allowPayloadRedesign058"),g.optBoolean("asymmetricSupports059"))'),
 ('g.optBoolean("payloadDesign058")?Design058.protocol().getString("scope")','g.optBoolean("payloadDesign058")?(g.optBoolean("asymmetricSupports059")?SupportDesign059.protocol():Design058.protocol()).getString("scope")'),
 ('out.put("counterfactual045",WorldFrames.copy(c));}return out;', 'out.put("counterfactual045",WorldFrames.copy(c));}if(g.optBoolean("asymmetricSupports059"))out.put("evidence059",Evidence059.stats());return out;')])
edit(j/'Domain044.java',[(
 'if(Set.of("construction.start","procedure.run").contains(tool)&&Design058.requested(g.getString("goal")))',
 'if(Set.of("construction.start","procedure.run").contains(tool)&&SupportDesign059.requested(g.getString("goal")))a.put("asymmetricSupports059",true);\n  if(Set.of("construction.start","procedure.run").contains(tool)&&Design058.requested(g.getString("goal")))')])
edit(j/'Tools044.java',[(
 'List.of("payloadDesign058","allowPayloadRedesign058")','List.of("payloadDesign058","allowPayloadRedesign058","asymmetricSupports059")'),
 ('if(goal.contains("dynamic payloads")','if(!SupportDesign059.requested(goal))s.getJSONObject("properties").remove("asymmetricSupports059");if(goal.contains("dynamic payloads")')])
edit(j/'ChatChain052.java',[(
 'out.append("Measured-failure redesign: ")','out.append(child.optBoolean("asymmetricSupports059")?"Measured asymmetric support redesign: ":"Measured-failure redesign: ")')])
catalog=root/'workspace-engine/src/main/resources/tools-044.json'; data=json.loads(catalog.read_text())
for t in data:
 if t['function']['name']=='construction_start':
  t['function']['parameters']['properties']['asymmetricSupports059']={'type':'boolean'}
  t['function']['description']+=' Optional asymmetricSupports059 compares the same-span symmetric and left/right shifted support layouts against separate frozen design and new reserved payloads; no stock or threshold changes.'
catalog.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
edit(root/'workspace-desktop/policy.cjs',[(
 'payloadDesign058?,allowPayloadRedesign058?', 'payloadDesign058?,asymmetricSupports059?,allowPayloadRedesign058?'),
 ('"payloadDesign058": {"type": "boolean"}', '"payloadDesign058": {"type": "boolean"}, "asymmetricSupports059": {"type": "boolean"}')])
p=root/'workspace-desktop/renderer/construction051.js'
edit(p,[
 ('<button id="d058-example">','<button id="d059-example">Asymmetric supports · new payloads</button><button id="d058-example">'),
 ('Allow the two declared wider support layouts','Allow the declared alternative support layouts'),
 ('<p>Four design cases select the layout.', '<label class="design053-check"><input id="d059-enable" type="checkbox">Edition 059: compare asymmetric supports with new payloads</label><p>Edition 059 holds span and stock fixed, shifts supports left/right after measured failure, and uses three design cases plus four new reserved payloads. Original mode: four design cases select the layout.'),
 ("$('d058-example').onclick=", "$('d059-enable').onchange=()=>{if($('d059-enable').checked){$('d058-enable').checked=true;$('d058-enable').onchange();}};\n  $('d059-example').onclick=()=>this.action(async()=>{this.requireSaved();await this.geometryChoices();$('c054-preset').value='wide';this.geometryFields();$('c054-span').value=.8;$('d059-enable').checked=true;$('d059-enable').onchange();$('d058-allow').checked=true;$('d053-force').value=40;const w=await this.call('create',{title:'LABELLED059 · asymmetric supports and new payloads',...this.geometryInput()});this.id=w.id;await this.refresh();$('design053-options').open=true;});\n  $('d058-example').onclick="),
 ("title:'LABELLED058 · failure-driven payload redesign'", "title:'LABELLED058 · failure-driven payload redesign'"),
 ("applyTaskControls056(task,name){", "applyTaskControls056(task,name){$('d059-enable').checked=!!task.asymmetricSupports059;"),
 ("return{payloadDesign058:true,allowPayloadRedesign058:", "return{payloadDesign058:true,asymmetricSupports059:$('d059-enable').checked,allowPayloadRedesign058:"),
 ("${design&&$('p057-enable').checked?", "${design&&$('d058-enable').checked&&$('d059-enable').checked?'; compare asymmetric supports using the new edition 059 payload protocol':''}${design&&$('p057-enable').checked?"),
 ("${c.payloadDesign058?' · design cases '", "${c.hypothesis053.supportOffsetM!==undefined?' · offset '+c.hypothesis053.supportOffsetM.toFixed(3)+' m':''}${c.payloadDesign058?' · design cases '"),
 ("$('d058-example').disabled=this.busy||active;", "$('d058-example').disabled=this.busy||active;$('d059-example').disabled=this.busy||active;"),
 ("if(g?.design053)$('design053-options').open=true;", "if(g?.design053)$('design053-options').open=true;if(g?.evidence059)$('d053-status').textContent+=' · evidence reuse '+g.evidence059.hits+' verified reads';")])
# The historical example must explicitly choose its own suite.
s=p.read_text(encoding='utf-8');s=s.replace("$('d058-example').onclick=()=>this.action(async()=>{this.requireSaved();", "$('d058-example').onclick=()=>this.action(async()=>{$('d059-enable').checked=false;this.requireSaved();");p.write_text(s,encoding='utf-8')
print('Integrated 059 goals, exact skills, chat and visible controls')
