$ErrorActionPreference='Stop'
function Check([string]$Step) { if ($LASTEXITCODE -ne 0) { throw "$Step failed with exit $LASTEXITCODE" } }
$release=(git rev-parse HEAD).Trim()
python build/audit-publication059.py HEAD $release
Check 'Local release audit'
git tag -a readme-059 -m 'Edition 059: verified evidence reuse and asymmetric support payload evaluation' $release
Check 'Create release tag'
git push --atomic origin HEAD:main HEAD:edition059 refs/tags/readme-059
Check 'Atomic release push'
git fetch https://github.com/eyeoverthink/Fraynix-Agent-Workspace.git main:refs/verify/edition059-main refs/tags/readme-059:refs/verify/edition059-tag
Check 'Fresh GitHub fetch'
python build/audit-publication059.py refs/verify/edition059-main $release
Check 'Fetched release audit'
python build/record-publication059.py
Check 'Publication receipt'
git add AGENTS.md README.md docs/PROJECT_MEMORY.md docs/DEVELOPMENT_LOG.md docs/PUBLICATION_059.json
Check 'Stage receipt'
git commit -m 'Record fetched edition 059 publication and continuity'
Check 'Receipt commit'
git push --atomic origin HEAD:main HEAD:edition059
Check 'Continuity push'
$final=(git rev-parse HEAD).Trim()
git fetch https://github.com/eyeoverthink/Fraynix-Agent-Workspace.git main:refs/verify/edition059-final
Check 'Final fresh GitHub fetch'
python build/audit-publication059.py refs/verify/edition059-final $final
Check 'Final fetched audit'
git status --short
Write-Output "PUBLICATION059_COMPLETE $final"
