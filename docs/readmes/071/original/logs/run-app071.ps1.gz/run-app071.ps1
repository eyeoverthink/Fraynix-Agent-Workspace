$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$env:JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=4'
node workspace-desktop/test/uncertain071-integration.cjs *> build/app071.log
$code=$LASTEXITCODE
Get-Content build/app071.log -Tail 28
exit $code
