$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$env:JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=4'
if(!(Test-Path -LiteralPath 'build/legacy064-restore')){Copy-Item -LiteralPath '../fraynix-workspace-edition070/build/legacy064-restore' -Destination 'build/legacy064-restore' -Recurse}
$env:FRAYNIX064_NATIVE_RESUME=(Resolve-Path 'build/legacy064-restore').Path
New-Item -ItemType Directory -Path build/regression071 -Force | Out-Null
git rev-parse HEAD | Set-Content -Encoding utf8 build/regression071/source.txt
$regression071Args=@(':workspace-engine:test')
foreach($class in @('BrainPayload064Test','Agent042Test','BrainPersistenceTest','BrainServiceTest','ChatChain052Test','Domain044Test','StoppingContext063Test','Contact064Test','RecoveryCompatibility066Test','TemporalCompatibility067Test','CalibrationCompatibility068Test','LaterCompatibility069Test','AdaptiveCompatibility070Test','UncertainCompatibility071Test','CalibrationChat068Test')){$regression071Args+=@('--tests',"*$class")}
foreach($name in @('publishedCalibrationIsExactAndRecomputed','policyFitsIntervalsAndSharesDomainFence','utilityCountsMissesAndRefusalsWithoutInventingEndpoints','gateRequiresBothComparisonsAndRealTaskSuccess','planningTablesRetainEveryMetricAndLeaveOriginalsUntouched','freshPartitionsHaveNoOldNativeDefinitions')){$regression071Args+=@('--tests',"*Decision065Test.$name")}
foreach($name in @('initialPoliciesRetainOldChoicesAndRefusalDomain','inverseAndBoundsUseOnlyTheSelectedState','attemptedRecoveryPaysForFailuresAndEveryUsedOperation','qualificationRequiresObservationBenefitCompletionAndRecovery','freshTasksAndLosslessContextRetainSubgroupsAndNulls')){$regression071Args+=@('--tests',"*Recovery066Test.$name")}
foreach($name in @('temporalEvidenceHandlesDropoutButRefusesLostOrUnsafeSupport','contextIsLosslessAndFutureMotionCannotChangePlanning','initialChoicesAreCompatibleAndScreenIsProspective','costsIncludeThreeObservationsAndDeclinedScreens','qualificationKeepsAllComparisonsAndFailureLimits')){$regression071Args+=@('--tests',"*Temporal067Test.$name")}
foreach($name in @('lateInverseHonorsBudgetGuardAndNoActionWhenAlreadyFits','lateWindowChecksAllSamplesAndRejectsFuture','casesAreNewBalancedAndFrozenModelIsExact','feesIncludeFailedAttemptAndEveryLaterObservation','gateRejectsAddedCostsHarmsAndLateFailures')){$regression071Args+=@('--tests',"*Later069Test.$name")}
foreach($name in @('signedPhysicsStopsSticksAndRestartsDownhill','eventBoundaryIsAppliedExactlyOnce','scheduleHasNoFutureInputAndUsesOnlyPaidFirstState','selectedWindowsRejectFutureAndUnsafeEvidence','newCasesPreserveFirstChoicesAndBalanceTiming','skipPaysSchedulerButNoExtraSensingAndFailureStillCounts','qualificationRequiresSensingSavingsAndPreservesLateMisses')){$regression071Args+=@('--tests',"*Adaptive070Test.$name")}
$regression071Args+=@(':workspace-engine:installDist'  ,'verifySourceIsolation','--no-daemon','--max-workers=1','-I','build/validation071.init.gradle')
& ./gradlew.bat @regression071Args *> build/regression071/regression.log
$regression071Exit=$LASTEXITCODE
Copy-Item workspace-engine/build/test-results/test/TEST-*.xml build/regression071
Get-Content build/regression071/regression.log -Tail 25
exit $regression071Exit
