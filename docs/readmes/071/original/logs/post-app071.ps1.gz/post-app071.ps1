$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$env:JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=4'
$live071=Get-Content -Raw workspace-desktop/test-output/uncertain071-live.json | ConvertFrom-Json
if(!$live071.passed){throw 'Actual app validation must pass first'}
./gradlew.bat :factory-runtime:check --no-daemon --max-workers=1 -I build/validation071.init.gradle *> build/factory071.log
if($LASTEXITCODE -ne 0){Get-Content build/factory071.log -Tail 25;exit $LASTEXITCODE}
& "$env:JAVA_HOME/bin/javac.exe" -cp 'workspace-engine/build/install/workspace-engine/lib/*' -d build build/ExportUncertain071.java
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
@'
from pathlib import Path
import json
j=json.loads(Path('workspace-desktop/test-output/uncertain071-live.json').read_text(encoding='utf8'))
assert j['passed']
Path('build/app-job071.json').write_text(json.dumps(j['job']),encoding='utf8')
'@ | python -
& "$env:JAVA_HOME/bin/java.exe" -Xmx768m -cp 'build;workspace-engine/build/install/workspace-engine/lib/*' fraymus.workspace.ExportUncertain071 build/app-job071.json build/uncertain-data071.json *> build/export071.log
if($LASTEXITCODE -ne 0){Get-Content build/export071.log;exit $LASTEXITCODE}
python build/compare071.py
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
Get-Content build/factory071.log -Tail 18
Get-Content build/export071.log
