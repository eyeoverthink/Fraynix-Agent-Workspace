const {chromium}=require('../workspace-desktop/node_modules/playwright');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{pathToFileURL,fileURLToPath}=require('node:url');
(async()=>{
 const d=path.resolve('docs/readmes/074'),data=JSON.parse(fs.readFileSync(path.join(d,'comparison-data.json'),'utf8')),b=await chromium.launch({channel:'msedge',headless:true}),checks=[],errors=[];
 try{for(const width of [1440,390]){
  const p=await b.newPage({viewport:{width,height:1000}});p.on('pageerror',e=>errors.push(e.message));await p.goto(pathToFileURL(path.join(d,'index.html')).href);
  await p.waitForFunction(()=>document.images.length>=5&&[...document.images].every(i=>i.complete&&i.naturalWidth>0));assert.equal(await p.locator('#case option').count(),16);
  assert((await p.locator('#verdict').innerText()).includes(data.evaluation.qualified?'PASSED.':'NOT PASSED.'));
  const before=await p.locator('#totals').innerText();await p.locator('#bank-cost').check();assert((await p.locator('#totals').innerText()).includes(String(data.evaluation.methods.memory.ticks+data.bankConstruction.attributableTicks)));await p.locator('#bank-cost').uncheck();assert.equal(await p.locator('#totals').innerText(),before);
  for(let i=0;i<data.rows.length;i++){
   await p.locator('#case').selectOption(String(i));const row=data.rows[i];
   for(const method of ['search','simple','memory']){
    await p.locator('#method').selectOption(method);assert.equal(await p.locator('#run option').count(),row.replays[method].length);assert((await p.locator('#case-table').innerText()).includes(String(row.results[method].chargedTicks)));
    if(!row.replays[method].length){assert.equal(await p.locator('#scene').getAttribute('data-run-id'),null);assert(await p.locator('#play').isDisabled());continue;}
    for(let k=0;k<row.replays[method].length;k++){
     await p.locator('#run').selectOption(String(k));const run=row.replays[method][k],a=run.definition.objects.find(o=>o.sourceId==='A');
     for(const frame of [0,Math.floor(run.samples.length/2),run.samples.length-1]){
      await p.locator('#frame').fill(String(frame));await p.locator('#frame').dispatchEvent('input');const f=run.samples[frame];assert.equal(await p.locator('#scene').getAttribute('data-run-id'),run.id);assert.equal(+(await p.locator('#scene').getAttribute('data-tick')),f.tick);assert((await p.locator('#motion').textContent()).includes(f.bodies.find(b=>b.id===a.id).position[0].toFixed(4)+'m'));
     }
    }
   }
  }
  await p.locator('#case').selectOption('2');await p.locator('#method').selectOption('memory');await p.locator('#run').selectOption('2');await p.locator('#frame').fill('0');await p.locator('#frame').dispatchEvent('input');await p.locator('#play').click();await p.waitForFunction(()=>+document.querySelector('#frame').value>2);await p.locator('#play').click();const paused=await p.locator('#frame').inputValue();await p.waitForTimeout(120);assert.equal(await p.locator('#frame').inputValue(),paused);
  await p.locator('#map button').last().click();assert((await p.locator('#module-source').getAttribute('href')).includes('Inspect-Memory074.cjs'));await p.locator('#filter').fill('MemoryStudy074');assert.equal(await p.locator('#files li').count(),1);
  assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  for(const href of await p.locator('a[href]').evaluateAll(es=>es.map(e=>e.href))){if(href.startsWith('file:')){const u=new URL(href);u.hash='';assert(fs.existsSync(fileURLToPath(u)),href);}}
  await p.locator('#results').scrollIntoViewIfNeeded();await p.screenshot({path:path.join(d,'offline-'+width+'.png')});await p.locator('#replay').scrollIntoViewIfNeeded();await p.screenshot({path:path.join(d,'offline-replay-'+width+'.png')});checks.push({width,cases:16,allMethodsAndAttempts:true,initialMiddleFinalPoses:true,playPause:true,bankCostToggle:true,noActuationClearsSource:true,mapFilterLinksImages:true,noHorizontalOverflow:true});await p.close();
 }assert.deepEqual(errors,[]);console.log(JSON.stringify({passed:true,checks,errors},null,2));}finally{await b.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
