from pathlib import Path
import json,hashlib,gzip,subprocess,sys,html,re,shutil,base64,xml.etree.ElementTree as ET
r=Path.cwd();out=Path(sys.argv[1]);d=r/'docs/readmes/074';d.mkdir(parents=True,exist_ok=True)
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
result=load(out/'result.json');assert result['passed'];study=load(out/'study.json')
analysis=load(r/'build/native-analysis074.json');tamper=load(r/'build/inspector-probes074.json');assert analysis['passed'] and tamper['passed']
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();project=Path(result['project']);archives=[]
def pack(p,dest):
 b=p.read_bytes();z=gzip.compress(b,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archives.append(dict(path=dest.relative_to(r).as_posix(),bytes=len(z),sha256=sha(z),rawBytes=len(b),rawSha256=sha(b),source=str(p)))
for p in sorted(out.iterdir()):
 if p.is_file() and p.suffix in ['.json','.log','.txt']:pack(p,d/'original/app'/(p.name+'.gz'))
for p in sorted((project/'memory-074'/study['id']/'bank').glob('*.json')):pack(p,d/'original/bank'/(p.name+'.gz'))
for p in sorted((project/'memory-074'/result['recoveryId']).rglob('original.json')):pack(p,d/'original/recovery'/(p.parent.name+'.json.gz'))
for p in sorted((r/'build').glob('*074*.log')):pack(p,d/'original/logs'/(p.name+'.gz'))
for p in sorted((r/'build/development074-first').glob('*')):
 if p.is_file():pack(p,d/'original/development-first'/(p.name+'.gz'))
for folder in ['inspector074-first','app074-first']:
 for p in sorted((r/'build'/folder).glob('*')):
  if p.is_file():pack(p,d/'original'/folder/(p.name+'.gz'))
cases={};invocations=[]
for folder in ['policy074','regression074']:
 rows=[]
 for p in sorted((r/'build'/folder).glob('TEST-*.xml')):
  root=ET.parse(p).getroot()
  for c in root.findall('testcase'):
   key=c.attrib['classname']+'#'+c.attrib['name'];passed=all(c.find(n) is None for n in ['failure','error','skipped']);cases[key]=passed;rows.append(dict(case=key,passed=passed))
  pack(p,d/'original/java'/folder/(p.name+'.gz'))
  for loc in re.findall(r'MEMORY073_NATIVE_SOURCE ([^\r\n<]+)',p.read_text(encoding='utf8')):
   for name in ['original.json','reconstruction.json']:pack(Path(loc)/name,d/'original/java'/folder/(name+'.gz'))
 if rows:invocations.append(dict(name=folder,cases=rows))
assert cases and all(cases.values())
for name in ['native-analysis074.json','inspector-probes074.json','desktop074.json','source-isolation.json','final-app074.json']:
 p=r/'build'/name;assert p.exists();pack(p,d/'original/logs'/(name+'.gz'))
for name in ['document074.py','guide074.html']:pack(r/'build'/name,d/'original/documentation'/(name+'.gz'))
for p in sorted(out.glob('*.png')):shutil.copyfile(p,d/p.name)
for p in sorted((r/'build/final-captures074').glob('*.png')):shutil.copyfile(p,d/p.name)
data={k:study[k] for k in ['id','evaluation','bankConstruction','bankPreparationMillis','finalAuditMillis','protocol','code']};data['rows']=[]
for row in study['rows']:
 x=load(out/(row['id']+'-originals.json'));row=json.loads(json.dumps(row));row['replays']={m:[] for m in ['search','simple','memory']}
 for item in x['originals']:
  packed=item['run'];raw=gzip.decompress(base64.b64decode(packed['gzipBase64']));assert sha(raw)==packed['rawSha256'];run=json.loads(raw);a=item['attempt']
  method=next(m for m in row['results'] if any(t['id']==a['id'] for t in row['results'][m]['attempts']))
  row['replays'][method].append(dict(id=run['id'],stage=a['stage'],family=a['family'],status=a['status'],definition=run['definition'],samples=[dict(tick=f['tick'],bodies=[{k:b[k] for k in ['id','position','rotation']} for b in f['bodies']]) for f in run['samples']]))
 data['rows'].append(row)
write(d/'comparison-data.json',json.dumps(data,separators=(',',':'),ensure_ascii=False)+'\n')
paths={x['path'] for x in load(r/'docs/readmes/073/file-inventory.json')}
paths.update(x for x in subprocess.check_output(['git','diff','--name-only','--diff-filter=A','e87a038','HEAD'],text=True).splitlines() if x.startswith(('workspace-engine/','workspace-desktop/','scripts/','fraynix-modules/')))
inventory=[]
for name in sorted(paths):
 b=(r/name).read_bytes()
 try:b=b.decode('utf8').replace('\r\n','\n').encode();kind='utf8-lf'
 except UnicodeError:kind='binary'
 inventory.append(dict(path=name,bytes=len(b),hashKind=kind,sha256=sha(b)))
js(d/'file-inventory.json',inventory);write(d/'FILE_TREE.md','# Edition 074 complete source tree\n\n[Canonical bytes and hashes](file-inventory.json).\n\n```text\n'+'\n'.join(x['path'] for x in inventory)+'\n```\n')
v=dict(edition=74,source=source,contract='49c82da',schemaCorrection='e652acc',runtimeImplementation='d38238a',javaDistinct=len(cases),javaClasses=len({k.split('#')[0] for k in cases}),javaAllPassed=True,javaInvocations=invocations,desktop=load(r/'build/desktop074.json'),actualApp=result['checks'],actualAppSource=result['source'],finalApp=load(r/'build/final-app074.json'),audit=result['audit'],analysis=analysis,tamper=tamper,scope='Prospectively frozen new configurations in the existing deterministic native box/controller family; 12 supported cases and 4 unsupported controls. No new physical footage, independent solver, LLM inference/weight update or general intelligence test.')
js(d/'verification.json',v);js(d/'original-evidence.json',dict(format='Exact original bytes, including development failures, compressed with gzip. Synthetic isolated validation projects only. No personal database or model weights.',files=archives))
modules=[('bank','Owned experiment memory','Rehearsal073.java','Revalidates original owned goal, native evidence, report and committed lineage before freezing a bank.'),('policy','Frozen comparison policy','MemoryPolicy074.java','Same new source, targets, authority and budget; original search, first-success control and memory-first ordering.'),('study','Durable Java study','MemoryStudy074.java','Serial native attempts, reconstruction, explicit recovery, full costs, final verification and immutable exports.'),('verify','Original physics gates','WorldVerify.java','Original force, torque, protected-body and pose checks remain authoritative.'),('view','Integrated evidence view','memory074.js','Real progress, case costs, read-only native replay and exact file exports in the current app.'),('inspect','Portable trace arithmetic','Inspect-Memory074.cjs','Independently checks recorded source/target/plan identities, rankings, original motion and cost aggregation.')]
mapping=[dict(id=i,name=n,note='docs/obsidian/82-memory-usefulness.md',source=('workspace-desktop/renderer/' if p.endswith('.js') else 'scripts/' if p.endswith('.cjs') else 'workspace-engine/src/main/java/fraymus/workspace/')+p,description=t) for i,n,p,t in modules]
system=dict(modules=mapping,screenshots=[dict(path='docs/readmes/074/'+p.name,label=p.stem) for p in sorted(d.glob('*.png'))],evidence=[dict(path=q) for q in ['docs/readmes/074/verification.json','docs/readmes/074/original-evidence.json','docs/EDITION_074_CONTRACT.md']]);js(d/'system-map.json',system)
e=study['evaluation'];m=e['methods'];summary='\n'.join(f"| {name} | {m[name]['successes']}/12 | {m[name]['ticks']:,} | {m[name]['runs']} | {m[name]['wallMillis']/1000:.2f} | {m[name]['meanUtility']:.6f} |" for name in ['search','simple','memory'])
pairs='\n'.join(f"| Memory versus {name} | {x['saved']} | {x['harmed']} | {x['meanTickDelta']:.2f} | {x['meanUtilityDelta']:.6f} |" for name,x in e['memoryMinus'].items())
caseRows='\n'.join('| '+row['id']+' | '+' | '.join(('success' if row['results'][name]['success'] else row['results'][name]['status'])+' / '+str(row['results'][name]['chargedTicks']) for name in ['search','simple','memory'])+' |' for row in study['rows'])
qualified='passed' if e['qualified'] else 'did not pass'
readme=f'''# Fraynix Agent Workspace · Edition 074

**Measuring whether executable memories earn their cost on unfamiliar scenes.** November 5, 2026.

[Previous edition 073](README-073.md) · [Offline interactive guide](docs/readmes/074/index.html) · [Complete source tree](docs/readmes/074/FILE_TREE.md) · [Verification](docs/readmes/074/verification.json) · [Exact original evidence](docs/readmes/074/original-evidence.json) · [Edition history](docs/readmes/INDEX.md)

## What this edition answers

Edition 073 made experiment memories executable: retrieve a verified source, reconstruct it, change a component, compare alternatives and retain a verified result. The next question is practical: **does remembering an experiment help on a new task once retrieval, reconstruction and failures are counted?** Edition 074 adds a real comparison in the existing Java workspace and answers that narrower question with retained native motion, rather than a demonstration selected after success.

The qualification **{qualified}**. The table below includes all 12 prospectively specified supported tasks. Four unsupported controls are shown separately and never counted as successes. No controller or skill was automatically promoted, and the active saved worlds stayed unchanged.

![Actual comparison results](docs/readmes/074/final-comparison-results.png)

*Actual app, isolated labelled synthetic project, November 5, 2026. These are new configurations within the existing native box/controller family, not new camera measurements or a demonstration of general intelligence.*

## Results, including the simpler control

| Method | Verified success | Charged native ticks | Native attempts | Active wall seconds | Mean primary utility |
| --- | --- | --- | --- | --- | --- |
{summary}

| Paired comparison | Goals saved | Goals harmed | Mean extra ticks per task | Mean utility difference |
| --- | --- | --- | --- | --- |
{pairs}

In this study, the remembered family was the existing controller order on ten tasks and reversed order on two material tasks. The memory method used exactly the same combined new-task forecast/actual ticks as the simple method. Its 71,796 extra ticks were the twelve original-memory reconstructions. The bank influenced two choices but produced no additional successes or net task-work reduction here. Against exhaustive search, the apparent saving comes from stopping after the first verified forecast, which the simpler control already does.

A success needs an eligible forecast and a distinct fresh execution that passes the original native gates and prediction-versus-actual comparison. Fewer forecasts alone cannot earn success. The declared utility is `success - 0.2 × chargedTicks / 57600`; the weight is an accounting choice, not a learned probability or universal value function.

Bank preparation took {study['bankPreparationMillis']/1000:.2f} seconds; the final original-evidence audit took {study['finalAuditMillis']/1000:.2f} seconds. These shared overheads are separate from the per-method active-wall table. Retained bank creation accounts for at least {study['bankConstruction']['attributableTicks']:,} earlier native ticks. Including that lower bound, memory uses at least {analysis['summary']['memoryAmortizedTicksPerTaskLowerBound']:.2f} ticks per new task. Missing historical collection failures and historical wall time are **unknown**, not zero. The interactive guide can add this attributable earlier work to the chart.

All three methods reached the success ceiling on this supported set, so it cannot show a success-rate improvement. The measured cost difference remains informative; it does not show that memory would be useless on harder or different tasks.

Each task is one deterministic execution per method with counterbalanced method order. Native ticks are a simulation-work proxy, not a claim of proportional CPU savings. Wall time includes lookup, reconstruction, planning, native execution, persistence and per-task checking; it is machine elapsed time, not a clean CPU microbenchmark. No confidence interval or population-wide performance claim is inferred from these 12 designed cases. All methods use the same simulator; independent trace arithmetic is not a second physics solver.

## The three methods

1. **Search** uses the existing controller-order, reversed-target-order and half-force alternatives. It evaluates admissible distinct candidates and retains original native-tick, effort and ordinal ranking.
2. **Simple** tries the same candidates in the existing order and stops at the first verified forecast. It still runs and verifies a distinct fresh actual execution.
3. **Memory** selects the nearest compatible episode from a frozen bank, reconstructs its original at-rest run, and tries its remembered successful candidate family first on the new scene. It uses bounded fallback if needed and the same fresh-actual checks. A remembered success never certifies a changed task.

The bank contains the original verified source and four original edition 073 acceptance children. It is frozen before the new study. New test results are not added to retrieval, and no evaluation case becomes training data during comparison. Retrieval uses an explicit normalized distance over role-matched mass, friction, dimensions and target travel length, with penalties for unmatched context roles and stable ID ties. It is local Java arithmetic, not semantic neural recall.

All arms share a 57,600-native-tick and 600-second active-wall budget. Each native attempt retains its original 14,400-tick and 90-second bounds. Admission reserves a full worst-case attempt plus a full fresh-actual allowance. Reconstruction and unsuccessful alternatives consume the same total budget; unknown interrupted native tails are conservatively charged their full maximum. Observed ticks remain separately visible. Recovery is explicit and limited to two resumes.

## New scenes and preserved outcomes

The source-controlled protocol declares 12 supported changes: two footprints, two rotations, two route changes, two obstacle contexts, two payloads and two material settings. Four invalid or unsupported cases test excess mass, oversize geometry, missing floor and invalid height. The original physics solver, controller classes and verifier identity are unchanged.

| Case | Search outcome / ticks | Simple outcome / ticks | Memory outcome / ticks |
| --- | --- | --- | --- |
{caseRows}

The full [frozen protocol](workspace-engine/src/main/resources/memory074-protocol.json) contains exact component values, source poses, target poses and force/torque ceilings. The [prospective contract](docs/EDITION_074_CONTRACT.md) was committed as `49c82da`; the schema-only original-quaternion correction `e652acc` also preceded implementation and outcomes. Runtime implementation `d38238a` preceded the full study. Cases, thresholds, ranking and controller behavior were not retuned after seeing results.

![Actual case-level costs](docs/readmes/074/final-payload-costs.png)

*Actual per-case evidence. A refused or failed attempt remains visible and charged; no missing result becomes success.*

## Try the comparison and inspect the evidence

Open **Spatial → One evolving world → Does memory help? · new-scene comparison**. Select eligible verified memories from the existing experiment-memory workflow. Press **Freeze bank & run comparison**. The Java runner validates the original owned evidence before beginning. A foreign ID or a user-supplied success label cannot create an eligible memory.

The current progress, method summary and per-case table update in the same application. Choose a case and method to inspect its selected memory, candidate order, reconstruction status, all attempts and observed versus charged work. Use **Load recorded motion** to replay an original native attempt. Change the run selector and frame slider to inspect failures as well as successes. The oriented boxes use original quaternions and metre coordinates; the replay is read-only.

![Actual oriented native replay](docs/readmes/074/final-yaw-replay.png)

**Export case & original traces** writes the selected case, frozen study/source identities, method outcomes and original native traces through the existing file export system. Each retained compressed trace carries original byte length and SHA-256. The portable [inspector](scripts/Inspect-Memory074.cjs) recomputes source/target authority, retrieval ranking, motion verification, candidate choice, fresh-actual comparison and all cost totals. Eight deliberately altered exports are rejected, including hidden reconstruction costs, changed payload/target, false success and substituting a forecast for actual execution.

**Stop** retains unfinished work without qualifying it. Closing the app and Java preserves the study; after reopening, **Resume** explicitly continues from checked state. A separate post-study lifecycle test interrupted an actually running native attempt, restarted Java, retained and charged that attempt, resumed, then stopped without producing a completed qualification. The primary comparison was already complete before that probe and its outcomes were not mixed into the primary score.

The original edition 073 synthetic project was copied into a distinct project and checked byte-for-byte before launch and after validation. Existing user worlds, normal review installations and model services were preserved. Starting this comparison does not modify the active world's revision, save new memories or launch an unbounded background search.

## Architecture and validation

```mermaid
flowchart LR
  A[Owned verified episodes] --> B[Frozen bank]
  B --> C[Java study and shared budgets]
  D[New source and target protocol] --> C
  C --> E[Search / simple / memory]
  E --> F[Original native motion and checks]
  F --> G[Distinct actual execution]
  G --> H[Full costs and paired outcomes]
  H --> I[Integrated replay and exact exports]
```

[MemoryPolicy074](workspace-engine/src/main/java/fraymus/workspace/MemoryPolicy074.java) defines the comparison and preserves the original candidate plans. [MemoryStudy074](workspace-engine/src/main/java/fraymus/workspace/MemoryStudy074.java) owns persistence, bounded native attempts, recovery and audit. [GoalRunner](workspace-engine/src/main/java/fraymus/workspace/GoalRunner.java) validates owned episode bundles. [The panel](workspace-desktop/renderer/memory074.js) displays evidence and dispatches typed Java operations. This edition adds no model, external agent framework or library. Existing Bullet/Minie, Electron/Chromium and JSON dependencies remain; it does not claim all inherited dependencies were rewritten.

Validation covers {len(cases)} distinct targeted Java tests across {len({k.split('#')[0] for k in cases})} classes, the desktop suite, the complete actual-app 48-cell study, original-evidence audit, exported-trace inspection and eight altered-evidence probes. It includes actual file export, cold restart, interruption/resume, Stop, unchanged worlds and 1600/1100 app layouts. The offline companion is checked at 1440/390 widths with real interactions and image loading. These are scoped regressions, not a fresh rerun of every expensive historical study. Original XML, outputs, traces, screenshots and development failures are archived with hashes.

The first focused test expected the missing-floor rejection one call too late. The test now checks the whole admission path; its original failure is retained. No scene or admissibility gate was changed. A first regression launcher incorrectly split a test-name argument; Gradle stopped before executing tests. Its command/output are retained and the corrected launcher runs the same intended classes. Visual inspection also found that the app correctly blocked an inline style under its existing content-security policy. The layout was moved into the existing stylesheet and the final app check asserts that its computed styles actually apply. The earlier image remains archived. Presentation-only follow-up keeps the saved comparison label current, separates table cells and clears a replay when its selected case or method changes. A separate actual-app check confirms that the finished evaluation and active worlds remain unchanged. Evidence-inspector or lifecycle-harness corrections, if needed, are retained separately from the frozen runtime and primary results.

No new LLM inference was required or tested in this edition. A model selected in a screenshot is not an inference result. Existing Java chat and skills remain; this comparison uses the integrated typed study controls. It neither updates LLM weights nor establishes consciousness, unrestricted autonomy or real-world accuracy.

## What the result suggests next

The experiment distinguishes remembering from improving. A costly reconstruction can be correct and still be a poor choice for a task that the simple method already solves. The next edition should use these measured costs and failures to write a new prospective contract, rather than adjusting this test until memory wins.

- Test a source-bound reconstruction certificate cache, invalidated by native identity, original bytes and restore-contract changes. Count verification/cache costs and retain a cold-start control.
- Build a bank whose procedures exhibit measured task-specific differences, rather than assuming an alternate order is useful. Keep training and evaluation separate, freeze the retrieval policy, then evaluate new configurations without selecting results to favor memory.
- Add harder, prospectively chosen tasks where control order matters. Investigate failures using retained contact, velocity, rotation and force traces; implement a bounded repair only after specifying its acceptance cases and rollback.
- Keep exhaustive search and first-success control, charge all failures, separate earlier training/collection work and require useful held-out outcomes before promotion.
- Broaden moving-state restore and typed skill-graph reuse only with complete state contracts and dedicated compatibility tests.

The vision remains a local agent whose environment, actions, memories and evaluations are part of one system. This edition adds the measurement needed to decide which forms of memory actually deserve to guide it.
'''
write(r/'README-074.md',readme)
write(r/'docs/obsidian/82-memory-usefulness.md',f'''# Measured executable memory usefulness

Edition 074 compares frozen-memory-first, exhaustive search and first verified success on twelve new supported native scenes plus four unsupported controls. Qualification {qualified}; no automatic promotion. All reconstruction/failure/actual costs count. Earlier bank creation remains a separate lower bound.

- [[README-074]]
- [[docs/EDITION_074_CONTRACT]]
- [[docs/obsidian/81-experiment-memory]]
- [[workspace-engine/src/main/java/fraymus/workspace/MemoryStudy074.java]]

Next: investigate source-qualified rebuild reuse and genuinely discriminating procedures, freeze a new policy/test before outcomes, retain the simple comparator and rollback. No new physical accuracy or LLM-weight learning claim.
''')
nodes=[dict(id=x['id'],type='file',file=x['source'],x=i%3*420,y=i//3*240,width=390,height=200) for i,x in enumerate(mapping)];js(r/'docs/obsidian/memory-usefulness.canvas',dict(nodes=nodes,edges=[dict(id='e'+str(i),fromNode=nodes[i]['id'],fromSide='right',toNode=nodes[i+1]['id'],toSide='left') for i in range(len(nodes)-1)]))
page=(r/'build/guide074.html').read_text(encoding='utf8')
for key,value in [('DATA',data),('MAP',system),('INVENTORY',inventory)]:page=page.replace('__'+key+'__',json.dumps(value,separators=(',',':'),ensure_ascii=False).replace('</','<\\/'))
page=page.replace('__SHOTS__',''.join('<figure><img src="'+p.name+'" alt="Actual app '+html.escape(p.stem)+'"><figcaption>'+html.escape(p.stem)+' · isolated labelled synthetic app · November 5, 2026</figcaption></figure>' for p in sorted(d.glob('*.png'))));write(d/'index.html',page)
print(json.dumps(dict(java=len(cases),classes=v['javaClasses'],sourceFiles=len(inventory),originals=len(archives),source=source)))
