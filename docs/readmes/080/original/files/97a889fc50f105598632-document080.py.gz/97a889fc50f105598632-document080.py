from pathlib import Path
import json, hashlib, gzip, subprocess, html, re, shutil, base64, xml.etree.ElementTree as ET
r=Path.cwd(); d=r/'docs/readmes/080'; out=r/'build/ui080-primary'; d.mkdir(parents=True,exist_ok=True)
def write(p,s): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s,encoding='utf8',newline='\n')
def js(p,v): write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b): return hashlib.sha256(b).hexdigest()
record=load(out/'result.json'); analysis=load(r/'build/analysis080.json'); probes=load(r/'build/probes080.json'); life=load(r/'build/ui080-lifecycle/result.json'); faults=load(r/'build/ui080-faults/result.json')
assert all(x['passed'] for x in [record,analysis,probes,life,faults])
e=analysis['summary']; source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(); archives=[]; archived=set()
def pack(p,dest):
 logical=dest.relative_to(r).as_posix(); dest=d/'original/files'/(sha(logical.encode())[:20]+'-'+dest.name[-42:])
 if dest in archived:return
 archived.add(dest);b=p.read_bytes();z=gzip.compress(b,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z)
 archives.append(dict(path=dest.relative_to(r).as_posix(),bytes=len(z),sha256=sha(z),rawBytes=len(b),rawSha256=sha(b),source=str(p),logicalPath=logical))
for folder in sorted((r/'build').glob('ui080-*')):
 if not folder.is_dir():continue
 for p in sorted(folder.iterdir()):
  if p.is_file() and p.suffix in ['.json','.log','.txt','.png']:pack(p,d/'original'/folder.name/(p.name+'.gz'))
 checkpoint=folder/('result.json' if (folder/'result.json').exists() else 'checkpoint.json')
 if checkpoint.exists() and folder.name!='ui080-faults':
  project=Path(load(checkpoint)['project'])
  for dirname in ['world-procedures-079','persistent-worlds','goals','agency-043','creation-044','artifacts','receipts','runtime-042']:
   for p in sorted((project/dirname).rglob('*')):
    if p.is_file() and p.suffix in ['.json','.jsonl','.log','.html','.js','.css']:pack(p,d/'original'/folder.name/'project'/p.relative_to(project).with_suffix(p.suffix+'.gz'))
  for name in ['engine.log','events.jsonl','test-desktop-process.log']:
   p=project/name
   if p.exists():pack(p,d/'original'/folder.name/'project'/(name+'.gz'))
for pattern in ['*080*.log','*080-stack*.txt']:
 for p in sorted((r/'build').glob(pattern)):pack(p,d/'original/logs'/(p.name+'.gz'))
cases={}; invocations=[]
for folder in ['unit080-first','regression080','final-native080','reuse080-fix','final-report080']:
 rows=[]
 for p in sorted((r/'build'/folder).glob('TEST-*.xml')):
  root=ET.parse(p).getroot()
  for c in root.findall('testcase'):
   key=c.attrib['classname']+'#'+c.attrib['name']; passed=all(c.find(n) is None for n in ['failure','error','skipped']);cases[key]=passed;rows.append(dict(case=key,passed=passed))
  pack(p,d/'original/java'/folder/(p.name+'.gz'))
  for loc in re.findall(r'(?:WORLD079_NATIVE|REBUILD079_NATIVE) ([^\r\n<]+)',p.read_text(encoding='utf8')):
   for f in Path(loc).rglob('*.json'):pack(f,d/'original/java'/folder/Path(loc).name/f.relative_to(loc).with_suffix('.json.gz'))
 if rows:invocations.append(dict(name=folder,source={'unit080-first':'Initial implementation working tree before compact-view/report and saved-skill corrections; repeated by later checks','regression080':'88861b3','final-native080':'5ee78b6','reuse080-fix':'fd2dfa4','final-report080':'4ec4d26'}[folder],cases=rows))
assert cases and all(cases.values())
for name in ['analysis080.json','probes080.json','desktop080.json','unchanged-native080.json','regress080.ps1','document080.py','guide080.html','README-080-template.md','report-wording-only080.json','ui-label080.py']:
 pack(r/'build'/name,d/'original/validation'/(name+'.gz'))
for folder in [out,r/'build/ui080-lifecycle',r/'build/ui080-final-smoke']:
 for p in folder.glob('*.png'):
  if p.name!='failure.png':shutil.copyfile(p,d/p.name)
protocol=load(r/'workspace-engine/src/main/resources/procedures080-protocol.json'); specs={s['id']:s for s in protocol['training']+protocol['calibration']+protocol['cases']}
data=dict(evaluation=e,learningTicks=sum(x['job']['arm']['chargedTicks'] for x in record['training'])+sum(x['job']['arm']['chargedTicks'] for row in record['calibration'] for x in row['results'].values()),bank=record['frozenBank'],model=record['model'],rows=[])
inputs=[dict(id=x['id'],split='training',results={'simple':x}) for x in record['training']]+[dict(**row,split='calibration') for row in record['calibration']]+[row for row in record['rows'] if row['split']=='unseen']
for row in inputs:
 entry=dict(id=row['id'],split=row['split'],spec=specs[row['id']],results={},replays={})
 for method,item in row['results'].items():
  x=load(out/item['originalFile']);a=item['job']['arm'];entry['results'][method]=dict(status=item['status'],reason=item['reason'],decision=item['job']['decision'],lookupMillis=item['job']['lookupMillis'],callerMillis=item['wallMillis'],cost080=item['goal']['taskCost080']);entry['replays'][method]=[]
  for packet in x['originals']:
   raw=gzip.decompress(base64.b64decode(packet['gzipBase64']));assert sha(raw)==packet['rawSha256'];run=json.loads(raw);attempt=next(t for t in a['attempts'] if t['id']==run['id']);n=len(run['samples']);indices=sorted(set(round(i*(n-1)/min(239,max(1,n-1))) for i in range(min(240,n))))
   frames=[dict(tick=run['samples'][i]['tick'],originalSampleIndex=i,bodies=[{k:b[k] for k in ['id','position','rotation']} for b in run['samples'][i]['bodies']]) for i in indices]
   entry['replays'][method].append(dict(id=run['id'],stage=attempt['stage'],family=attempt['family'],status=attempt['status'],definition=run['definition'],originalSampleCount=n,samples=frames,targets=run['plan']['intent']['targets']))
 data['rows'].append(entry)
write(d/'comparison-data.json',json.dumps(data,separators=(',',':'))+'\n')
paths={x['path'] for x in load(r/'docs/readmes/079/file-inventory.json')};paths.update(x for x in subprocess.check_output(['git','diff','--name-only','--diff-filter=A','0978fb6','HEAD'],text=True).splitlines() if x.startswith(('workspace-engine/','workspace-desktop/','scripts/','fraynix-modules/')));inventory=[]
for name in sorted(paths):
 b=(r/name).read_bytes()
 try:b=b.decode('utf8').replace('\r\n','\n').encode();kind='utf8-lf'
 except UnicodeError:kind='binary'
 inventory.append(dict(path=name,bytes=len(b),hashKind=kind,sha256=sha(b)))
js(d/'file-inventory.json',inventory);write(d/'FILE_TREE.md','# Edition 080 complete source tree\n\n[Canonical bytes and hashes](file-inventory.json).\n\n```text\n'+'\n'.join(x['path'] for x in inventory)+'\n```\n')
v=dict(edition=80,source=source,contract='2789bed',primarySource=record['source'],finalRuntimeSource=load(r/'build/ui080-final-smoke/result.json')['source'],finalRuntimeSmoke=load(r/'build/ui080-final-smoke/result.json')['checks'],reportWordingOnly=load(r/'build/report-wording-only080.json'),javaDistinct=len(cases),javaClasses=len({k.split('#')[0] for k in cases}),javaAllPassed=True,javaInvocations=invocations,desktop=load(r/'build/desktop080.json'),actualApp=record['checks'],lifecycle=life['checks'],lifecycleSource=life['source'],faults=faults['checks'],faultsSource=faults['source'],correctedSmoke=load(r/'build/ui080-smoke2/result.json')['checks'],firstSmokeFailure=load(r/'build/ui080-smoke/checkpoint.json').get('error'),primaryNativeAttempts=sum(len(i['job']['arm']['attempts']) for row in inputs for i in row['results'].values()),analysis=analysis,tamper=probes,sourceIsolation=load(r/'build/unchanged-native080.json'),scope='One serial counterbalanced labelled native-box study. Original physics and verifiers remain authoritative; independent original-byte arithmetic and cost provenance inspection is not an independent physics solver. Successful acceptance uses deterministic Java planning; the preserved failed first smoke entered local-model repair. No new physical accuracy or LLM weight-training claim.')
js(d/'verification.json',v)
modules=[('timing','Complete-task cost','TaskCost080.java','Owned Java measurement, matching and conservative empirical estimates.'),('runner','Verified procedure','WorldProcedure079.java','Original native forecasts, actual stages, evidence, calibration provenance and reports.'),('goal','Durable goal and skill','GoalRunner.java','Lifecycle clock, actual host checks, commit and requested retention.'),('commit','Persistent world','WorldLedger.java','Unchanged original authority and atomic world commit.'),('inspect','Independent reader','Inspect-Procedures080.cjs','Reconstruct original motion, paired source hashes and estimation arithmetic.')]
mapping=[dict(id=i,name=n,note='docs/obsidian/88-complete-task-costs.md',source=('scripts/' if p.endswith('.cjs') else 'workspace-engine/src/main/java/fraymus/workspace/')+p,description=t) for i,n,p,t in modules];js(d/'system-map.json',dict(modules=mapping,screenshots=[dict(path='docs/readmes/080/'+p.name,label=p.stem) for p in sorted(d.glob('*.png'))]))
m=e['methods'];relation=f"Supported estimates on {e['coveredCases']}/8 tasks. Mean absolute saving error {e['maeMillis']/1000:.3f}s versus {e['oldMaeMillis']/1000:.3f}s for the earlier point estimate on the same cases. Calibrated control selected memory on {m['calibrated']['lookups']}/8 tasks. These are frozen held-out outcomes; the policy was not retuned after observing them." if e['coveredCases'] else 'No supported estimates in this batch; estimation improvement is not established.'
fmt=lambda x:'PASSED' if x else 'NOT PASSED'
values=dict(ESTIMATION=fmt(e['estimationImproved']),EFFICIENCY=fmt(e['efficient']),BATCH=fmt(e['firstBatchEfficient']),RELATION=relation,JAVA=str(v['javaDistinct']),CLASSES=str(v['javaClasses']),DESKTOP=str(v['desktop']['tests']),PROBES=str(len(probes['probes'])),TRAIN=f"{e['trainingMillis']/1000:.2f}",FIT=f"{e['calibrationMillis']/1000:.2f}",TRAIN_TICKS=f"{sum(x['job']['arm']['chargedTicks'] for x in record['training']):,}",FIT_TICKS=f"{sum(x['job']['arm']['chargedTicks'] for row in record['calibration'] for x in row['results'].values()):,}",LIFECYCLE=' '.join(life['checks'])+'.',FAULTS=' '.join(faults['checks'])+'.',RESULTS='\n'.join(f"| {k} | {x['successes']}/8 | {x['completeMillis']/1000:.2f} | {x['callerMillis']/1000:.2f} | {x['ticks']:,} | {x['stages']} | {x['lookups']}/8 |" for k,x in m.items()),ESTIMATES='\n'.join('| '+x['id']+' | '+(f"{x['predictedSavingMillis']/1000:.3f}" if x['available'] else 'Unavailable')+f" | {x['observedSavingMillis']/1000:.3f} | "+(str(x['covered']) if x['available'] else 'Not evaluated')+' | '+str(x['chosen'])+' |' for x in e['estimates']))
s=(r/'build/README-080-template.md').read_text(encoding='utf8').replace('(workspace-desktop/persistent-world-panel.js)','(workspace-desktop/renderer/persistent-world-panel.js)')
for k,val in values.items():s=s.replace('__'+k+'__',val)
assert not re.search(r'__[A-Z_]+__',s);write(r/'README-080.md',s)
shots=''.join(f'<figure><a href="{html.escape(p.name)}"><img src="{html.escape(p.name)}" alt="Actual edition080 {html.escape(p.stem)}"></a><figcaption>{html.escape(p.stem)} · actual isolated app capture, November 6, 2026.</figcaption></figure>' for p in sorted(d.glob('*.png')))
s=(r/'build/guide080.html').read_text(encoding='utf8').replace('__SHOTS__',shots)
for key,obj in [('DATA',data),('MAP',mapping),('INVENTORY',inventory)]:s=s.replace('__'+key+'__',json.dumps(obj,separators=(',',':')).replace('<','\\u003c'))
write(d/'index.html',s)
write(r/'docs/obsidian/88-complete-task-costs.md',f'# Complete task costs · edition080\n\n[[README-080|Edition080]] · [[README-079|Previous079]] · [[docs/readmes/080/index.html|Offline evidence]] · [[docs/obsidian/complete-task-costs.canvas|System map]]\n\n{relation}\n\nJava admission → lookup → forecast → actual motion → original verification → host report checks → commit → retention → timing record. Explicit matched completed control pairs calibrate cost. Warm/cold proof state, runtime and saving workloads stay separate. Original physics, controllers, verifiers and WorldLedger unchanged. Interruptions invalidate continuous timing, not legitimate bounded recovery. No automatic evaluation ingestion or weight training.\n\nNext: repeat cost measurements, measure cold and retention workloads, longer goal sequences and amortization; keep held-out cases and original outcome authority.\n')
nodes=[dict(id='readme',type='file',file='README-080.md',x=0,y=0,width=380,height=200)];edges=[]
for i,m in enumerate(mapping):nodes.append(dict(id=m['id'],type='file',file=m['source'],x=(i%3)*420,y=270+(i//3)*260,width=380,height=210));edges.append(dict(id='e'+str(i),fromNode='readme',fromSide='bottom',toNode=m['id'],toSide='top',label=m['name']))
js(r/'docs/obsidian/complete-task-costs.canvas',dict(nodes=nodes,edges=edges));js(d/'original-evidence.json',dict(format='Exact gzip originals from isolated synthetic projects and tests. Failed attempts retained. No private production project.',files=archives));print(json.dumps(dict(archives=len(archives),canonicalFiles=len(inventory),javaDistinct=v['javaDistinct'],estimationImproved=e['estimationImproved'])))
