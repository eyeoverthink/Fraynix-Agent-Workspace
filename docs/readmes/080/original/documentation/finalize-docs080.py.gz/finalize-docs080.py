from pathlib import Path
import json, gzip, hashlib, re
r=Path.cwd();d=r/'docs/readmes/080'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,s):p.write_text(s,encoding='utf8',newline='\n')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
v=read(d/'verification.json');v['visualReview']=read(r/'build/visual-review080.json');v['offlineBrowser']=read(r/'build/browser-docs080.log');assert v['visualReview']['passed'] and v['offlineBrowser']['passed'];js(d/'verification.json',v);archive=read(d/'original-evidence.json')
for name in ['check-docs080.cjs','browser-docs080.log','visual-review080.json','finalize-docs080.py','recapture-docs080.cjs','recapture-docs080.log']:
 p=r/'build'/name;b=p.read_bytes();z=gzip.compress(b,mtime=0);dest=d/'original/documentation'/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archive['files'].append(dict(path=dest.relative_to(r).as_posix(),bytes=len(z),sha256=hashlib.sha256(z).hexdigest(),rawBytes=len(b),rawSha256=hashlib.sha256(b).hexdigest(),source=str(p)))
js(d/'original-evidence.json',archive)
e=v['analysis']['summary'];result='; '.join(f"{k}: {x['successes']}/8, {x['ticks']} ticks/{x['stages']} stages, {x['completeMillis']/1000:.2f}s complete / {x['callerMillis']/1000:.2f}s caller" for k,x in e['methods'].items())
scope=f"{v['javaDistinct']} distinct Java checks/{v['javaClasses']} classes; {v['desktop']['tests']} desktop checks; actual primary/chat/report/export/skill/cold restart, separate interruption/resume/Stop, {len(v['tamper']['probes'])} independent altered-evidence probes and eight actual Java API source faults. Actual app1600/1100 and offline1440/390. Source-qualified invocations and failed first smoke preserved. Successful path uses deterministic Java planning; first smoke entered local-model repair. No new physical accuracy or weight-training claim."
p=r/'README.md';s=p.read_text(encoding='utf8');a=s.index('> **[Edition 079');b=s.index('One integrated app,',a);write(p,s[:a]+f'''> **[Edition 080 · Complete-task cost calibration](README-080.md)** · [Offline guide](docs/readmes/080/index.html) · [Edition history](docs/readmes/INDEX.md)

Java measures execution, verification, world commit and requested saving before estimating whether memory is worth using. Estimation improvement: **{e['estimationImproved']}**; complete-task efficiency: **{e['efficient']}**; first-batch efficiency including learning: **{e['firstBatchEfficient']}**. [Actual results, screenshots and evidence](README-080.md).

Edition 080 implementation, screenshots and original evidence are prepared for publication. [Previous fetched publication](docs/PUBLICATION_079.json).

'''+s[b:])
p=r/'docs/readmes/INDEX.md';s=p.read_text(encoding='utf8');i=s.index('\nLatest implementation');write(p,s[:i].rstrip()+'\n| [080](../../README-080.md) | 2026-11-06 | Complete-task cost calibration for verified memory | [Viewer](080/index.html) · [tree](080/FILE_TREE.md) |\n'+s[i:].replace('**079**','**080**'))
p=r/'docs/obsidian/00-home.md';s=p.read_text(encoding='utf8').replace('edition_context: 079','edition_context: 080');s=re.sub(r'Current:.*?System map\]\]\.', 'Current: [[README-080|Edition 080 — complete-task cost calibration]] ·\n[[docs/obsidian/88-complete-task-costs|Operation and next gates]] ·\n[[docs/obsidian/complete-task-costs.canvas|System map]].',s,count=1,flags=re.S);write(p,s)
entry=f'''## Edition 080 · Validated locally; publication next

Prospective contract2789bed, parent0978fb6; primary source{v['primarySource']}. Java measures admission through native execution, original audits, host report, world commit and requested retention. Final timing write and caller transport/polling excluded; caller elapsed separately measured. Explicit owned completed matched simple/memory pairs calibrate costs; original source hashes rechecked. At least two distinct compatible tasks, up to four neighbors, runtime/workload/receipt/recipe/warm-cold separation. Positive lower empirical saving required; no statistical coverage guarantee. Interrupted/resumed timing is ineligible. No original physics/controller/verifier/WorldLedger changes.

{result}. Estimation improved {e['estimationImproved']}, supported cases {e['coveredCases']}/8, MAE {e['maeMillis']}ms versus old {e['oldMaeMillis']}ms. Complete-task efficiency {e['efficient']}; first-batch efficiency {e['firstBatchEfficient']}. Training {e['trainingMillis']/1000:.2f}s; calibration plus fit {e['calibrationMillis']/1000:.2f}s. Three actual learning goals, four paired calibrations and eight new cases x four controls plus four unsupported controls. Frozen model/bank throughout evaluation. No outcome retuning, automatic ingestion or controller promotion.

{scope}

The primary comparison remains sourcefd2dfa4. Final source4ec4d26 changes only the Java report heading after that comparison, with a separate UI label correction; fresh native checks and final-source chat/skill/cold-restart smoke pass. Historical calibration keeps its original code identity. First smoke cold skill reuse refused internal workload metadata. Fixed saved defaults to strip internal fields and retain cost mode; corrected harness task-ID selection after restored ordering. Fresh smoke and primary passed. Original failure and repair/model-request logs retained. Existing review apps normal045/qa046, private data and services untouched. Procedure identity changes; old proof is never relabelled. Calibration with no saving does not cover chat retention/skills; cold restart requires cold-compatible evidence. Original kinematic reconstruction does not restore native contact manifolds.

README080, original screenshots, offline charts/replays, complete source inventory/raw archives, Obsidian88/canvas, memory/logs prepared. Push and fetch main/edition080/readme-080 next; not yet claimed. Preserve frozen001–079. No subagents or overlapping heavy tests. Next: repeat complete measurements, cold/retention workloads, longer goal sequences and amortization, broader tasks through existing verified contracts.

'''
for name in ['AGENTS.md','docs/PROJECT_MEMORY.md','docs/DEVELOPMENT_LOG.md']:
 p=r/name;s=p.read_text(encoding='utf8');s=re.sub(r'\n## Edition 080 · Implementation and validation in progress\n.*?(?=\n## Edition 079)', '\n',s,count=1,flags=re.S);i=s.index('\n');write(p,s[:i+1]+'\n'+entry+s[i+1:])
p=r/'docs/ARCHITECTURE.md';s=p.read_text(encoding='utf8');i=s.index('\n');write(p,s[:i+1]+'''
## Current edition080: complete-task cost calibration

[Edition080](../README-080.md) measures the existing durable procedure's full Java completion interval. `TaskCost080` matches owned completed controls and estimates empirical savings; `WorldProcedure079` persists timing/model/source provenance; `GoalRunner` owns the monotonic lifecycle clock and saving workload. The existing persistent-world panel reviews explicit comparison pairs. Original physics, native controls/verifiers, WorldFrames and WorldLedger remain unchanged. A cost estimate cannot authorize motion. Interrupted timings are excluded; retained models cannot substitute warm measurements for cold proof work or a different saving workload. Evaluation stays outside calibration.

'''+s[i+1:].replace('## Current edition079:','## Edition079 foundation:'))
print('Current docs and continuity prepared; publication next.')
