$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$env:JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=4'
if(!(Test-Path -LiteralPath 'build/legacy064-restore')){Copy-Item -LiteralPath '../fraynix-workspace-edition069/build/legacy064-restore' -Destination 'build/legacy064-restore' -Recurse}
$env:FRAYNIX064_NATIVE_RESUME=(Resolve-Path 'build/legacy064-restore').Path
New-Item -ItemType Directory -Path build/regression070 -Force | Out-Null
git rev-parse HEAD | Set-Content -Encoding utf8 build/regression070/source.txt
$regression070Args=@(':workspace-engine:test')
foreach($class in @('BrainPayload064Test','Agent042Test','BrainPersistenceTest','BrainServiceTest','ChatChain052Test','Domain044Test','StoppingContext063Test','Contact064Test','RecoveryCompatibility066Test','TemporalCompatibility067Test','CalibrationCompatibility068Test','LaterCompatibility069Test','AdaptiveCompatibility070Test','CalibrationChat068Test')){$regression070Args+=@('--tests',"*$class")}
foreach($name in @('publishedCalibrationIsExactAndRecomputed','policyFitsIntervalsAndSharesDomainFence','utilityCountsMissesAndRefusalsWithoutInventingEndpoints','gateRequiresBothComparisonsAndRealTaskSuccess','planningTablesRetainEveryMetricAndLeaveOriginalsUntouched','freshPartitionsHaveNoOldNativeDefinitions')){$regression070Args+=@('--tests',"*Decision065Test.$name")}
foreach($name in @('initialPoliciesRetainOldChoicesAndRefusalDomain','inverseAndBoundsUseOnlyTheSelectedState','attemptedRecoveryPaysForFailuresAndEveryUsedOperation','qualificationRequiresObservationBenefitCompletionAndRecovery','freshTasksAndLosslessContextRetainSubgroupsAndNulls')){$regression070Args+=@('--tests',"*Recovery066Test.$name")}
foreach($name in @('temporalEvidenceHandlesDropoutButRefusesLostOrUnsafeSupport','contextIsLosslessAndFutureMotionCannotChangePlanning','initialChoicesAreCompatibleAndScreenIsProspective','costsIncludeThreeObservationsAndDeclinedScreens','qualificationKeepsAllComparisonsAndFailureLimits')){$regression070Args+=@('--tests',"*Temporal067Test.$name")}
foreach($name in @('lateInverseHonorsBudgetGuardAndNoActionWhenAlreadyFits','lateWindowChecksAllSamplesAndRejectsFuture','casesAreNewBalancedAndFrozenModelIsExact','feesIncludeFailedAttemptAndEveryLaterObservation','gateRejectsAddedCostsHarmsAndLateFailures')){$regression070Args+=@('--tests',"*Later069Test.$name")}
$regression070Args+=@(':workspace-engine:installDist' ,'verifySourceIsolation','--no-daemon','--max-workers=1','-I','build/validation070.init.gradle')
& ./gradlew.bat @regression070Args *> build/regression070/regression.log
$regression070Exit=$LASTEXITCODE
Copy-Item workspace-engine/build/test-results/test/TEST-*.xml build/regression070
Get-Content build/regression070/regression.log -Tail 25
exit $regression070Exit
