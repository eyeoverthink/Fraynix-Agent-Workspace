$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$env:JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=4'
if(!(Test-Path -LiteralPath 'build/legacy064-restore')){Copy-Item -LiteralPath '../fraynix-workspace-edition068/build/legacy064-restore' -Destination 'build/legacy064-restore' -Recurse}
$env:FRAYNIX064_NATIVE_RESUME=(Resolve-Path 'build/legacy064-restore').Path
New-Item -ItemType Directory -Path build/regression069 -Force | Out-Null
git rev-parse HEAD | Set-Content -Encoding utf8 build/regression069/source.txt
$regression069Args=@(':workspace-engine:test')
foreach($class in @('BrainPayload064Test','Agent042Test','BrainPersistenceTest','BrainServiceTest','ChatChain052Test','Domain044Test','StoppingContext063Test','Contact064Test','RecoveryCompatibility066Test','TemporalCompatibility067Test','CalibrationCompatibility068Test','LaterCompatibility069Test','CalibrationChat068Test')){$regression069Args+=@('--tests',"*$class")}
foreach($name in @('publishedCalibrationIsExactAndRecomputed','policyFitsIntervalsAndSharesDomainFence','utilityCountsMissesAndRefusalsWithoutInventingEndpoints','gateRequiresBothComparisonsAndRealTaskSuccess','planningTablesRetainEveryMetricAndLeaveOriginalsUntouched','freshPartitionsHaveNoOldNativeDefinitions')){$regression069Args+=@('--tests',"*Decision065Test.$name")}
foreach($name in @('initialPoliciesRetainOldChoicesAndRefusalDomain','inverseAndBoundsUseOnlyTheSelectedState','attemptedRecoveryPaysForFailuresAndEveryUsedOperation','qualificationRequiresObservationBenefitCompletionAndRecovery','freshTasksAndLosslessContextRetainSubgroupsAndNulls')){$regression069Args+=@('--tests',"*Recovery066Test.$name")}
foreach($name in @('temporalEvidenceHandlesDropoutButRefusesLostOrUnsafeSupport','contextIsLosslessAndFutureMotionCannotChangePlanning','initialChoicesAreCompatibleAndScreenIsProspective','costsIncludeThreeObservationsAndDeclinedScreens','qualificationKeepsAllComparisonsAndFailureLimits')){$regression069Args+=@('--tests',"*Temporal067Test.$name")}
$regression069Args+=@(':workspace-engine:installDist','verifySourceIsolation','--no-daemon','--max-workers=1','-I','build/validation069.init.gradle')
& ./gradlew.bat @regression069Args *> build/regression069/regression.log
$regression069Exit=$LASTEXITCODE
Copy-Item workspace-engine/build/test-results/test/TEST-*.xml build/regression069
Get-Content build/regression069/regression.log -Tail 25
exit $regression069Exit
