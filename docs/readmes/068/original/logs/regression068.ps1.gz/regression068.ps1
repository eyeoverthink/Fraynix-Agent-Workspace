$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$env:JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=4'
if(!(Test-Path -LiteralPath 'build/legacy064-restore')){Copy-Item -LiteralPath '../fraynix-workspace-edition067/build/legacy064-restore' -Destination 'build/legacy064-restore' -Recurse}
$env:FRAYNIX064_NATIVE_RESUME=(Resolve-Path 'build/legacy064-restore').Path
New-Item -ItemType Directory -Path build/regression068 -Force | Out-Null
git rev-parse HEAD | Set-Content -Encoding utf8 build/regression068/source.txt
$regression068Args=@(':workspace-engine:test')
foreach($class in @('BrainPayload064Test','Agent042Test','BrainPersistenceTest','BrainServiceTest','ChatChain052Test','Domain044Test','StoppingContext063Test','Contact064Test','RecoveryCompatibility066Test','TemporalCompatibility067Test','CalibrationCompatibility068Test')){$regression068Args+=@('--tests',"*$class")}
foreach($name in @('publishedCalibrationIsExactAndRecomputed','policyFitsIntervalsAndSharesDomainFence','utilityCountsMissesAndRefusalsWithoutInventingEndpoints','gateRequiresBothComparisonsAndRealTaskSuccess','planningTablesRetainEveryMetricAndLeaveOriginalsUntouched','freshPartitionsHaveNoOldNativeDefinitions')){$regression068Args+=@('--tests',"*Decision065Test.$name")}
foreach($name in @('initialPoliciesRetainOldChoicesAndRefusalDomain','inverseAndBoundsUseOnlyTheSelectedState','attemptedRecoveryPaysForFailuresAndEveryUsedOperation','qualificationRequiresObservationBenefitCompletionAndRecovery','freshTasksAndLosslessContextRetainSubgroupsAndNulls')){$regression068Args+=@('--tests',"*Recovery066Test.$name")}
foreach($name in @('temporalEvidenceHandlesDropoutButRefusesLostOrUnsafeSupport','contextIsLosslessAndFutureMotionCannotChangePlanning','initialChoicesAreCompatibleAndScreenIsProspective','costsIncludeThreeObservationsAndDeclinedScreens','qualificationKeepsAllComparisonsAndFailureLimits')){$regression068Args+=@('--tests',"*Temporal067Test.$name")}
$regression068Args+=@(':workspace-engine:installDist','verifySourceIsolation','--no-daemon','--max-workers=1','-I','build/validation068.init.gradle')
& ./gradlew.bat @regression068Args *> build/regression068/regression.log
$regression068Exit=$LASTEXITCODE
Copy-Item workspace-engine/build/test-results/test/TEST-*.xml build/regression068
Get-Content build/regression068/regression.log -Tail 25
exit $regression068Exit
