package fraymus.workspace;
import org.json.*;import java.nio.file.*;
public class InspectContext068{
 public static void main(String[] args)throws Exception{
  var facts=new JSONObject(Files.readString(Path.of(args[0])));var g=new JSONObject(Files.readString(Path.of("build/chat068-first.json")));g.getJSONObject("context044").put("agent042Facts",facts);
  var c=ChatChain052.context(g);Files.writeString(Path.of("build/chat-projection068.json"),c.toString(2));
  System.out.println("Context chars="+c.toString().length());for(String k:c.keySet())System.out.println(k+"="+c.get(k).toString().length());for(String k:c.getJSONObject("agent042Facts").keySet())System.out.println("facts."+k+"="+c.getJSONObject("agent042Facts").get(k).toString().length());
 }
}
