from pathlib import Path
import subprocess,json,sys,os,re,hashlib
r=Path.cwd();out=Path(sys.argv[1]).resolve();record=json.loads((out/'result.json').read_text(encoding='utf8'));assert record['passed']
os.environ['JAVA_HOME']='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot';os.environ['PATH']=os.environ['JAVA_HOME']+'/bin;'+os.environ['PATH'];os.environ['JAVA_TOOL_OPTIONS']='-XX:ActiveProcessorCount=4 -Xmx768m'
def run(args,log):
 with (r/'build'/log).open('wb') as f:subprocess.run(args,cwd=r,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('PASS',log,flush=True)
originals=json.loads((r/'build/export-test076-first/original-hashes.json').read_text(encoding='utf8'));assert all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in originals);(r/'build/original-preservation076.json').write_text(json.dumps({'passed':True,'files':len(originals),'scope':'All primary original.json bytes unchanged across harness continuation, restart and recovery validation.'},indent=2),encoding='utf8')
run(['node','scripts/Inspect-Procedures076.cjs',str(out)],'native-analysis076.json')
run(['node','scripts/Test-Procedures076-Inspector.cjs',str(out)],'inspector-probes076.json')
run(['node','workspace-desktop/test/procedures076-final.cjs',str(out)],'final-app076.log')
run(['pwsh','-NoProfile','-File','build/regress076.ps1'],'regress-run076.log')
s=(r/'build/desktop076.log').read_text(encoding='utf-8-sig');values={k:int(re.search(r'^(?:#|\u2139) '+k+r' (\d+)',s,re.M).group(1)) for k in ['tests','pass','fail','cancelled','skipped']};assert values['tests']==values['pass'] and not any(values[k] for k in ['fail','cancelled','skipped']);(r/'build/desktop076.json').write_text(json.dumps({'passed':True,**values},indent=2),encoding='utf8')
