from pathlib import Path
import json,hashlib,gzip,subprocess,sys,html,re,shutil,base64,datetime,xml.etree.ElementTree as ET
r=Path.cwd();out=Path(sys.argv[1]);d=r/'docs/readmes/076';d.mkdir(parents=True,exist_ok=True)
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
result=load(out/'result.json');assert result['passed'];study=load(out/'study.json');analysis=load(r/'build/native-analysis076.json');tamper=load(r/'build/inspector-probes076.json');assert analysis['passed'] and tamper['passed'];source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();project=Path(result['project']);archives=[]
def pack(p,dest):
 b=p.read_bytes();z=gzip.compress(b,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archives.append(dict(path=dest.relative_to(r).as_posix(),bytes=len(z),sha256=sha(z),rawBytes=len(b),rawSha256=sha(b),source=str(p)))
for p in sorted(out.iterdir()):
 if p.is_file() and p.suffix in ['.json','.log','.txt']:pack(p,d/'original/app'/(p.name+'.gz'))
for label,studyId in [('primary',study['id']),('recovery',result['recoveryId'])]:
 root=project/'procedures-076'/studyId
 for p in sorted(root.rglob('*.json')):
  if p.name in ['original.json','study.json'] or 'bank' in p.parts:pack(p,d/'original'/label/p.relative_to(root).with_suffix('.json.gz'))
first=load(r/'build/development076-first/reason.json');firstRoot=Path(first['project'])/'procedures-076'/first['studyId'];partial=load(firstRoot/'study.json')['data'];attempts=[a for row in partial['training']+partial['rows'] for arm in row['results'].values() for a in arm['attempts']]
for p in sorted(firstRoot.rglob('*.json')):
 if p.name in ['original.json','study.json']:pack(p,d/'original/development-first'/p.relative_to(firstRoot).with_suffix('.json.gz'))
for p in sorted(Path(first['out']).iterdir()):
 if p.is_file() and p.suffix in ['.json','.log','.txt']:pack(p,d/'original/development-app'/(p.name+'.gz'))
pack(r/'build/development076-first/reason.json',d/'original/development-first/reason.json.gz')
for p in sorted((r/'build/export-test076-first').iterdir()):
 if p.is_file():pack(p,d/'original/harness-export-first'/(p.name+'.gz'))
for p in sorted((r/'build').glob('*076*.log')):pack(p,d/'original/logs'/(p.name+'.gz'))
cases={};invocations=[]
for folder in ['preflight076','handoff076','regression076']:
 rows=[]
 for p in sorted((r/'build'/folder).glob('TEST-*.xml')):
  root=ET.parse(p).getroot()
  for c in root.findall('testcase'):
   key=c.attrib['classname']+'#'+c.attrib['name'];passed=all(c.find(n) is None for n in ['failure','error','skipped']);cases[key]=passed;rows.append(dict(case=key,passed=passed))
  pack(p,d/'original/java'/folder/(p.name+'.gz'))
  for loc in re.findall(r'(?:PROCEDURE076_NATIVE_SOURCE|MEMORY073_NATIVE_SOURCE) ([^\r\n<]+)',p.read_text(encoding='utf8')):
   for f in Path(loc).glob('*.json'):
    if f.name.startswith(('forecast-','actual-')) or f.name in ['original.json','reconstruction.json']:pack(f,d/'original/java'/folder/(f.name+'.gz'))
 if rows:invocations.append(dict(name=folder,cases=rows))
assert cases and all(cases.values())
for name in ['native-analysis076.json','inspector-probes076.json','desktop076.json','final-app076.json','original-preservation076.json','unchanged-native076.json','regress076.ps1','document076.py','guide076.html']:
 pack(r/'build'/name,d/'original/validation'/(name+'.gz'))
for p in sorted(out.glob('*.png')):
 if p.name!='failure.png':shutil.copyfile(p,d/p.name)
for p in sorted((r/'build/final-captures076').glob('*.png')):shutil.copyfile(p,d/p.name)
data={k:study[k] for k in ['id','evaluation','trainingTicks','trainingWallMillis','auditMillis','bank','protocol','code','bankFrozenAt']};data['trainingElapsedMillis']=(datetime.datetime.fromisoformat(study['bankFrozenAt'])-datetime.datetime.fromisoformat(study['createdAt'])).total_seconds()*1000;data['rows']=[]
for row in study['training']+study['rows']:
 x=load(out/(row['id']+'-originals.json'));row=json.loads(json.dumps(row));row['replays']={m:[] for m in row['results']}
 for item in x['originals']:
  packet=item['run'];raw=gzip.decompress(base64.b64decode(packet['gzipBase64']));assert sha(raw)==packet['rawSha256'];run=json.loads(raw);a=item['attempt'];n=len(run['samples']);indices=sorted(set([round(i*(n-1)/min(239,max(1,n-1))) for i in range(min(240,n))]));frames=[]
  for i in indices:
   f=run['samples'][i];frames.append(dict(tick=f['tick'],originalSampleIndex=i,bodies=[{k:b[k] for k in ['id','position','rotation']} for b in f['bodies']]))
  row['replays'][item['method']].append(dict(id=run['id'],stage=a['stage'],family=a['family'],status=a['status'],definition=run['definition'],originalSampleCount=n,samples=frames))
 data['rows'].append(row)
write(d/'comparison-data.json',json.dumps(data,separators=(',',':'),ensure_ascii=False)+'\n')
paths={x['path'] for x in load(r/'docs/readmes/075/file-inventory.json')};paths.update(x for x in subprocess.check_output(['git','diff','--name-only','--diff-filter=A','d7e2ca9','HEAD'],text=True).splitlines() if x.startswith(('workspace-engine/','workspace-desktop/','scripts/','fraynix-modules/')));inventory=[]
for name in sorted(paths):
 b=(r/name).read_bytes()
 try:b=b.decode('utf8').replace('\r\n','\n').encode();kind='utf8-lf'
 except UnicodeError:kind='binary'
 inventory.append(dict(path=name,bytes=len(b),hashKind=kind,sha256=sha(b)))
js(d/'file-inventory.json',inventory);write(d/'FILE_TREE.md','# Edition 076 complete source tree\n\n[Canonical bytes and hashes](file-inventory.json).\n\n```text\n'+'\n'.join(x['path'] for x in inventory)+'\n```\n')
v=dict(edition=76,primaryNativeAttempts=sum(len(a['attempts']) for row in study['training']+study['rows'] for a in row['results'].values()),source=source,contract='435e95c',initialImplementation='c0a36b8',runtimeImplementation='6530e9b',javaDistinct=len(cases),javaClasses=len({k.split('#')[0] for k in cases}),javaAllPassed=True,javaInvocations=invocations,desktop=load(r/'build/desktop076.json'),actualApp=result['checks'],actualAppSource=result['source'],finalApp=load(r/'build/final-app076.json'),coldAudit=result['coldAudit'],originalPreservation=load(r/'build/original-preservation076.json'),validationSource=result.get('validationSource',result['source']),analysis=analysis,tamper=tamper,developmentPartial=dict(studyId=partial['id'],settledArms=partial['progress'],attempts=len(attempts),chargedTicksWithUnknownTails=sum(a.get('chargedTicks',14400) for a in attempts),reason=first['reason']),scope='Frozen declared native box tasks: three training scenes, eight unfamiliar supported configurations and four refusal controls. All recipe failures, work and explicit recovery retained. Same solver/controller; no new footage, independent physical solver, LLM inference/weight learning or general intelligence test.')
js(d/'verification.json',v);js(d/'original-evidence.json',dict(format='Exact original export/checkpoint/log/XML bytes, gzip-compressed. Primary study, separate recovery and retained development failure are distinct. Synthetic isolated projects; no personal database or model weights.',files=archives))
modules=[('procedure','Typed procedures','Procedure076.java','Direct, reversed, half-force and measured two/three-stage decomposition; unchanged original authority and native verifier.'),('study','Durable Java study','ProcedureStudy076.java','Owns training, immutable receipts, matched control runs, budgets, recovery, verification and export.'),('frame','Measured world frames','WorldFrames.java','Carries exact positions, rotations, velocities and elapsed ticks while preserving original geometry and IDs.'),('verify','Original physics gates','WorldVerify.java','Original integrated wrench, lifecycle, endpoint and protected-body checks remain authoritative.'),('view','Integrated evidence view','procedures076.js','Actual progress, training/test controls, per-arm costs, native stage replay and exact exports.'),('inspect','Independent arithmetic','Inspect-Procedures076.cjs','Checks original trace arithmetic, staged handoffs, frozen ranking, fresh execution and all costs outside Java.')]
mapping=[dict(id=i,name=n,note='docs/obsidian/84-verified-procedures.md',source=('workspace-desktop/renderer/' if p.endswith('.js') else 'scripts/' if p.endswith('.cjs') else 'workspace-engine/src/main/java/fraymus/workspace/')+p,description=t) for i,n,p,t in modules]
system=dict(modules=mapping,screenshots=[dict(path='docs/readmes/076/'+p.name,label=p.stem) for p in sorted(d.glob('*.png'))],evidence=[dict(path=q) for q in ['docs/readmes/076/verification.json','docs/readmes/076/original-evidence.json','docs/EDITION_076_CONTRACT.md']]);js(d/'system-map.json',system)
e=study['evaluation'];m=e['methods'];methods=['legacy','simple','geometry','memory'];summary='\n'.join(f"| {name} | {m[name]['successes']}/8 | {m[name]['ticks']:,} | {m[name]['runs']} | {m[name]['wallMillis']/1000:.2f} | {m[name]['utility']:.6f} |" for name in methods);pairs='\n'.join(f"| Memory versus {name} | {x['saved']} | {x['harmed']} | {x['tickDelta']:,} | {x['utilityDelta']:.6f} |" for name,x in e['paired'].items());qual='PASSED' if e['qualified'] else 'NOT PASSED'
caseRows='\n'.join('| '+row['id']+' | '+' | '.join(('success' if row['results'][name]['success'] else ('not verified' if row['results'][name]['status']=='completed' else row['results'][name]['status']))+' / '+str(row['results'][name]['chargedTicks']) for name in methods)+' |' for row in study['rows'])
trainRows='\n'.join('| '+row['id']+' | '+' | '.join(('verified' if row['results'][f]['success'] else 'not verified')+' / '+str(row['results'][f]['chargedTicks']) for f in ['direct','reverse','half-force','two-stage','three-stage'])+' |' for row in study['training']);families=', '.join(sorted(set(b['family'] for b in study['bank'])))
relation=(f"Memory and the geometry control both solved {m['memory']['successes']}/8 tasks. " if m['memory']['successes']==m['geometry']['successes'] else f"Memory solved {m['memory']['successes']}/8 versus geometry's {m['geometry']['successes']}/8. ")+f"Simple control solved {m['simple']['successes']}/8; legacy solved {m['legacy']['successes']}/8. "+('Memory and geometry used exactly the same charged native work. Memory took 21.91% longer in measured active wall time; retrieval therefore adds proof/lookup overhead without a measured selection advantage on this set.' if m['memory']['ticks']==m['geometry']['ticks'] else 'Use the paired counts and costs below to distinguish new successes from reordered work; neither alone justifies a broader capability claim.')
readme=f'''# Fraynix Agent Workspace · Edition 076

**Varied verified procedures, measured against equally equipped simple controls.** November 5, 2026.

[Previous edition 075](README-075.md) · [Offline interactive guide](docs/readmes/076/index.html) · [Complete source tree](docs/readmes/076/FILE_TREE.md) · [Validation](docs/readmes/076/verification.json) · [Original evidence](docs/readmes/076/original-evidence.json) · [Frozen contract](docs/EDITION_076_CONTRACT.md) · [Edition history](docs/readmes/INDEX.md)

## What changed

Edition 075 demonstrated that an exact reconstruction certificate could avoid repeated setup work. It did not establish better procedural decisions: the remembered alternatives largely selected the same control that a simpler method would choose. Edition 076 adds a genuinely executable repertoire of five typed Java procedures and tests whether their verified training outcomes improve success on unfamiliar arrangements.

The new procedures include two-stage and three-stage tasks. A stage is a complete native arrangement, ending only after the original pose, speed, force and protected-body checks. The next stage starts from the measured positions, rotations, linear velocities, angular velocities and elapsed ticks. It does not pretend the objects stopped perfectly or write them directly to the next target. A whole-task forecast must be followed by a distinct actual execution from the original starting frame before the procedure can enter the training bank.

The app now contains **{len(study['bank'])} verified training receipts** from this study, covering **{families}**. These are saved, versioned procedures with original native evidence. They are separate from the existing general skill registry and are not automatically promoted into arbitrary active-world execution. The integrated comparison is functional: it trains, freezes, retrieves, executes, verifies, survives restart, displays motion and exports originals.

![Actual integrated results](docs/readmes/076/final-comparison-results.png)

*Actual dated capture of the isolated validation app. The model selector elsewhere in the interface is not evidence of new LLM inference. All reported motions below come from retained native physics runs.*

## The measured answer

**Learned-selection success improvement: {qual}.** The primary qualification requires more successes than both equally equipped controls, no harmed cases against either and positive paired utility. A better repertoire than the older control is useful, but does not by itself demonstrate that memory selects better than simple geometry.

| Method | Verified successes | Charged ticks | Native stages | Active wall seconds | Primary utility |
| --- | --- | --- | --- | --- | --- |
{summary}

{relation}

| Paired comparison | Tasks saved | Tasks harmed | Extra native ticks | Utility difference |
| --- | --- | --- | --- | --- |
{pairs}

Training consumed **{study['trainingTicks']:,} native ticks** and **{study['trainingWallMillis']/1000:.2f} summed per-arm active seconds**, including failures. Elapsed time from study creation to the sealed bank was **{data['trainingElapsedMillis']/1000:.2f} seconds** by the recorded timestamps; that additionally includes bank-proof auditing, storage and scheduling outside individual arms. The final original-proof audit took **{study['auditMillis']/1000:.2f} seconds**. Memory's new-task work plus the complete training bill is **{study['trainingTicks']+m['memory']['ticks']:,} ticks**, or **{(study['trainingTicks']+m['memory']['ticks'])/8:.2f} per unfamiliar supported task** for this single batch. The offline chart can include that training bill. The simple and geometry methods use the same hand-written procedures without performing retrieval or training-proof validation.

Work means charged simulated ticks, not GPU operations, wall-clock speed or electricity. Active wall time includes scheduling, lookup, planning, native execution, verification and storage within each arm. Bank-freeze work outside the individual training arms, final audit and separate development/recovery tests are additional overheads; the creation-to-freeze elapsed time is reported above. Recorded elapsed timestamps are not CPU time. This is one deterministic run per method and case, not a population confidence estimate. No outcome or threshold was tuned after the primary results.

## Four controls with a fair comparison

The **legacy** control tries direct, reversed order and half force, stopping at the first whole-task success. This preserves the prior three-alternative baseline. The **simple** control has all five procedures and tries them in a fixed order. The **geometry** control also has all five, choosing three stages first for travel greater than eight metres, otherwise two stages for a shortest yaw change greater than 130 degrees, otherwise direct. Those rules were committed before any new native outcome.

The **memory** control ranks only verified training receipts by declared components: matching target roles, size, mass, friction, requested travel and yaw, plus force and torque ceilings. Equal distances prefer lower measured training work, then stable receipt identity. It revalidates the selected original proof before trying the same recipe on the new task. If the target roles are incompatible, it explicitly falls back to fixed-order simple control and retains the lookup cost. It never matches on a hidden test-case label or learns from evaluation outcomes.

Giving memory more tools than the baseline would confound the comparison. Here simple, geometry and memory have the same repertoire, budgets, force limits and checks. Improvements over legacy measure repertoire value; improvements over simple and geometry measure the extra value of learned selection. Both answers are reported even when the stronger qualification fails.

The declared utility is `success - 0.2 × chargedTicks / 86400`, summed over eight supported cases. It is an accounting preference, not a probability. A cheaper tie alone cannot pass the learned-success gate. The four unsupported controls must all refuse with zero actuation; their exclusions from the eight-case denominator are explicit and their full records remain available.

## What training actually retained

| Training scene | Direct | Reverse | Half force | Two-stage | Three-stage |
| --- | --- | --- | --- | --- | --- |
{trainRows}

Each table cell shows outcome and charged ticks. Every recipe was attempted on each of the three declared sources. Failed forecasts, refused plans and consumed work remain recorded. Only a complete forecast and separate successful actual procedure create a receipt. The bank was frozen at `{study['bankFrozenAt']}` before any evaluation attempt.

The large-heading training scene illustrates why composition matters. The original direct alternatives stalled under the same declared torque ceiling, while staged procedures completed the arrangement. Their intermediate goals reduced the required change per native stage without increasing force or erasing measured motion. The long-travel scene also exposes a constraint: an equal-fraction intermediate target can collide with existing geometry. The conservative planner must refuse such a stage; interpolation is not a universal route planner.

![Training outcomes for the large turn](docs/readmes/076/training-heading-results.png)

A receipt records the training source, family/version, costs, owned study and arm, native/verifier identity, exact proof hash and all stage lineage. Hashes detect changed bytes; they are not cryptographic signatures proving an adversarially controlled machine trustworthy. Source ownership and actual native verification remain necessary. Imported text cannot install a handler or mark a procedure successful.

## Every unfamiliar case stays in the result

| Case | Legacy | Simple | Geometry | Memory |
| --- | --- | --- | --- | --- |
{caseRows}

The cases vary heading, distance, combined demands, payload, friction and target-role compatibility. They remain in the same declared upright-box task family. The four unsupported controls cover excessive mass, oversized geometry, missing floor and invalid target height. A refusal is a useful boundary check, not a secretly completed task.

![Retrieved procedure and retained costs](docs/readmes/076/retrieved-procedure-results.png)

## How measured stages connect

```mermaid
flowchart LR
    A[Declared training source] --> B[Typed Java procedure]
    B --> C[Native forecast stages]
    C --> D[Distinct actual stages]
    D --> E[Original checks and full-task verification]
    E --> F[Frozen owned receipt]
    F --> G[Component-based retrieval]
    G --> H[Unfamiliar task with fresh execution]
    H --> I[Compare against matched simple controls]
    I --> J[Retain outcomes, costs and replay]
```

Intermediate targets are derived from the original source and requested endpoint, not repeatedly interpolated from a drifting current estimate. Translation uses equal fractions. Rotation uses the shortest yaw path, including the wrap across ±180 degrees. The final stage retains the exact requested targets. Two-stage and three-stage procedures remain separate typed recipes, not arbitrary executable text emitted by an LLM.

After each successful stage, `WorldFrames.after` preserves all dynamic bodies, their stable IDs, original geometry and accumulated time. The next fresh native world initializes from that exact measured frame. This is a **kinematic cold handoff**: solver contact manifolds and hidden integrator state are not restored continuously. The native initialization checks bound any numeric conversion error in positions, orientations and velocities. The UI and documentation name this limitation directly.

Each native stage still uses the original `WorldPlan`, `WorldPhysics` and `WorldVerify`. Completed stages cannot silently bypass their original release, target, inactive-body, force, torque or speed gates. Whole-task final targets require position error at most 0.1 m, orientation error at most 5 degrees, speed at most 0.2 m/s and angular speed at most 0.2 rad/s. Non-target bodies are additionally checked against the original whole-task positions and rotations at **every integrated tick**, not merely the displayed samples or a new anchor at each stage.

Forecast and actual programs start independently from the same initial frame. Each actual stage must match its forecast's exact source and plan, with at least 95% sample coverage and at most 0.01 m positional and 0.5-degree orientation residual. A stored forecast cannot be relabelled as the actual run. An observed success cannot be credited before its complete verification chain is present.

![Actual second-stage native replay](docs/readmes/076/training-heading-staged-replay.png)

## Bounds, recovery and costs

Each arm has an 86,400-tick and 900-active-second ceiling. Every native stage retains its original 14,400-tick and 90-wall-second bounds. Before a candidate begins, the runner reserves the worst-case work for all of its forecast and actual stages. It checks the remaining reserve again before each stage. This makes ordering consequential: after spending work on failed candidates, a six-run three-stage forecast/actual program may no longer fit. The refusal and unused capacity remain visible rather than borrowing beyond the common budget. In particular, the two unfamiliar long-distance cases succeeded with memory and geometry-first ordering, while fixed-order control spent work on earlier failed alternatives and could no longer reserve the full three-stage worst case. That is a benefit of ordering under this prospective reservation rule, not evidence that the fixed-order method consumed all86,400 ticks or that memory has discovered a new physics law.

A failed stage stops that program. A later candidate begins again at the original source, retaining the earlier failure and cost. Stop cannot qualify unfinished work. An interrupted native tail is conservatively charged the full 14,400 ticks when its completion is unknown. Explicit Resume retains settled stages and histories and is limited to two resumptions. Recovery is tested separately from the primary comparison so its probe does not inflate or improve the reported score.

All study worlds are isolated. No procedure is automatically applied to an active user world, promoted to a global controller or ingested as evaluation training. Existing persistent-world commits still require their own authority and fresh checks. The study demonstrates verified reusable procedure selection within a bounded task family; broader chat-directed execution remains a subsequent integration gate.

## Review the app, step by step

1. Start the Java-backed workspace using the existing launch instructions in the [entry README](README.md). Keep an existing private project's ownership separate from a new test project.
2. Open **Spatial**, expand the persistent-world section, then **Verified procedures · learn and compare**.
3. Use **Train procedures & compare** to run a new isolated study. Progress counts fifteen training arms plus forty-eight evaluation arms. The app refuses other compute mutations while this serial study owns execution.
4. Watch the training phase, bank freeze, unfamiliar-case comparison and original-proof audit. A running or interrupted job has no improvement claim. **Stop study** preserves its work; **Resume interrupted study** resumes only compatible code and protocol.
5. Choose a training or test scene and a procedure/control. Inspect successes, failures, charged and observed ticks, chosen procedure and retrieval evidence.
6. Use **Load recorded motion**, select a native stage and move the frame slider. Changing case or method clears the previous replay identity. Replay is a read-only view.
7. Use **Export case & original traces** after the study settles. Exported packets contain original native traces and checksums, source/plan declarations, attempt metadata, bank and procedure outcomes. They do not grant execution authority.
8. Restart the app and select the saved study. Verified recipes, results and proof identities remain available; cold verification is part of this release's recorded tests.

The companion [offline guide](docs/readmes/076/index.html) provides training and test selectors, all methods, stage replay, cost charts, a training-cost toggle, module links, screenshots and searchable source inventory. Its displayed motion is sampled to at most 240 retained frames per stage for a smaller offline page. Exact unabridged traces and all integrated ticks remain in the original exports. The viewer does not synthesize missing motion or operate the application.

## Validation and retained development failures

The primary comparison retained **{v['primaryNativeAttempts']} native stage attempts**, including failures. The release records **{v['javaDistinct']} distinct targeted Java checks across {v['javaClasses']} classes**, **{v['desktop']['tests']} desktop checks**, the actual 63-arm app comparison, full original-proof audit after cold restart, export/replay checks, separate interruption/resume/Stop, and damaged-bank refusal. Independent inspection recomputes native displacement, force/torque authority, stage handoffs, final outcomes, retrieval order and charged costs. **{len(tamper['probes'])} altered-evidence probes** verify that false sources, missing originals, substituted stages, erased carried motion, changed authority, costs, ranking or success labels are rejected. Validation scope and exact invocation records are in [verification.json](docs/readmes/076/verification.json).

The first compile failed on a Java parameter-type error, then passed after correction. The first app study stopped after {partial['progress']} settled training arms because the inherited edition073 reconstruction comparison deliberately accepts only initial-at-rest scenes. A later actual stage correctly retained velocity, so that older contract refused it. The repair added a separate edition076 comparison with exact source/plan equality and original native verification; the edition073 restriction remains unchanged. A real four-run test verifies two forecast stages and two independently executed actual stages, including nonzero velocity carried into stage two. A separate boundary test catches a bystander moving out of bounds and back between displayed frames.

That partial study retains {len(attempts)} native attempts and {v['developmentPartial']['chargedTicksWithUnknownTails']:,} charged ticks, with unknown tails charged conservatively where needed. It is development evidence, not part of the primary score. The complete primary study restarted from a new empty project after correction `6530e9b`; the frozen cases, thresholds, controls and budget were unchanged. The completed primary study also exposed two test-harness assumptions: it read the first export manifest before asynchronous creation, then compared a restart-updated timestamp as immutable data. The harness now waits for actual file creation and compares every retained outcome field while excluding only the ordinary last-opened timestamp. Its original failures are archived; primary motion was not rerun. No performance tuning followed the primary outcomes. Tests ran serially with Java21, four CPUs and a 768MB heap; installed jars were not replaced while their app was alive.

## Current architecture and practical value

The application remains one local workspace with Java-owned goals, chat planning, skill scheduling, persistent worlds, experiment histories, model routing and verification. The desktop hosts the browser, creation canvas, integrated views and input. The existing Game Lab remains a runtime and visualization surface. These responsibilities let an agent observe state, propose action, execute bounded alternatives, inspect actual motion and retain a procedure whose success is traceable to evidence.

This edition adds handwritten Java composition, receipts, selection, budgets and verification around the existing solver. Existing Bullet/Minie, JSON and Electron/Chromium dependencies remain; they have not been rewritten or hidden behind a pure-Java claim. The new logic has no added external framework. Nor does a versioned bank constitute LLM weight training, semantic understanding of an arbitrary photograph or unrestricted self-improvement.

The useful advance is inspectable task knowledge: a procedure can encode a multi-step way of working, preserve the actual state between steps and be reused only when its original proof is valid. The app's live processes and evidence provide content for evaluation. More elaborate intelligence should earn its place by improving a complete task against a simpler alternative.

## Next steps and acceptance gates

- **Separate repertoire value from selection value.** Keep the current result intact. Freeze a new task set before changing retrieval or geometry rules; require more useful successes, no hidden harmed cases and all training/validation work included.
- **Use failure traces for better intermediate goals.** Equal-fraction staging can place a target on an obstacle. A subsequent typed procedure could choose a verified clear waypoint using the owned geometry logic, with conservative clearance checks and no extra force allowance.
- **Make memory selective and cheaper.** Profile repeated proof reads and component ranking. Any cache must bind source, code, restore contract and original evidence, and still require fresh execution on a changed task.
- **Connect the proven repertoire to durable goals.** Let chat request a supported procedure through Java's existing typed routing, with explicit scope, task-specific checks, interruption recovery and active-world commit verification. Do not expose a comparison success as permission to execute arbitrary code.
- **Expand only after the boundary is measured.** Continuous contact-state restoration, interacting or non-upright bodies, richer geometry and physical-camera grounding need their own tests. Synthetic native success does not establish real-world calibration.

These are planned gates, not claims that the features already exist. The complete current sources, original records and next-step reasoning are linked below.

## Sources and continuity

[Typed procedures](workspace-engine/src/main/java/fraymus/workspace/Procedure076.java) · [Java study runner](workspace-engine/src/main/java/fraymus/workspace/ProcedureStudy076.java) · [Frozen protocol](workspace-engine/src/main/resources/procedures076-protocol.json) · [Integrated panel](workspace-desktop/renderer/procedures076.js) · [Independent inspector](scripts/Inspect-Procedures076.cjs) · [Actual integration test](workspace-desktop/test/procedures076-integration.cjs) · [Obsidian operation note](docs/obsidian/84-verified-procedures.md) · [System canvas](docs/obsidian/verified-procedures.canvas) · [Project memory](docs/PROJECT_MEMORY.md) · [Development log](docs/DEVELOPMENT_LOG.md).

Earlier numbered editions and their frozen assets remain unchanged. This edition's publication target is the existing private Fraynix-Agent-Workspace repository; the historical Chandra application remains separate.
'''
write(r/'README-076.md',readme)
shots=''.join(f'<figure><a href="{html.escape(p.name)}"><img src="{html.escape(p.name)}" alt="Actual edition076 {html.escape(p.stem)}"></a><figcaption>{html.escape(p.stem)} · actual isolated app capture, November5,2026.</figcaption></figure>' for p in sorted(d.glob('*.png')))
guide=(r/'build/guide076.html').read_text(encoding='utf8').replace('__SHOTS__',shots).replace('__DATA__',json.dumps(data,separators=(',',':')).replace('<','\\u003c')).replace('__MAP__',json.dumps(system,separators=(',',':')).replace('<','\\u003c')).replace('__INVENTORY__',json.dumps(inventory,separators=(',',':')).replace('<','\\u003c'));write(d/'index.html',guide)
write(r/'docs/obsidian/84-verified-procedures.md',f'''# Verified procedures · edition076

[[README-076|Edition076]] · [[docs/readmes/076/index.html|Offline evidence explorer]] · [[docs/obsidian/verified-procedures.canvas|System map]] · [[README-075|Previous075]]

Five typed Java procedures, three training sources, eight unfamiliar tasks and four unsupported controls. Fifteen training and forty-eight evaluation arms. Bank contains {len(study['bank'])} verified receipts; all training costs {study['trainingTicks']}ticks. Learned-selection qualification {qual}; no promotion. See README for actual comparative totals and limitations.

[[workspace-engine/src/main/java/fraymus/workspace/Procedure076.java|Procedures]] own exact fractions, shortest yaw, original authority, full-task checks and component ranking. [[workspace-engine/src/main/java/fraymus/workspace/ProcedureStudy076.java|Java runner]] owns training/freeze/retrieval/recovery. [[workspace-engine/src/main/java/fraymus/workspace/WorldFrames.java|Frames]] carry measured kinematics; contact solver remains cold. [[workspace-desktop/renderer/procedures076.js|Integrated panel]] displays real progress and read-only replay. [[scripts/Inspect-Procedures076.cjs|Independent inspector]] rechecks original arithmetic.

Preserve the first interrupted development study and all failed primary tasks. No evaluation ingestion, post-outcome retuning, native controller changes or new LLM inference. Next: clear intermediate waypoints, selective useful retrieval and typed durable-goal integration, each evaluated prospectively against simple control.
''')
nodes=[dict(id='readme',type='file',file='README-076.md',x=0,y=0,width=380,height=200)];edges=[]
for i,m in enumerate(mapping):
 nodes.append(dict(id=m['id'],type='file',file=m['source'],x=(i%3)*420,y=270+(i//3)*260,width=380,height=210));edges.append(dict(id='e'+str(i),fromNode='readme',fromSide='bottom',toNode=m['id'],toSide='top',label=m['name']))
js(r/'docs/obsidian/verified-procedures.canvas',dict(nodes=nodes,edges=edges))
print(json.dumps(dict(words=len(readme.split()),archives=len(archives),canonicalFiles=len(inventory),javaDistinct=v['javaDistinct'],readme='README-076.md',qualification=e['qualified'])))
