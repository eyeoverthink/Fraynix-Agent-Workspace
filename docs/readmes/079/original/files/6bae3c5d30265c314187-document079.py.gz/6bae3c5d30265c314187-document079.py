from pathlib import Path
import json,hashlib,gzip,subprocess,html,re,shutil,base64,xml.etree.ElementTree as ET
r=Path.cwd();d=r/'docs/readmes/079';out=r/'build/ui079-primary';d.mkdir(parents=True,exist_ok=True)
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8',newline='\n')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
record=load(out/'result.json');assert record['passed'];life=load(r/'build/ui079-lifecycle/result.json');assert life['passed'];analysis=load(r/'build/native-analysis079.json');tamper=load(r/'build/inspector-probes079.json');assert analysis['passed'] and tamper['passed'];e=analysis['summary'];source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();archives=[];archived=set()
def pack(p,dest):
 logical=dest.relative_to(r).as_posix();dest=d/'original/files'/(sha(logical.encode())[:20]+'-'+dest.name[-42:])
 if dest in archived:return
 archived.add(dest);b=p.read_bytes();z=gzip.compress(b,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archives.append(dict(path=dest.relative_to(r).as_posix(),bytes=len(z),sha256=sha(z),rawBytes=len(b),rawSha256=sha(b),source=str(p),logicalPath=logical))
for folder in sorted((r/'build').glob('ui079-*')):
 if not folder.is_dir():continue
 for p in sorted(folder.iterdir()):
  if p.is_file() and p.suffix in ['.json','.log','.txt','.png']:pack(p,d/'original'/folder.name/(p.name+'.gz'))
 checkpoint=folder/('result.json' if (folder/'result.json').exists() else 'checkpoint.json')
 if checkpoint.exists():
  project=Path(load(checkpoint)['project'])
  for dirname in ['world-procedures-079','persistent-worlds','goals','agency-043','creation-044','artifacts','receipts','runtime-042']:
   for p in sorted((project/dirname).rglob('*')):
    if p.is_file() and p.suffix in ['.json','.jsonl','.log','.html','.js','.css']:pack(p,d/'original'/folder.name/'project'/p.relative_to(project).with_suffix(p.suffix+'.gz'))
  for name in ['engine.log','events.jsonl','test-desktop-process.log']:
   p=project/name
   if p.exists():pack(p,d/'original'/folder.name/'project'/(name+'.gz'))
for p in sorted((r/'build/final-captures079').glob('*.json')):pack(p,d/'original/final-app'/(p.name+'.gz'))
for p in sorted((r/'build').glob('*079*.log')):pack(p,d/'original/logs'/(p.name+'.gz'))
cases={};invocations=[]
for folder in ['native079-first','native079-second','regression079-first','regression079','certificates079','recovery079-unit']:
 rows=[]
 for p in sorted((r/'build'/folder).glob('TEST-*.xml')):
  root=ET.parse(p).getroot()
  for c in root.findall('testcase'):
   key=c.attrib['classname']+'#'+c.attrib['name'];passed=all(c.find(n) is None for n in ['failure','error','skipped']);cases[key]=passed;rows.append(dict(case=key,passed=passed))
  pack(p,d/'original/java'/folder/(p.name+'.gz'))
  for loc in re.findall(r'(?:WORLD079_NATIVE|REBUILD079_NATIVE) ([^\r\n<]+)',p.read_text(encoding='utf8')):
   for f in Path(loc).rglob('*.json'):pack(f,d/'original/java'/folder/Path(loc).name/f.relative_to(loc).with_suffix('.json.gz'))
 if rows:invocations.append(dict(name=folder,cases=rows))
assert cases and all(cases.values()),'Latest result for every executed Java case must pass'
for name in ['current-extra079.json','native-analysis079.json','inspector-probes079.json','desktop079.json','unchanged-native079.json','regress079.ps1','document079.py','prepare-guide079.py','guide079.html','README-079-template.md','final-app079.json']:
 pack(r/'build'/name,d/'original/validation'/(name+'.gz'))
for folder in [out,r/'build/ui079-final-smoke',r/'build/ui079-lifecycle',r/'build/final-captures079']:
 for p in sorted(folder.glob('*.png')):
  if p.name!='failure.png':shutil.copyfile(p,d/p.name)
protocol=load(r/'workspace-engine/src/main/resources/procedures079-protocol.json');specs={s['id']:s for s in protocol['training']+protocol['cases']}
data=dict(evaluation=e,trainingTicks=e['trainingTicks'],trainingElapsedMillis=e['trainingMillis'],bank=record['frozenBank'],rows=[])
inputs=[dict(id=x['id'],split='training',results={'simple':x}) for x in record['training']]+[row for row in record['rows'] if row['split']=='unseen']
for row in inputs:
 entry=dict(id=row['id'],split=row['split'],spec=specs[row['id']],results={},replays={})
 for method,item in row['results'].items():
  x=load(out/item['originalFile']);a=item['job']['arm'];entry['results'][method]={**a,'status':item['status'],'reason':item['reason'],'decision':item['job']['decision'],'lookupMillis':item['job']['lookupMillis'],'completeWallMillis':item['wallMillis']};entry['replays'][method]=[]
  for packet in x['originals']:
   raw=gzip.decompress(base64.b64decode(packet['gzipBase64']));assert sha(raw)==packet['rawSha256'];run=json.loads(raw);attempt=next(t for t in a['attempts'] if t['id']==run['id']);n=len(run['samples']);indices=sorted(set(round(i*(n-1)/min(239,max(1,n-1))) for i in range(min(240,n))));frames=[dict(tick=run['samples'][i]['tick'],originalSampleIndex=i,bodies=[{k:b[k] for k in ['id','position','rotation']} for b in run['samples'][i]['bodies']]) for i in indices]
   entry['replays'][method].append(dict(id=run['id'],stage=attempt['stage'],family=attempt['family'],status=attempt['status'],definition=run['definition'],originalSampleCount=n,samples=frames,targets=run['plan']['intent']['targets'],waypoint=a['programs'][attempt['family']]['waypoints'][attempt['stage']]))
 data['rows'].append(entry)
write(d/'comparison-data.json',json.dumps(data,separators=(',',':'))+'\n')
paths={x['path'] for x in load(r/'docs/readmes/078/file-inventory.json')};paths.update(x for x in subprocess.check_output(['git','diff','--name-only','--diff-filter=A','06036bc','HEAD'],text=True).splitlines() if x.startswith(('workspace-engine/','workspace-desktop/','scripts/','fraynix-modules/')));inventory=[]
for name in sorted(paths):
 b=(r/name).read_bytes()
 try:b=b.decode('utf8').replace('\r\n','\n').encode();kind='utf8-lf'
 except UnicodeError:kind='binary'
 inventory.append(dict(path=name,bytes=len(b),hashKind=kind,sha256=sha(b)))
js(d/'file-inventory.json',inventory);write(d/'FILE_TREE.md','# Edition 079 complete source tree\n\n[Canonical bytes and hashes](file-inventory.json).\n\n```text\n'+'\n'.join(x['path'] for x in inventory)+'\n```\n')
v=dict(edition=79,source=source,contract='2cd7204',runtimeImplementation='b60a8f6',primarySource=record['source'],javaDistinct=len(cases),javaClasses=len({k.split('#')[0] for k in cases}),javaAllPassed=True,javaInvocations=invocations,desktop=load(r/'build/desktop079.json'),actualApp=record['checks'],lifecycle=life['checks'],finalApp=load(r/'build/final-app079.json'),finalRuntimeSmoke=load(r/'build/ui079-final-smoke/result.json')['checks'],finalRuntimeSource=load(r/'build/ui079-final-smoke/result.json')['source'],primaryNativeAttempts=sum(len(i['job']['arm']['attempts']) for row in inputs for i in row['results'].values()),analysis=analysis,tamper=tamper,currentNativeInspection=load(r/'build/current-extra079.json'),sourceIsolation=load(r/'build/unchanged-native079.json'),scope='Counterbalanced labelled native box tasks. The original physics solver, controllers and verifiers remain authoritative; a separate reader reconstructs arithmetic and provenance. Actual desktop chat/report/commit/restart tests, not new LLM inference, physical-camera accuracy or an independent physics solver.')
js(d/'verification.json',v);js(d/'original-evidence.json',dict(format='Exact originals, gzip compressed; paths identify isolated synthetic primary, lifecycle, smoke and unit-test sources. Failed invocations retained separately. No private production project.',files=archives))
modules=[('decision','Measured decision','Procedure079.java','Compare measured avoided work with proof cost and uncertainty.'),('targets','Current-world targets','Waypoints079.java','Bounded targets proposed from the actual starting frame.'),('runner','Durable procedure','WorldProcedure079.java','Own forecasts, distinct actual stages, bounded recovery and original evidence.'),('goal','Chat and saved skills','GoalRunner.java','Existing durable goal/host workflow, report checks and versioned skill reuse.'),('commit','Atomic world commit','WorldLedger.java','One verified revision per whole procedure; pending ownership on interruption.'),('export','Complete world history','WorldExport079.java','All stages and failed forecasts in original mixed-world exports.'),('inspect','Independent arithmetic','Inspect-Procedures079.cjs','Recompute original motion, cost choice, handoffs and proof provenance.')]
mapping=[dict(id=i,name=n,note='docs/obsidian/87-selective-world-goals.md',source=('scripts/' if p.endswith('.cjs') else 'workspace-engine/src/main/java/fraymus/workspace/')+p,description=t) for i,n,p,t in modules];system=dict(modules=mapping,screenshots=[dict(path='docs/readmes/079/'+p.name,label=p.stem) for p in sorted(d.glob('*.png'))],evidence=[dict(path=p) for p in ['docs/readmes/079/verification.json','docs/readmes/079/original-evidence.json','docs/EDITION_079_CONTRACT.md']]);js(d/'system-map.json',system)
m=e['methods'];fastest=min(m,key=lambda k:m[k]['wallMillis']);relation=f"Adaptive selected memory on {m['adaptive']['memoryLookups']}/8 tasks; always-memory selected it on {m['memory']['memoryLookups']}/8. Adaptive harmed {e['harmed']['simple']} tasks versus simple and {e['harmed']['memory']} versus memory. {fastest.capitalize()} had the lowest complete summed task time in this batch. The complete selective-benefit gate {'passed' if e['qualified'] else 'did not pass'}; the training-inclusive gate {'passed' if e['firstBatchEfficient'] else 'did not pass'}. Timing is one serial run on this machine, not a universal speed claim."
values=dict(QUALIFIED='PASSED' if e['qualified'] else 'NOT PASSED',BATCH='PASSED' if e['firstBatchEfficient'] else 'NOT PASSED',BANK=str(e['bankSize']),TRAIN_TICKS=f"{e['trainingTicks']:,}",TRAIN_WALL=f"{e['trainingMillis']/1000:.2f}",JAVA=str(v['javaDistinct']),CLASSES=str(v['javaClasses']),DESKTOP=str(v['desktop']['tests']),PROBES=str(len(tamper['probes'])),RELATION=relation,LIFECYCLE=' '.join(life['checks'])+'.',RESULTS='\n'.join(f"| {k} | {x['successes']}/8 | {x['ticks']:,} | {x['stages']} | {x['wallMillis']/1000:.2f} | {x['memoryLookups']}/8 |" for k,x in m.items()),CASES='\n'.join('| '+row['id']+' | '+' | '.join(row['results'][k]['status']+' / '+str(row['results'][k]['job']['arm']['chargedTicks'])+' ticks' for k in ['simple','memory','adaptive'])+' |' for row in record['rows'] if row['split']=='unseen'))
s=(r/'build/README-079-template.md').read_text(encoding='utf8')
for k,val in values.items():s=s.replace('__'+k+'__',val)
assert not re.search(r'__[A-Z_]+__',s);write(r/'README-079.md',s)
shots=''.join(f'<figure><a href="{html.escape(p.name)}"><img src="{html.escape(p.name)}" alt="Actual edition079 {html.escape(p.stem)}"></a><figcaption>{html.escape(p.stem)} · actual isolated app capture, November 6, 2026.</figcaption></figure>' for p in sorted(d.glob('*.png')))
s=(r/'build/guide079.html').read_text(encoding='utf8').replace('__SHOTS__',shots)
for key,obj in [('DATA',data),('MAP',system),('INVENTORY',inventory)]:s=s.replace('__'+key+'__',json.dumps(obj,separators=(',',':')).replace('<','\\u003c'))
write(d/'index.html',s)
write(r/'docs/obsidian/87-selective-world-goals.md',f"# Selective memory in continuing worlds · edition079\n\n[[README-079|Edition079]] · [[README-078|Previous078]] · [[docs/readmes/079/index.html|Offline evidence]] · [[docs/obsidian/selective-world-goals.canvas|System map]]\n\n{relation}\n\nChat binds current world → Java cost decision → isolated forecasts → distinct actual stages → original checks → actual canvas assertions → atomic commit → optional owned memory and versioned skill. Restart clears proof trust but preserves world and procedure. Stop cannot commit unfinished motion. Five fixed recipe families; no outcome retuning or evaluation ingestion. Training cost {e['trainingTicks']} ticks / {e['trainingMillis']/1000:.2f}s.\n\nThe exact known closed078 source can explicitly upgrade unchanged state; pending/unknown worlds refuse. Native identity deliberately changes because the ledger changes; original solver/controller/verifier computations remain unchanged.\n\nNext: calibrate predicted versus actual complete savings, preserve cheaper proof checks, broaden verified procedure tasks and connect uncertain real observations through the same durable contract.\n")
nodes=[dict(id='readme',type='file',file='README-079.md',x=0,y=0,width=380,height=200)];edges=[]
for i,m in enumerate(mapping):nodes.append(dict(id=m['id'],type='file',file=m['source'],x=(i%3)*420,y=270+(i//3)*260,width=380,height=210));edges.append(dict(id='e'+str(i),fromNode='readme',fromSide='bottom',toNode=m['id'],toSide='top',label=m['name']))
js(r/'docs/obsidian/selective-world-goals.canvas',dict(nodes=nodes,edges=edges));print(json.dumps(dict(archives=len(archives),canonicalFiles=len(inventory),javaDistinct=v['javaDistinct'],qualification=e['qualified'])))
