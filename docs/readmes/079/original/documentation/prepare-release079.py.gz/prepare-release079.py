from pathlib import Path
r=Path.cwd();old=r/'../fraynix-workspace-edition078/build'
for name in ['audit-publication078.py','release078.py','push-receipt078.py']:
 s=(old/name).read_text(encoding='utf8').replace('078','079').replace('86-proof-reuse','87-selective-world-goals').replace('proof-reuse.canvas','selective-world-goals.canvas').replace('byte-verified proof reuse, matched native outcomes and complete task costs','selective memory and durable verified chat-driven world goals')
 (r/'build'/name.replace('078','079')).write_text(s,encoding='utf8',newline='\n')
s=(old/'freeze078.py').read_text(encoding='utf8').replace('078','079').replace('7cb6071','06036bc').replace("manifest['latest']==77","manifest['latest']==78").replace('number=78','number=79').replace("manifest['latest']=78","manifest['latest']=79").replace('Byte-verified proof reuse and complete task costs','Selective memory in durable chat-driven world goals')
(r/'build/freeze079.py').write_text(s,encoding='utf8',newline='\n')
s=(old/'check-docs078.cjs').read_text(encoding='utf8').replace('078','079').replace('cached','adaptive').replace('15','11').replace("selectOption('two-stage')","selectOption('simple')").replace("fill('ProcedureStudy079')","fill('workspace-engine/src/main/java/fraymus/workspace/WorldProcedure079.java')")
# All displayed rows are actual supported/training procedures; refusal controls are listed separately.
(r/'build/check-docs079.cjs').write_text(s,encoding='utf8',newline='\n')
print('Publication and offline checks prepared; no publication performed.')
