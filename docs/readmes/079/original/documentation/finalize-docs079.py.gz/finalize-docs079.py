from pathlib import Path
import json,gzip,hashlib,re
r=Path.cwd();d=r/'docs/readmes/079'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,s):p.write_text(s,encoding='utf8',newline='\n')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
v=read(d/'verification.json');v['visualReview']=read(r/'build/visual-review079.json');v['offlineBrowser']=read(r/'build/browser-docs079.log');assert v['visualReview']['passed'] and v['offlineBrowser']['passed'];js(d/'verification.json',v);archive=read(d/'original-evidence.json')
for name in ['check-docs079.cjs','browser-docs079.log','visual-review079.json','finalize-docs079.py','prepare-release079.py','inspect079.log']:
 p=r/'build'/name
 if not p.exists():continue
 b=p.read_bytes();z=gzip.compress(b,mtime=0);dest=d/'original/documentation'/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archive['files'].append(dict(path=dest.relative_to(r).as_posix(),bytes=len(z),sha256=hashlib.sha256(z).hexdigest(),rawBytes=len(b),rawSha256=hashlib.sha256(b).hexdigest(),source=str(p)))
js(d/'original-evidence.json',archive)
e=v['analysis']['summary'];result='; '.join(f"{k}: {x['successes']}/8, {x['ticks']} ticks/{x['stages']} stages, {x['wallMillis']/1000:.2f}s complete" for k,x in e['methods'].items());scope=f"{v['javaDistinct']} distinct targeted Java checks/{v['javaClasses']} classes; {v['desktop']['tests']} desktop checks; actual primary chat/report/commit/skill/restart/export; separate moving-stage interruption/resume/Stop; {len(v['tamper']['probes'])} controlled altered-evidence probes. Actual app1600/1100 and offline1440/390. No new LLM inference or physical accuracy claim."
p=r/'README.md';s=p.read_text(encoding='utf8');a=s.index('> **[Edition 078');b=s.index('One integrated app,',a);write(p,s[:a]+f'''> **[Edition 079 · Selective memory in continuing worlds](README-079.md)** · [Offline guide](docs/readmes/079/index.html) · [Edition history](docs/readmes/INDEX.md)

Chat now connects cost-aware verified procedures to durable Java goals, actual native execution, persistent world commits and named saved skills. Selective-benefit qualification: **{e['qualified']}**; training-inclusive efficiency: **{e['firstBatchEfficient']}**. [Actual results, screenshots and complete evidence](README-079.md).

Edition 079 implementation, screenshots and original evidence are prepared for publication. [Previous fetched publication](docs/PUBLICATION_078.json).

'''+s[b:])
p=r/'docs/readmes/INDEX.md';s=p.read_text(encoding='utf8');i=s.index('\nLatest implementation');write(p,s[:i].rstrip()+'\n| [079](../../README-079.md) | 2026-11-06 | Selective memory in durable chat-driven world goals | [Viewer](079/index.html) · [tree](079/FILE_TREE.md) |\n'+s[i:].replace('**078**','**079**'))
p=r/'docs/obsidian/00-home.md';s=p.read_text(encoding='utf8').replace('edition_context: 078','edition_context: 079');s=re.sub(r'Current:.*?System map\]\]\.', 'Current: [[README-079|Edition 079 — selective memory and durable world goals]] ·\n[[docs/obsidian/87-selective-world-goals|Operation and next gates]] ·\n[[docs/obsidian/selective-world-goals.canvas|System map]].',s,count=1,flags=re.S);write(p,s)
entry=f'''## Edition 079 · Validated locally; publication next

Prospective contract2cd7204; original integrated implementationb60a8f6; actual primary source{v['primarySource']}. Five fixed families, three simple-control learning goals, frozen bank and eight unfamiliar tasks x three counterbalanced methods plus four unsupported controls. No policy/case/gate retuning after outcomes. New Java durable procedure uses current world observations, isolated forecasts, distinct actual stages, original checking, real canvas assertions and an atomic final world commit; owned memory and named skills retained only after success. Simple bypasses memory; adaptive subtracts proof cost and uncertainty from measured avoided work. Cold restart clears proof trust. Stop cannot commit, unknown interrupted tail charged in full, at most two explicit native resumes.

{result}. Selective benefit {e['qualified']}; first-batch efficiency with training {e['firstBatchEfficient']}. Training {e['trainingTicks']}ticks / {e['trainingMillis']/1000:.2f}s, bank{e['bankSize']}. No automatic promotion, evaluation ingestion or model-weight training. {scope}

Original native solver/controller/verifier/WorldFrames unchanged. WorldLedger source identity intentionally changes for atomic commit. Explicit exact closed078 compatibility handoff preserves frame; pending/unknown worlds refuse. Exact kinematic handoffs do not restore continuous contact manifolds. All failed reader/storage/parser/layout invocations retained with corrections. Independent reader checks original bytes, arithmetic, handoffs, decisions, full proof provenance and world commits; Java reconstructs geometric search. Synthetic lifted-box tasks, not physical robotics calibration.

README079, actual screenshots, offline interactive replays, complete source inventory, original archives and Obsidian87/canvas prepared. Push main/edition079/readme-079 and fetch verification next; not yet claimed. Preserve frozen001–078, normal045/qa046/private data/services. No subagents/overlapping heavy work; Java21/four CPUs/768MB. Next: calibrate expected versus actual complete savings, amortization across longer goals, broader verified procedures and uncertain real observations through the same durable world contract.

'''
for name in ['AGENTS.md','docs/PROJECT_MEMORY.md','docs/DEVELOPMENT_LOG.md']:
 p=r/name;s=p.read_text(encoding='utf8');i=s.index('\n');write(p,s[:i+1]+'\n'+entry+s[i+1:])
p=r/'docs/ARCHITECTURE.md';s=p.read_text(encoding='utf8');i=s.index('\n');write(p,s[:i+1]+'''\n## Current edition079: selective memory and durable world goals

[Edition079](../README-079.md) connects chat and saved skills to the existing Java goal runner. `Procedure079` owns cost decisions/current-frame task checks; `Waypoints079` proposes bounded targets; `WorldProcedure079` owns staged native forecasts, distinct actual execution, evidence, bounded recovery and memory. Existing host checks verify the actual report. `WorldLedger` commits one measured final revision; `WorldExport079` preserves all stages. Owned exact-byte proof trust is boot-local; skills and verified worlds persist. The frozen unfamiliar-task comparison measures whole-task costs against simple and always-memory controls. See the current README for results and qualified limits.

'''+s[i+1:].replace('## Current edition078: verified proof reuse','## Edition078 foundation: verified proof reuse'))
print('Current documentation and notes prepared; publication next.')
