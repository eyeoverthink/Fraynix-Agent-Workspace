const {launch}=require('../workspace-desktop/test/calibration-integration.cjs');
const fs=require('node:fs/promises'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{
 const out=path.resolve(__dirname,'../workspace-desktop/test-output');
 const record=JSON.parse(await fs.readFile(path.join(out,'construction057-live.json'),'utf8'));
 assert(record.passed);process.env.FRAYNIX_WORKSPACE_PERSISTENT='0';
 const {app,page}=await launch(record.project);
 try{
  await app.evaluate((_,id)=>global.workspaceTest.execute('canvas.open',{id}),record.first.report.id);
  await page.locator('#preview-tab').click();await page.locator('#expand-canvas').click();
  await page.waitForFunction(()=>document.querySelector('#preview-tab').classList.contains('selected')&&!document.querySelector('#canvas-surface').hidden&&document.body.classList.contains('canvas-focus'));
  const capture=async name=>{await new Promise(r=>setTimeout(r,250));await fs.writeFile(path.join(out,'construction057-'+name+'.png'),Buffer.from(await app.evaluate(()=>global.workspaceTest.capture()),'base64'));};
  const selected=await app.evaluate(()=>global.workspaceTest.canvasRead(`(()=>{const select=document.querySelector('#payload057-case');select.value='payload-edge-impact';select.dispatchEvent(new Event('change'));const time=document.querySelector('#payload057-time');time.value=119;time.dispatchEvent(new Event('input'));document.querySelector('#payload057-scene').scrollIntoView({block:'center'});return{caseId:select.value,tick:Number(document.querySelector('#payload057-scene').dataset.tick),curves:document.querySelectorAll('.payload057-curve').length,rows:document.querySelectorAll('#payload057-table tbody tr').length};})()`));
  assert.equal(selected.tick,1440);assert.equal(selected.curves,11);assert.equal(selected.rows,7);await capture('replay-edge');
  await app.evaluate(()=>global.workspaceTest.canvasRead("document.querySelector('#payload057-table').scrollIntoView({block:'center'});true"));await capture('report');
  await fs.writeFile(path.join(out,'construction057-visible-report.json'),JSON.stringify({passed:true,source:require('node:child_process').execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),project:record.project,selected,visibleCanvas:true,worldId:record.worldId,report:record.first.report},null,2));
  console.log(JSON.stringify({passed:true,selected}));
 }finally{await app.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
