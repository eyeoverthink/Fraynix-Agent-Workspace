from pathlib import Path
p=Path('workspace-engine/src/main/java/fraymus/workspace/CounterfactualReport045.java');s=p.read_text(encoding='utf8');start=s.index('if(data.has("payload057"))');end=s.index('out.getJSONArray("sources")',start);s=s[:start]+s[start:end].replace('manifest','payloadManifest')+s[end:];p.write_text(s,encoding='utf8')
