from pathlib import Path
p=Path('workspace-engine/src/main/java/fraymus/workspace/Payload057.java');s=p.read_text(encoding='utf8');a=s.index('    private static void save(Path path,JSONObject d)throws Exception {');b=s.index('    static JSONObject specification',a)
s=s[:a]+'''    private static void save(Path path,JSONObject d)throws Exception {
        Files.createDirectories(path.getParent());Path pending=path.resolveSibling(path.getFileName()+"."+UUID.randomUUID()+".pending");
        try(var channel=java.nio.channels.FileChannel.open(pending,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE)){
            var writer=new java.io.BufferedWriter(java.nio.channels.Channels.newWriter(channel,StandardCharsets.UTF_8),65536);
            new JSONObject().put("format","java-agent-042-v1").put("sha256",evidenceHash(d)).put("data",d).write(writer);writer.flush();channel.force(true);
            if(channel.size()>protocol().getInt("maxBytes"))throw new IllegalStateException("Payload history exceeds64MB; previous and pending originals retained");
        }
        for(int retry=0;;retry++){try{Files.move(pending,path,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);break;}catch(AccessDeniedException denied){if(retry>=5)throw denied;Thread.sleep(25L<<retry);}}
    }
'''+s[b:];p.write_text(s,encoding='utf8')
