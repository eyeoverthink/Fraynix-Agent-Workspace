from pathlib import Path
p=Path('workspace-engine/src/main/java/fraymus/workspace/GoalRunner.java');s=p.read_text(encoding='utf8')
s=s.replace('loadRoot055,loadRoot056;', 'loadRoot055,loadRoot056,payloadRoot057;').replace('this.loadRoot055=project.resolve("load-055");','this.payloadRoot057=project.resolve("payload-057");this.loadRoot055=project.resolve("load-055");')
s=s.replace('"directFirst055","loadTests055"','"directFirst055","loadTests055","payloadTests057"')
s=s.replace('"loadTests055","loadDesign056"','"loadTests055","payloadTests057","loadDesign056"')
s=s.replace('"payloadTests057","load055"','"payloadTests057","payload057","load055"')
# Preserve changed policy identity when a retained diagnostic procedure is reused.
needle='if(p.getJSONObject("defaults").optBoolean("design053")&&!p.optString("counterfactualCodeSha256").equals(Counterfactual045.code()))'
s=s.replace(needle,'if(p.getJSONObject("defaults").optBoolean("payloadTests057")&&(!p.has("payloadPolicy057")||!p.getJSONObject("payloadPolicy057").similar(Payload057.policy())))throw new IllegalStateException("Saved payload protocol changed; review a new procedure version");'+needle)
s=s.replace('if(input.optBoolean("loadTests055"))g.put("loadTests055",true);','if(input.optBoolean("loadTests055"))g.put("loadTests055",true);if(input.optBoolean("payloadTests057"))g.put("payloadTests057",true);')
s=s.replace('if(!loads055(g,r)||!loads056(g,r))return;','if(!loads055(g,r)||!loads056(g,r)||!payloads057(g,r))return;')
s=s.replace('g.has("load056")?exportLoad056(g.getString("id")):null)', 'g.has("load056")?exportLoad056(g.getString("id")):null,g.has("payload057")?Payload057.original(payloadRoot057,r):null)')
needle='if(g.optBoolean("loadTests055")&&!g.has("load055"))'
s=s.replace(needle,'if(g.optBoolean("payloadTests057")&&(!g.has("payload057")||!g.getJSONObject("payload057").getBoolean("complete")||!g.getJSONObject("payload057").getBoolean("repeatable")))throw new IllegalStateException("Payload experiments are unfinished or repeats disagree");'+needle)
start=s.index('    private JSONObject counterData055(');end=s.index('\n',start);line=s[start:end];assert line.endswith('return d;}')
line=line[:-len('return d;}')]+'''if(g.has("payload057")){var payload=Payload057.read(payloadRoot057,run);if(!payload.similar(g.getJSONObject("payload057")))throw new IllegalStateException("Retained payload evidence changed");var original=Payload057.original(payloadRoot057,run);d.remove("dataSha256");d.put("payload057",payload).put("payload057File",new JSONObject().put("rawSha256",original.getString("rawSha256")).put("rawBytes",original.getInt("rawBytes")));long prior=d.has("measuredWork056")?d.getJSONObject("measuredWork056").getLong("totalTicks"):d.getJSONObject("baseline054").getLong("comparisonPlusExecutionTicks")+(g.has("load055")?g.getJSONObject("load055").getLong("totalTicks"):0);d.put("measuredWork057",new JSONObject().put("priorAssemblyAndLoadTicks",prior).put("payloadAndPositionTicks",payload.getLong("totalTicks")).put("totalTicks",prior+payload.getLong("totalTicks"))).put("dataSha256",WorldFrames.hash(d));}return d;}'''
s=s[:start]+line+s[end:]
insert='''    private boolean payloads057(JSONObject g,JSONObject run)throws Exception {
        if(!g.optBoolean("payloadTests057")||g.has("payload057"))return true;
        if(geometryFuture==null){geometryGoal=g.getString("id");var original=WorldFrames.copy(run);geometryFuture=geometryWorker.submit(()->Payload057.evaluate(payloadRoot057,original,()->Thread.currentThread().isInterrupted()));change(g,"world-report","Testing actual falling payload bodies and new force positions; failed cases remain diagnostic evidence");return false;}
        if(!geometryGoal.equals(g.getString("id")))throw new IllegalStateException("Foreign payload experiment");if(!geometryFuture.isDone())return false;var result=geometryFuture.get();geometryFuture=null;geometryGoal="";if(!result.getBoolean("complete")||!result.getBoolean("repeatable"))throw new IllegalStateException("Payload experiments incomplete or repeats disagree; originals retained");g.put("payload057",result);save("goal",g);g.getJSONObject("counterfactual045").put("data",counterData055(g,run));save("goal",g);return true;
    }
    public synchronized JSONObject exportPayload057(String id)throws Exception {var g=read(id);if(!g.optBoolean("payloadTests057")||!g.has("runId"))throw new IllegalStateException("This task has no payload experiment");var run=worldNative.run(g.getString("runId"));var out=new JSONObject().put("format","fraynix.payload-study-057-v1").put("goalId",id).put("original",Payload057.original(payloadRoot057,run));if(g.has("payload057"))out.put("results",Payload057.read(payloadRoot057,run));return out;}
'''
s=s.replace('    public synchronized JSONObject exportLoad056',insert+'    public synchronized JSONObject exportLoad056')
needle='if(g.optBoolean("loadDesign056")){p.getJSONObject("defaults")'
s=s.replace(needle,'if(g.optBoolean("payloadTests057"))p.put("payloadPolicy057",Payload057.policy()).put("payload057",g.getJSONObject("payload057"));'+needle)
# The procedure action describes diagnostic completion rather than a universal load pass.
needle='save("procedure",p);return new JSONObject().put("id",id).put("name",name).put("version",version);'
s=s.replace(needle,'if(g.optBoolean("payloadTests057"))p.getJSONArray("actions").put("Run actual dynamic payloads and new force positions; retain failures and repeats; verify original report and replay before completion");'+needle)
p.write_text(s,encoding='utf8')
p=Path('workspace-engine/src/main/java/fraymus/workspace/CounterfactualReport045.java');s=p.read_text(encoding='utf8')
needle='static JSONObject build(JSONObject actual,JSONObject data,JSONArray attempts,JSONObject envelopes){';assert needle in s
s=s.replace(needle,needle+'return build(actual,data,attempts,envelopes,null);}\n    static JSONObject build(JSONObject actual,JSONObject data,JSONArray attempts,JSONObject envelopes,JSONObject payloadOriginal){')
s=s.replace('out.getJSONArray("sources").put("counterfactual-decision:"','if(data.has("payload057")){var manifest=data.getJSONObject("payload057File");if(payloadOriginal==null||!manifest.getString("rawSha256").equals(payloadOriginal.getString("rawSha256"))||manifest.getInt("rawBytes")!=payloadOriginal.getInt("rawBytes"))throw new IllegalStateException("Payload original file differs");PayloadReport057.add(files,data.getJSONObject("payload057"),payloadOriginal);}out.getJSONArray("sources").put("counterfactual-decision:"')
needle='if(!Double.isFinite(error)||error>.002)';assert needle in s
s=s.replace(needle,'if(d.has("payload057"))PayloadReport057.verify(d.getJSONObject("payload057"),view.getJSONObject("payload057"));'+needle)
s=s.replace("$('cf045-status').textContent=d.comparison.passed", "if(d.measuredWork057){const w=d.measuredWork057,p=document.createElement('p');p.textContent='Complete task: '+w.totalTicks+' native ticks = '+w.priorAssemblyAndLoadTicks+' prior assembly/load ticks + '+w.payloadAndPositionTicks+' payload/position ticks, including retained interrupted work.';$('payload057-section').append(p);}$('cf045-status').textContent=d.comparison.passed")
p.write_text(s,encoding='utf8')
p=Path('workspace-engine/src/main/java/fraymus/workspace/WorkspaceStore.java');s=p.read_text(encoding='utf8');needle='synchronized JSONObject writeCounterfactualWorldOnce(String key,JSONObject run,JSONObject data,JSONArray attempts,JSONObject envelopes)throws IOException{';assert needle in s
s=s.replace(needle,needle+'return writeCounterfactualWorldOnce(key,run,data,attempts,envelopes,null);}\n    synchronized JSONObject writeCounterfactualWorldOnce(String key,JSONObject run,JSONObject data,JSONArray attempts,JSONObject envelopes,JSONObject payloadOriginal)throws IOException{')
s=s.replace('CounterfactualReport045.build(run,data,attempts,envelopes),data.has("load056")?8_000_000:4_000_000,data.has("load056")?32_000_000:20_000_000','CounterfactualReport045.build(run,data,attempts,envelopes,payloadOriginal),(data.has("load056")||data.has("payload057"))?8_000_000:4_000_000,(data.has("load056")||data.has("payload057"))?32_000_000:20_000_000')
p.write_text(s,encoding='utf8')
p=Path('workspace-engine/src/main/java/fraymus/workspace/Counterfactual045.java');s=p.read_text(encoding='utf8').replace('Design056.class,Load056.class','Design056.class,Load056.class,Payload057.class,PayloadReport057.class');p.write_text(s,encoding='utf8')
p=Path('workspace-engine/src/main/java/fraymus/workspace/WorkspaceServer.java');s=p.read_text(encoding='utf8').replace('case "/api/construction056/load-export"','case "/api/construction057/payload-export" -> {SpatialScene.keys(input,"id");result=goals.exportPayload057(input.getString("id"));}\n                    case "/api/construction056/load-export"');p.write_text(s,encoding='utf8')
