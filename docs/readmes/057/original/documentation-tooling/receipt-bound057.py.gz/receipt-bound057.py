from pathlib import Path
p=Path('workspace-engine/src/main/java/fraymus/workspace/WorkspaceServer.java');s=p.read_text(encoding='utf8').replace('exchange.getRequestURI().getPath().equals("/api/agency043/frame")?8_100_000:2_100_000','Set.of("/api/agency043/frame","/api/goals/ack").contains(exchange.getRequestURI().getPath())?8_100_000:2_100_000');p.write_text(s,encoding='utf8')
