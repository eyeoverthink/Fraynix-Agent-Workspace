from pathlib import Path
import subprocess
files=subprocess.check_output(['git','diff','--name-only']).decode().splitlines()
for name in files:
 p=Path(name);s=p.read_text(encoding='utf8');original=subprocess.check_output(['git','show','HEAD:'+name]).decode('utf8')
 for ch in set(original):
  if ord(ch)<128:continue
  try:bad=ch.encode('utf8').decode('cp1252')
  except UnicodeDecodeError:continue
  s=s.replace(bad,ch)
 p.write_text(s,encoding='utf8')
p=Path('build/finish-integration057.py');s=p.read_text(encoding='utf8').replace('.read_text()',".read_text(encoding='utf8')");p.write_text(s,encoding='utf8')
