from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).resolve().parent.parent;d=r/'docs/readmes/057'
def canon(p):return p.read_text(encoding='utf8').replace('\r\n','\n').encode()
snap=[]
for p in sorted(d.rglob('*')):
 if p.is_file():
  binary=p.suffix in ['.png','.jpg','.gz','.zip']
  snap.append({'path':p.relative_to(r).as_posix(),'kind':'binary' if binary else 'text','sha256':hashlib.sha256(p.read_bytes() if binary else canon(p)).hexdigest()})
p=r/'docs/readmes/editions.json';m=json.loads(p.read_text(encoding='utf8'));assert m['latest'] in [56,57]
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
e={'number':57,'date':'2026-11-03','title':'Dynamic payloads and new load positions','status':'validated-local','markdown':'README-057.md','markdownSha256':hashlib.sha256(canon(r/'README-057.md')).hexdigest(),'companion':'docs/readmes/057/index.html','tag':'readme-057','sourceBaseline':source,'snapshotDirectory':'docs/readmes/057','snapshotFiles':snap}
m['editions']=[x for x in m['editions'] if x['number']!=57]+[e];m['latest']=57;p.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n',encoding='utf8');print('Frozen',len(snap),'new snapshot files; earlier entries unchanged')
