from pathlib import Path
import json,gzip,hashlib,re
r=Path.cwd();d=r/'docs/readmes/081'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,s):p.write_text(s,encoding='utf8',newline='\n')
def js(p,v):write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
v=read(d/'verification.json');v['visualReview']=read(r/'build/visual-review081.json');v['offlineBrowser']=read(r/'build/browser-docs081.log');assert v['visualReview']['passed'] and v['offlineBrowser']['passed'];js(d/'verification.json',v);archive=read(d/'original-evidence.json')
for name in ['check-docs081.cjs','browser-docs081.log','visual-review081.json','finalize-docs081.py','recapture-docs081.cjs','recapture-docs081.log']:
 p=r/'build'/name;b=p.read_bytes();z=gzip.compress(b,mtime=0);dest=d/'original/documentation'/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z);archive['files'].append(dict(path=dest.relative_to(r).as_posix(),bytes=len(z),sha256=hashlib.sha256(z).hexdigest(),rawBytes=len(b),rawSha256=hashlib.sha256(b).hexdigest(),source=str(p)))
js(d/'original-evidence.json',archive)
e=v['analysis']['summary'];result='; '.join(f"{k}: {x['successes']}/8, {x['ticks']} ticks/{x['stages']} stages, {x['completeMillis']/1000:.2f}s complete, {x['callerMillis']/1000:.2f}s caller, {x['estimationMillis']/1000:.3f}s estimation, {x['loads']} evidence loads / {x['verifiedBytes']} verified bytes" for k,x in e['methods'].items())
scope=f"{v['javaDistinct']} Java checks/{v['javaClasses']} classes; {v['desktop']['tests']} desktop checks; actual primary/chat/report/export/skill/cold restart, separate interruption/resume/Stop, {len(v['tamper']['probes'])} independent altered-evidence probes and sixteen actual Java API source faults across both readers. Actual app1600/1100 and offline1440/390. No new physical accuracy or model-weight learning claim."
p=r/'README.md';s=p.read_text(encoding='utf8');a=s.index('> **[Edition 080');b=s.index('One integrated app,',a);write(p,s[:a]+f'''> **[Edition 081 · Faster estimation with complete evidence checks](README-081.md)** · [Offline guide](docs/readmes/081/index.html) · [Edition history](docs/readmes/INDEX.md)

Two bounded Java readers check the same original calibration evidence. Estimation overhead reduction: **{e['estimationReductionPercent']:.1f}%**; complete-task reduction: **{e['completeReductionPercent']:.2f}%** in eight controlled pairs. Identical decisions, native work and final states; original verification retained. [Actual results, screenshots and evidence](README-081.md).

Edition 081 implementation, screenshots and original evidence are prepared for publication. [Previous fetched publication](docs/PUBLICATION_080.json).

'''+s[b:])
p=r/'docs/readmes/INDEX.md';s=p.read_text(encoding='utf8');i=s.index('\nLatest implementation');write(p,s[:i].rstrip()+'\n| [081](../../README-081.md) | 2026-11-06 | Faster estimation with complete evidence checks | [Viewer](081/index.html) · [tree](081/FILE_TREE.md) |\n'+s[i:].replace('**080**','**081**'))
p=r/'docs/obsidian/00-home.md';s=p.read_text(encoding='utf8').replace('edition_context: 080','edition_context: 081');s=re.sub(r'Current:.*?System map\]\]\.', 'Current: [[README-081|Edition 081 — faster estimation, complete evidence]] ·\n[[docs/obsidian/89-calibration-evidence|Operation and next gates]] ·\n[[docs/obsidian/calibration-evidence.canvas|System map]].',s,count=1,flags=re.S);write(p,s)
entry=f'''## Edition 081 · Validated locally; publication next

Contracte825734, parentb121e65; primary source{v['primarySource']}. Read-only080 profile:334–400ms hashing149743387bytes/load. Two bounded Java readers use original ProofMemo078 snapshots; one batch in flight, every byte reread, all readers joined before comparison or refusal, no timestamp shortcut or trust cache. Pair arithmetic, TaskCost080, physics/controller/native verification and WorldLedger unchanged. Current procedure identity includes CalibrationScan081; older proofs cannot authorize the new implementation. Serial reference is isolated-test-only.

{result}. Estimation reduction {e['estimationReductionPercent']:.2f}%; separate six-repeat reader reduction {e['microReductionPercent']:.2f}%; complete-task reduction {e['completeReductionPercent']:.2f}% (faster={e['completeTaskFaster']}). Decisions, native work and final frames identical. Three learning tasks, four calibration pairs, six regression and two prospective mass/friction cases x two counterbalanced readers; four unsupported controls. Bank/model frozen. Learning {e['trainingMillis']/1000:.2f}s; calibration+fit {e['calibrationMillis']/1000:.2f}s. One machine, no retuning or general performance claim.

{scope}

Java complete-task timing includes original native execution/checks, real host-report checks, world commit and requested retention; final timing write/caller transport outside, caller elapsed separate. Reader stats captured before export. Every successful load checks the same bytes. Interrupted/resumed clocks remain ineligible. Existing private normal045/qa046 and data/services preserved. README081, real captures, offline charts/replays, complete source/raw evidence, Obsidian89/map and notes prepared. Push and fetch main/edition081/readme-081 next; not yet claimed. Preserve numbered001–080. No subagents or heavy overlap. Next: repeated resource-budget measurements, cold/retention workloads, longer sequences and amortization.

'''
for name in ['AGENTS.md','docs/PROJECT_MEMORY.md','docs/DEVELOPMENT_LOG.md']:
 p=r/name;s=p.read_text(encoding='utf8');i=s.index('\n');write(p,s[:i+1]+'\n'+entry+s[i+1:])
p=r/'docs/ARCHITECTURE.md';s=p.read_text(encoding='utf8');i=s.index('\n');write(p,s[:i+1]+'''
## Current edition081: bounded parallel calibration evidence

[Edition081](../README-081.md) keeps the existing selection and outcome authority. `CalibrationScan081` uses two Java readers to run original `ProofMemo078.snapshot` checks; `WorldProcedure079` joins them before comparing ordered evidence, retaining implementation and paired-cost arithmetic checks at all existing boundaries. One batch in flight, no persistent trust or timestamp shortcut. Failed or interrupted reads cannot authorize an estimate. Operational diagnostics measure loads, elapsed loader/hash time, failures and successfully verified bytes; they do not replace physical evidence. Normal runtime uses two readers, with an isolated-test-only serial comparison. Complete-task timings and original physics/controller/verifier/WorldLedger behavior are unchanged.

'''+s[i+1:].replace('## Current edition080:','## Edition080 foundation:'))
print('Current documentation and continuity prepared; publication next.')
