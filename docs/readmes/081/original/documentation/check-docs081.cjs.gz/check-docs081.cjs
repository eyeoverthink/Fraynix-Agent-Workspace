'use strict';
const {chromium}=require('../workspace-desktop/node_modules/playwright');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{pathToFileURL,fileURLToPath}=require('node:url');
(async()=>{
 const d=path.resolve('docs/readmes/081'),data=JSON.parse(fs.readFileSync(path.join(d,'comparison-data.json'),'utf8')),b=await chromium.launch({channel:'msedge',headless:true}),checks=[],errors=[];
 try{for(const width of [1440,390]){
  const p=await b.newPage({viewport:{width,height:1000}});p.on('pageerror',e=>errors.push(e.message));await p.goto(pathToFileURL(path.join(d,'index.html')).href);
  await p.waitForFunction(()=>document.images.length>=5&&[...document.images].every(i=>i.complete&&i.naturalWidth>0));assert.equal(await p.locator('#case option').count(),data.rows.length);
  assert((await p.locator('#status').innerText()).includes('Estimation improvement: '+(data.evaluation.estimationImproved?'PASSED':'NOT PASSED')));
  for(const metric of ['callerMillis','ticks','completeMillis']){await p.locator('#metric').selectOption(metric);assert.equal(await p.locator('#cost').getAttribute('data-metric'),metric);const plain=await p.locator('#cost').textContent();await p.locator('#training').check();assert.equal(await p.locator('#cost').getAttribute('data-training'),'true');assert.notEqual(await p.locator('#cost').textContent(),plain);await p.locator('#training').uncheck();assert.equal(await p.locator('#cost').textContent(),plain);}
  assert.equal(await p.locator('#estimate-table tr').count(),9);assert.equal(await p.locator('#errors circle').count(),16);
  let stages=0;
  for(let i=0;i<data.rows.length;i++){
   await p.locator('#case').selectOption(String(i));const row=data.rows[i];
   for(const method of Object.keys(row.results)){
    await p.locator('#method').selectOption(method);assert.equal(await p.locator('#attempt option').count(),row.replays[method].length);
    for(let k=0;k<row.replays[method].length;k++){
     await p.locator('#attempt').selectOption(String(k));const run=row.replays[method][k];stages++;
     for(const frame of [0,Math.floor(run.samples.length/2),run.samples.length-1]){
      await p.locator('#frame').fill(String(frame));await p.locator('#frame').dispatchEvent('input');const f=run.samples[frame];assert.equal(await p.locator('#scene').getAttribute('data-run-id'),run.id);assert.equal(+(await p.locator('#scene').getAttribute('data-tick')),f.tick);assert((await p.locator('#frame-info').innerText()).includes('original sample '+(f.originalSampleIndex+1)+'/'));
      const a=run.definition.objects.find(o=>o.sourceId==='A'),body=f.bodies.find(x=>x.id===a.id),rendered=await p.locator('#scene rect').first().getAttribute('x');const first=run.definition.objects.find(o=>o.sourceId!=='floor');if(first.sourceId==='A')assert(Math.abs(+rendered-(275+body.position[0]*36-a.size[0]*18))<1e-8);
     }
    }
   }
  }
  await p.locator('#case').selectOption('0');await p.locator('#method').selectOption('simple');await p.locator('#attempt').selectOption('0');await p.locator('#play').click();await p.waitForFunction(()=>+document.querySelector('#frame').value>2);await p.locator('#play').click();const paused=await p.locator('#frame').inputValue();await p.waitForTimeout(180);assert.equal(await p.locator('#frame').inputValue(),paused);
  await p.locator('#map button').last().click();assert((await p.locator('#module-source').getAttribute('href')).includes('Inspect-Procedures081.cjs'));await p.locator('#filter').fill('workspace-engine/src/main/java/fraymus/workspace/CalibrationScan081.java');assert.equal(await p.locator('#files li').count(),1);
  assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));for(const id of ['scene','trajectory','errors','cost'])assert(await p.locator('#'+id).evaluate(s=>[...s.querySelectorAll('text')].every(t=>s.clientWidth/s.viewBox.baseVal.width*parseFloat(getComputedStyle(t).fontSize)>=12)),id+' readable');
  for(const href of await p.locator('a[href]').evaluateAll(es=>es.map(e=>e.href))){if(href.startsWith('file:')){const u=new URL(href);u.hash='';assert(fs.existsSync(fileURLToPath(u)),href);}}
  for(const section of ['results','estimates','replay']){await p.locator('#'+section).scrollIntoViewIfNeeded();await p.screenshot({path:path.join(d,'offline-'+section+'-'+width+'.png')});}
  checks.push({width,cases:data.rows.length,stages,allMethodsAndAttempts:true,initialMiddleFinalOriginalPoses:true,playPause:true,trainingToggle:true,allCostMetrics:true,estimates:true,mapFilterLinksImages:true,noHorizontalOverflow:true,minimumChartText12Pixels:true});await p.close();
 }assert.deepEqual(errors,[]);console.log(JSON.stringify({passed:true,checks,errors},null,2));}finally{await b.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
