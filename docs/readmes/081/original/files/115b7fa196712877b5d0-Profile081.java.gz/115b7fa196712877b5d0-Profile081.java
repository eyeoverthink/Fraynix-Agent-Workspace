package fraymus.workspace;
import java.nio.file.*;
import java.util.*;
import org.json.*;
/** Read-only diagnosis of original 080 calibration costs. Does not authorize a current action. */
public class Profile081 {
 public static void main(String[] args)throws Exception {
  Path root=Path.of(args[0]).resolve("world-procedures-079");
  String id=AgentFiles042.loadChecked(root.resolve("cost-model080.json")).getString("id");
  var model=AgentFiles042.loadChecked(root.resolve("cost-models080").resolve(id+".json"));
  var jobs=new HashMap<String,JSONObject>();for(String g:model.getJSONObject("evidence").keySet())jobs.put(g,AgentFiles042.loadChecked(root.resolve(g).resolve("goal.json")));
  var proof=new ProofMemo078(root);var runs=new JSONArray();
  for(int n=0;n<4;n++) {
   double parse=0,arithmetic=0,pathsMs=0,hash=0;long bytes=0,start=System.nanoTime();
   long at=System.nanoTime();var m=AgentFiles042.loadChecked(root.resolve("cost-models080").resolve(id+".json"));double modelMs=(System.nanoTime()-at)/1e6;
   var pairs=new JSONArray();for(Object raw:m.getJSONArray("pairs")){
    var pair=(JSONObject)raw;String a=pair.getString("simpleId"),b=pair.getString("memoryId");at=System.nanoTime();
    var ca=AgentFiles042.loadChecked(root.resolve(a).resolve("cost080.json"));var cb=AgentFiles042.loadChecked(root.resolve(b).resolve("cost080.json"));parse+=(System.nanoTime()-at)/1e6;
    at=System.nanoTime();pairs.put(TaskCost080.pair(ca,cb));arithmetic+=(System.nanoTime()-at)/1e6;
    for(String g:List.of(a,b)){
     at=System.nanoTime();var j=WorldFrames.copy(jobs.get(g));var ps=new ArrayList<Path>();ps.add(root.resolve(g).resolve("cost080.json"));ps.add(root.resolve(g).resolve("goal.json"));
     for(Object t:j.getJSONObject("arm").getJSONArray("attempts")){var t1=(JSONObject)t;if(t1.has("sha256"))ps.add(root.resolve(g).resolve("attempts").resolve(t1.getString("id")).resolve("original.json"));}
     pathsMs+=(System.nanoTime()-at)/1e6;at=System.nanoTime();var snap=proof.snapshot(ps);hash+=(System.nanoTime()-at)/1e6;
     if(!snap.similar(m.getJSONObject("evidence").getJSONArray(g)))throw new IllegalStateException("Original changed");for(Object s:snap)bytes+=((JSONObject)s).getLong("bytes");
    }
   }
   if(!pairs.similar(m.getJSONArray("pairs")))throw new IllegalStateException("Arithmetic changed");
   runs.put(new JSONObject().put("iteration",n).put("modelMillis",modelMs).put("costParseCheckMillis",parse).put("pairMillis",arithmetic).put("jobCopyPathsMillis",pathsMs).put("evidenceMillis",hash).put("evidenceBytes",bytes).put("totalMillis",(System.nanoTime()-start)/1e6));
  }
  System.out.println(new JSONObject().put("scope","Read-only original 080 data, no current engine compatibility or action claim").put("sourceCode",model.getString("code")).put("runs",runs).toString(2));
 }
}
