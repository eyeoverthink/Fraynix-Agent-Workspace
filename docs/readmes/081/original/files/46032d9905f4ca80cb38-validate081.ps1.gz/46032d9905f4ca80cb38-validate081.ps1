$ErrorActionPreference='Stop'
$env:JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.10.7-hotspot'
$env:JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=4 -Xmx768m'
$env:PATH=$env:JAVA_HOME+'/bin;'+$env:PATH
$result=Get-Content -LiteralPath build/ui081-primary/result.json -Raw | ConvertFrom-Json
if(-not $result.passed){throw 'Primary study did not pass.'}
Push-Location workspace-desktop
try {
 & node test/procedures081-faults.cjs *> ../build/faults081.log
 if($LASTEXITCODE){throw 'Fault validation failed; original logs retained.'}
 & node test/procedures081-lifecycle.cjs *> ../build/lifecycle081.log
 if($LASTEXITCODE){throw 'Lifecycle validation failed; original logs retained.'}
} finally {Pop-Location}
if(-not (Test-Path -LiteralPath build/regression081-source.txt)){throw 'Final regression record missing.'}
& node scripts/Study-Build081.cjs
if($LASTEXITCODE){throw 'Build inputs changed after regression.'}
& node scripts/Inspect-Procedures081.cjs build/ui081-primary > build/analysis081.json
if($LASTEXITCODE){throw 'Independent inspection failed.'}
& node scripts/Probe-Procedures081.cjs build/ui081-primary > build/probes081.json
if($LASTEXITCODE){throw 'Independent corruption probes failed.'}
& python build/check-desktop081.py
if($LASTEXITCODE){throw 'Desktop count verification failed.'}
Write-Output 'Serial edition081 validation completed.'
