from pathlib import Path
import json, hashlib, gzip, subprocess, html, re, shutil, base64, xml.etree.ElementTree as ET
r=Path.cwd(); d=r/'docs/readmes/081'; out=r/'build/ui081-primary'; d.mkdir(parents=True,exist_ok=True)
def write(p,s): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s,encoding='utf8',newline='\n')
def js(p,v): write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b): return hashlib.sha256(b).hexdigest()
record=load(out/'result.json'); analysis=load(r/'build/analysis081.json'); probes=load(r/'build/probes081.json'); life=load(r/'build/ui081-lifecycle/result.json'); faults=load(r/'build/ui081-faults/result.json')
assert all(x['passed'] for x in [record,analysis,probes,life,faults])
e=analysis['summary']; source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(); archives=[]; archived=set()
def pack(p,dest):
 logical=dest.relative_to(r).as_posix(); dest=d/'original/files'/(sha(logical.encode())[:20]+'-'+dest.name[-42:])
 if dest in archived:return
 archived.add(dest);b=p.read_bytes();z=gzip.compress(b,mtime=0);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z)
 archives.append(dict(path=dest.relative_to(r).as_posix(),bytes=len(z),sha256=sha(z),rawBytes=len(b),rawSha256=sha(b),source=str(p),logicalPath=logical))
for folder in sorted((r/'build').glob('ui081-*')):
 if not folder.is_dir():continue
 for p in sorted(folder.iterdir()):
  if p.is_file() and p.suffix in ['.json','.log','.txt','.png','.jar']:pack(p,d/'original'/folder.name/(p.name+'.gz'))
 checkpoint=folder/('result.json' if (folder/'result.json').exists() else 'checkpoint.json')
 if checkpoint.exists() and folder.name not in ['ui081-faults','ui081-review']:
  project=Path(load(checkpoint)['project'])
  for dirname in ['world-procedures-079','persistent-worlds','goals','agency-043','creation-044','artifacts','receipts','runtime-042']:
   for p in sorted((project/dirname).rglob('*')):
    if p.is_file() and p.suffix in ['.json','.jsonl','.log','.html','.js','.css']:pack(p,d/'original'/folder.name/'project'/p.relative_to(project).with_suffix(p.suffix+'.gz'))
  for name in ['engine.log','events.jsonl','test-desktop-process.log']:
   p=project/name
   if p.exists():pack(p,d/'original'/folder.name/'project'/(name+'.gz'))
for pattern in ['*081*.log','*081-stack*.txt']:
 for p in sorted((r/'build').glob(pattern)):pack(p,d/'original/logs'/(p.name+'.gz'))
cases={}; invocations=[]
for folder in ['unit081-first','regression081']:
 rows=[]
 for p in sorted((r/'build'/folder).glob('TEST-*.xml')):
  root=ET.parse(p).getroot()
  for c in root.findall('testcase'):
   key=c.attrib['classname']+'#'+c.attrib['name']; passed=all(c.find(n) is None for n in ['failure','error','skipped']);
   if folder!='unit081-first':cases[key]=passed
   rows.append(dict(case=key,passed=passed))
  pack(p,d/'original/java'/folder/(p.name+'.gz'))
  for loc in re.findall(r'(?:WORLD079_NATIVE|REBUILD079_NATIVE) ([^\r\n<]+)',p.read_text(encoding='utf8')):
   for f in Path(loc).rglob('*.json'):pack(f,d/'original/java'/folder/Path(loc).name/f.relative_to(loc).with_suffix('.json.gz'))
 if rows:invocations.append(dict(name=folder,source='Excluded stale-build development attempt; not counted as final validation' if folder=='unit081-first' else (r/'build/regression081-source.txt').read_text(encoding='utf8').strip(),cases=rows))
assert cases and all(cases.values())
for name in ['analysis081.json','probes081.json','desktop081.json','unchanged-native081.json','profile081.json','Profile081.java','study081-build.json','validate081.ps1','check-desktop081.py','regress081.ps1','document081.py','guide081.html','README-081-template.md']:
 pack(r/'build'/name,d/'original/validation'/(name+'.gz'))
for folder in [out,r/'build/ui081-lifecycle',r/'build/ui081-review']:
 for p in folder.glob('*.png'):
  if p.name!='failure.png':shutil.copyfile(p,d/p.name)
protocol=load(r/'workspace-engine/src/main/resources/procedures081-protocol.json'); specs={s['id']:s for s in protocol['training']+protocol['calibration']+protocol['cases']}
data=dict(evaluation=e,learningTicks=sum(x['job']['arm']['chargedTicks'] for x in record['training'])+sum(x['job']['arm']['chargedTicks'] for row in record['calibration'] for x in row['results'].values()),bank=record['frozenBank'],model=record['model'],rows=[])
inputs=[dict(id=x['id'],split='training',results={'simple':x}) for x in record['training']]+[dict(**row,split='calibration') for row in record['calibration']]+[row for row in record['rows'] if row['split']=='unseen']
for row in inputs:
 entry=dict(id=row['id'],split=row['split'],spec=specs[row['id']],results={},replays={})
 for method,item in row['results'].items():
  x=load(out/item['originalFile']);a=item['job']['arm'];entry['results'][method]=dict(status=item['status'],reason=item['reason'],decision=item['job']['decision'],lookupMillis=item['job']['lookupMillis'],callerMillis=item['wallMillis'],cost080=item['goal']['taskCost080'],scan=item['scan']);entry['replays'][method]=[]
  for packet in x['originals']:
   raw=gzip.decompress(base64.b64decode(packet['gzipBase64']));assert sha(raw)==packet['rawSha256'];run=json.loads(raw);attempt=next(t for t in a['attempts'] if t['id']==run['id']);n=len(run['samples']);indices=sorted(set(round(i*(n-1)/min(239,max(1,n-1))) for i in range(min(240,n))))
   frames=[dict(tick=run['samples'][i]['tick'],originalSampleIndex=i,bodies=[{k:b[k] for k in ['id','position','rotation']} for b in run['samples'][i]['bodies']]) for i in indices]
   entry['replays'][method].append(dict(id=run['id'],stage=attempt['stage'],family=attempt['family'],status=attempt['status'],definition=run['definition'],originalSampleCount=n,samples=frames,targets=run['plan']['intent']['targets']))
 data['rows'].append(entry)
write(d/'comparison-data.json',json.dumps(data,separators=(',',':'))+'\n')
paths={x['path'] for x in load(r/'docs/readmes/080/file-inventory.json')};paths.update(x for x in subprocess.check_output(['git','diff','--name-only','--diff-filter=A','b121e65','HEAD'],text=True).splitlines() if x.startswith(('workspace-engine/','workspace-desktop/','scripts/','fraynix-modules/')));inventory=[]
for name in sorted(paths):
 b=(r/name).read_bytes()
 try:b=b.decode('utf8').replace('\r\n','\n').encode();kind='utf8-lf'
 except UnicodeError:kind='binary'
 inventory.append(dict(path=name,bytes=len(b),hashKind=kind,sha256=sha(b)))
js(d/'file-inventory.json',inventory);write(d/'FILE_TREE.md','# Edition 081 complete source tree\n\n[Canonical bytes and hashes](file-inventory.json).\n\n```text\n'+'\n'.join(x['path'] for x in inventory)+'\n```\n')
v=dict(edition=81,source=source,contract='e825734',primarySource=record['source'],javaDistinct=len(cases),javaClasses=len({k.split('#')[0] for k in cases}),javaAllPassed=True,javaInvocations=invocations,desktop=load(r/'build/desktop081.json'),actualApp=record['checks'],lifecycle=life['checks'],lifecycleSource=life['source'],faults=faults['checks'],faultsSource=faults['source'],primaryNativeAttempts=sum(len(i['job']['arm']['attempts']) for row in inputs for i in row['results'].values()),analysis=analysis,tamper=probes,sourceIsolation=load(r/'build/unchanged-native081.json'),profile=load(r/'build/profile081.json'),excludedDevelopment=load(r/'build/ui081-build-mismatch/build-mismatch.json'),buildReceipt=record['buildReceipt'],settledReview=load(r/'build/ui081-review/result.json'),scope='Eight paired labelled native-box tasks, one machine. Original physics, verifiers and selection arithmetic unchanged. Every calibration load rereads original bytes. Independent inspection is not another physics solver. No model-weight training or new physical accuracy claim.')
js(d/'verification.json',v)
modules=[('reader','Two evidence readers','CalibrationScan081.java','Two bounded readers run original byte/path checks, join, then compare; no cached trust.'),('runner','Verified procedure','WorldProcedure079.java','Original native forecasts, actual stages, model identity, pair arithmetic and reports.'),('goal','Durable goal and skill','GoalRunner.java','Original goal clock, real report checks, commit and requested retention.'),('proof','Original byte checks','ProofMemo078.java','Unchanged owned-file checks, SHA-256 and bounded evidence reads.'),('inspect','Independent reader','Inspect-Procedures081.cjs','Original-byte, native arithmetic, cost provenance and paired-work comparison.')]
mapping=[dict(id=i,name=n,note='docs/obsidian/89-calibration-evidence.md',source=('scripts/' if p.endswith('.cjs') else 'workspace-engine/src/main/java/fraymus/workspace/')+p,description=t) for i,n,p,t in modules]
js(d/'system-map.json',dict(modules=mapping,screenshots=[dict(path='docs/readmes/081/'+p.name,label=p.stem) for p in sorted(d.glob('*.png'))]))
a=e['methods']['reference'];b=e['methods']['parallel']
result=f"Calibration-reading overhead {'fell' if e['estimationImproved'] else 'did not fall'} by the comparison's measured {e['estimationReductionPercent']:.1f}%. Complete Java task time changed from {a['completeMillis']/1000:.2f}s to {b['completeMillis']/1000:.2f}s ({e['completeReductionPercent']:.2f}% reduction). Complete-task improvement: **{'observed in this batch' if e['completeTaskFaster'] else 'not established in this batch'}**. Both methods completed {b['successes']}/8 tasks."
values=dict(RESULT_TEXT=result,RESULT_TABLE='\n'.join(f"| {k} | {x['successes']}/8 | {x['completeMillis']/1000:.2f} | {x['callerMillis']/1000:.2f} | {x['estimationMillis']/1000:.3f} | {x['loads']} | {x['ticks']:,} |" for k,x in e['methods'].items()),MICRO=f"{e['microReductionPercent']:.1f}",TRAIN=f"{e['trainingMillis']/1000:.2f}",FIT=f"{e['calibrationMillis']/1000:.2f}",JAVA=str(v['javaDistinct']),CLASSES=str(v['javaClasses']),DESKTOP=str(v['desktop']['tests']),FAILURES='An earlier development attempt was stopped after visual review caught a build made before a source text-encoding cleanup. Its partial measurements, original project records, log and exact installed engine JAR are retained and excluded from this comparison. A full rebuild and entirely fresh study followed; input and installed-JAR hashes are checked before launch and at completion. No cases or policy thresholds were changed.')
s=(r/'build/README-081-template.md').read_text(encoding='utf8')
for k,val in values.items():s=s.replace('__'+k+'__',val)
assert not re.search(r'__[A-Z_]+__',s);write(r/'README-081.md',s)
shots=''.join(f'<figure><a href="{html.escape(p.name)}"><img src="{html.escape(p.name)}" alt="Actual edition081 {html.escape(p.stem)}"></a><figcaption>{html.escape(p.stem)} · actual isolated app capture, November 6, 2026.</figcaption></figure>' for p in sorted(d.glob('*.png')))
s=(r/'build/guide081.html').read_text(encoding='utf8').replace('__SHOTS__',shots)
for key,obj in [('DATA',data),('MAP',load(d/'system-map.json')),('INVENTORY',inventory)]:s=s.replace('__'+key+'__',json.dumps(obj,separators=(',',':')).replace('<','\\u003c'))
write(d/'index.html',s)
write(r/'docs/obsidian/89-calibration-evidence.md',f'# Calibration evidence · edition081\n\n[[README-081|Edition081]] · [[README-080|Previous080]] · [[docs/readmes/081/index.html|Offline evidence]] · [[docs/obsidian/calibration-evidence.canvas|System map]]\n\n{result}\n\nTwo bounded Java evidence readers; original owned-file and byte checks on every load; join before comparison. No cached trust or timestamp shortcut. Pair arithmetic, conservative choice, native verification and final world commit unchanged. Serial reference only in isolated test runtimes. Six existing cases and two prospective mass/friction variations; bank/model frozen.\n\nNext: repeat complete costs under different resource budgets; cold and retention workloads; longer sequences and amortization. Source identity remains mandatory.\n')
nodes=[dict(id='readme',type='file',file='README-081.md',x=0,y=0,width=380,height=200)];edges=[]
for i,m in enumerate(mapping):nodes.append(dict(id=m['id'],type='file',file=m['source'],x=(i%3)*420,y=270+(i//3)*260,width=380,height=210));edges.append(dict(id='e'+str(i),fromNode='readme',fromSide='bottom',toNode=m['id'],toSide='top',label=m['name']))
js(r/'docs/obsidian/calibration-evidence.canvas',dict(nodes=nodes,edges=edges));js(d/'original-evidence.json',dict(format='Exact gzip originals from isolated synthetic projects and tests. No private production project. Original080 profile is read-only diagnosis, not current native proof.',files=archives));print(json.dumps(dict(archives=len(archives),canonicalFiles=len(inventory),javaDistinct=v['javaDistinct'],estimationImproved=e['estimationImproved'])))
